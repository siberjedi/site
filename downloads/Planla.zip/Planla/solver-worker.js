/* Planla! — paralel çözücü işçisi (Web Worker)
 *
 * Neden: tarayıcı tek iş parçacıklıdır; uygulama aynı anda tek bir arama yapabiliyordu.
 * Ölçümde aynı veriyi 6 bağımsız aramayla denediğimizde 6'dan 2'si TAM yerleşim buldu,
 * tek arama ise bulamıyordu. Fark, aramanın rastgele başlangıcından geliyor.
 * Bu işçi, çözücüyü ana iş parçacığından bağımsız bir çekirdekte çalıştırır; ana sayfa
 * birkaç işçiyi aynı anda başlatıp ilk TAM sonucu alır.
 *
 * app.js'i olduğu gibi yükleriz (kod ikizlenmesin diye). solveAllJoint içinde doğrudan
 * DOM erişimi yok; yalnız birkaç arayüz fonksiyonu çağırıyor. Onları aşağıda taklit ediyoruz.
 */

/* ---- Sahte DOM: app.js worker içinde de yüklenebilsin ---- */
const _el = new Proxy(function () {}, {
  get(_t, k) {
    if (k === 'style' || k === 'classList' || k === 'dataset')
      return new Proxy({}, { get: () => () => {}, set: () => true });
    if (k === 'options' || k === 'children' || k === 'selectedOptions' || k === 'files') return [];
    if (k === 'value' || k === 'textContent' || k === 'innerHTML' || k === 'className') return '';
    if (k === 'checked' || k === 'disabled') return false;
    return () => _el;
  },
  set: () => true,
  apply: () => _el,
});
self.document = {
  getElementById: () => _el,
  querySelector: () => _el,
  querySelectorAll: () => [],
  createElement: () => _el,
  addEventListener: () => {},
  body: _el,
  documentElement: _el,
  fonts: { check: () => true, ready: Promise.resolve() },
};
self.window = self;
self.localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
self.requestAnimationFrame = (f) => setTimeout(f, 0);
self.alert = () => {};
self.confirm = () => true;
self.matchMedia = () => ({ matches: false, addEventListener: () => {} });

// Sürümü kendi URL'imizden al ve app.js'i AYNI sürümle yükle: sayfa ile işçinin farklı
// app.js sürümleri çalıştırması (tarayıcı önbelleği) gerçek bir hataya yol açmıştı.
const _surum = (String(self.location.search || '').match(/[?&]v=([^&]+)/) || [])[1] || '0';
self.__APP_SURUM = _surum;
importScripts('app.js?v=' + _surum);

/* İşçide arayüz yok, ama süre yine de kıymetli.
   Ölçüm: bu veride sıfırdan arama hiçbir bütçeyle tamamlanmıyor; tam yerleşimi bulan
   onarım + bitiriş fazı. O yüzden sıfırdan faz ERKEN pes etsin (2,5 dk iyileşme yoksa),
   kazandıran faza daha çok süre kalsın. */
try { STALL_MS = 150000; } catch (e) {}
try { REPAIR_STALL_MS = 420000; } catch (e) {}
try { SOLVE_SOFT_MS = 600000; } catch (e) {}

/* ---- Arayüz fonksiyonlarını mesajla değiştir ---- */
let _seed = 0;
self.showScheduleProgress = function (text, pct) {
  self.postMessage({ tip: 'ilerleme', seed: _seed, metin: String(text || ''), pct: pct || 0 });
};
self.toast = function () {};
self.saveState = function () {};
self.refresh = function () {};
self.renderDefs = function () {};
// waitFrame ana iş parçacığındaki rAF'e bağlıydı; burada mikro gecikme yeterli.
self.waitFrame = function () { return new Promise((r) => setTimeout(r, 0)); };

function _tamMi(res) {
  if (!res) return false;
  const eksik = (res.allFailed || res.failed || []).length;
  return eksik === 0;
}

self.onmessage = async function (e) {
  const msg = e.data || {};
  if (msg.tip !== 'basla') return;
  _seed = msg.seed || 0;
  try {
    // Ana iş parçacığının durumunu bu işçiye kopyala (structured clone ile geldi).
    S = msg.state;
    if (typeof solveCancelled !== 'undefined') solveCancelled = false;

    const opts = { flexibleBlocks: true, silentResult: true };
    if (msg.completeOnly) opts.completeOnly = true;   // mevcut programı koru, boşlukları kapat
    const res = await solveAllJoint(opts);

    // Sonuç: her okulun ders satırları + özet
    const lessons = {};
    for (const sc of S.schools) if ((sc.defs || []).length) lessons[sc.id] = sc.lessons || [];
    self.postMessage({
      tip: 'bitti',
      seed: _seed,
      tam: _tamMi(res),
      yerlesen: res ? res.placedHours || 0 : 0,
      toplam: res ? res.totalHours || 0 : 0,
      eksikBlok: res ? (res.allFailed || res.failed || []).length : -1,
      lessons,
    });
  } catch (err) {
    self.postMessage({ tip: 'hata', seed: _seed, mesaj: String((err && err.message) || err) });
  }
};
