' Planla! - Tek tikla baslat
' Bu dosyaya cift tiklamaniz yeterli.
' Python yuklu degilse index.html'e cift tiklayarak da kullanabilirsiniz.

Option Explicit

Dim shell, fso, kok, pyCmd, kod, port
Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

' ---- Calisma dizinini BU dosyanin klasorune sabitle ----
' (Onceki surumde bu yoktu: kisayoldan veya baska bir klasorden calistirildiginda
'  sunucu.py bulunamiyor, sunucu hic acilmiyor ve tarayicida bos sayfa cikiyordu.)
kok = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = kok

port = 5177

' ---- Gerekli dosyalar yerinde mi ----
If Not fso.FileExists(fso.BuildPath(kok, "index.html")) Then
  MsgBox "index.html bu klasorde bulunamadi:" & vbCrLf & kok & vbCrLf & vbCrLf & _
         "baslat.vbs dosyasini uygulamanin bulundugu klasorden calistirin.", 16, "Planla!"
  WScript.Quit
End If

' ---- Python var mi (once py launcher, sonra python) ----
' shell.Run kabuk yonlendirmesi (2>nul) anlamaz; bu yuzden cmd /c ile sariyoruz.
pyCmd = ""
kod = shell.Run("cmd /c py --version >nul 2>&1", 0, True)
If kod = 0 Then
  pyCmd = "py"
Else
  kod = shell.Run("cmd /c python --version >nul 2>&1", 0, True)
  If kod = 0 Then pyCmd = "python"
End If

If pyCmd = "" Or Not fso.FileExists(fso.BuildPath(kok, "sunucu.py")) Then
  ' Python yoksa dosyayi dogrudan ac - uygulama file:// uzerinde de calisir.
  shell.Run """" & fso.BuildPath(kok, "index.html") & """", 1, False
  WScript.Quit
End If

' ---- Ayni porttaki eski sunucuyu durdur ----
shell.Run "powershell -NoProfile -WindowStyle Hidden -Command ""Get-NetTCPConnection -LocalPort " & port & _
          " -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique |" & _
          " ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }""", 0, True

' ---- Sunucuyu arka planda baslat ----
shell.Run "cmd /c " & pyCmd & " """ & fso.BuildPath(kok, "sunucu.py") & """", 0, False

' ---- Sunucu hazir olana kadar bekle (sabit bekleme yerine gercek kontrol) ----
Dim http, hazir, i
hazir = False
For i = 1 To 40                     ' en fazla ~10 saniye
  WScript.Sleep 250
  On Error Resume Next
  Set http = CreateObject("MSXML2.XMLHTTP")
  http.Open "GET", "http://127.0.0.1:" & port & "/index.html", False
  http.Send
  If Err.Number = 0 And http.Status = 200 Then hazir = True
  Err.Clear
  On Error GoTo 0
  If hazir Then Exit For
Next

If Not hazir Then
  ' Sunucu acilmadi: uygulamayi dosyadan ac, kullanici bos sayfayla karsilasmasin.
  shell.Run """" & fso.BuildPath(kok, "index.html") & """", 1, False
  WScript.Quit
End If

' ---- Tarayicida ac (onbellek icin zaman damgasi) ----
shell.Run "http://localhost:" & port & "/?t=" & CLng(Timer * 1000), 1, False
