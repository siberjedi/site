# Üçüncü taraf bileşenler

Planla! internet bağlantısı gerektirmez; aşağıdaki bileşenler klasörün içinde gelir.

## Kütüphane

- **`xlsx.full.min.js`** — xlsx-js-style 1.2.0-beta (SheetJS Community Edition tabanlı),
  Apache License 2.0. Excel (`.xlsx`) çıktısı için kullanılır.

## Yazı tipleri

- **`fonts/inter-*.woff2`** — Inter, Rasmus Andersson.
  SIL Open Font License 1.1 (<https://openfontlicense.org>).
  Arayüz yazı tipi; Google Fonts'tan indirilip klasöre konmuştur (çevrimdışı çalışsın diye).

- **`fonts/ms-subset.woff2`** — Material Symbols Outlined, Google.
  Apache License 2.0.
  Yalnız uygulamada kullanılan ikonları içeren küçültülmüş (subset) sürümdür;
  hangi ikonların bulunduğu `fonts/_ikonlar.txt` dosyasında listelidir.

Bu dosyalar dışındaki tüm kod Planla!'ya aittir ve `LICENSE` (MIT) ile dağıtılır.
