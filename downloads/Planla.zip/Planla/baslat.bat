@echo off
title Dagitmatik

py --version >nul 2>&1
if %errorlevel% equ 0 (
    set PY_CMD=py
) else (
    python --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo Python 3 bulunamadi.
        echo index.html dosyasina cift tiklayarak da kullanabilirsiniz.
        echo.
        pause
        start "" "index.html"
        exit /b
    )
    set PY_CMD=python
)

echo Dagitmatik baslatiliyor...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 5177 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"
start /min "" "%PY_CMD%" sunucu.py
timeout /t 2 /nobreak >nul
start "" "http://localhost:5177/?t=%random%"
exit
