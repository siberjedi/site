# Planla! — Ders Programı Üretici

> **Planla! ücretsizdir.** Dilediğiniz gibi kullanabilir, kopyalayabilir ve paylaşabilirsiniz.

## Kurulum gerektirmez

**`baslat.vbs`** dosyasına çift tıklayın — uygulama tarayıcınızda açılır.

> **Neden `baslat.vbs`?** Dağıtım, bilgisayarınızın tüm çekirdeklerini kullanarak aynı anda
> birkaç arama yürütür; zor programlarda tam yerleşimi bulan şey budur. Tarayıcılar bu özelliği
> yalnız yerel sunucu üzerinden açılan sayfalarda çalıştırır, `baslat.vbs` de onu kurar.
>
> `index.html`'e çift tıklayarak da kullanabilirsiniz — her şey çalışır, yalnız dağıtım tek
> çekirdekle arar ve zor programlarda eksik kalma ihtimali artar.

- Tüm kütüphaneler ve yazı tipleri klasörün içindedir — **internet bağlantısı gerekmez.**
- Verileriniz tarayıcınızın hafızasında saklanır (aynı tarayıcıyı kullanmaya devam edin).
- Bilgisayar değiştirecekseniz **Kaydet** ile `.json` dosyası indirip yeni bilgisayarda **Aç** ile yükleyin.

## Verilerinizi korumak

Uygulama her değişikliği tarayıcıya otomatik kaydeder ve son iki sürümü ayrıca yedekler.
Yine de şunlara dikkat edin:

- Tarayıcı geçmişini silerken "site verileri"ni temizlerseniz veriniz gider.
  **Önemli çalışmalarda ara ara `Kaydet` ile dosya yedeği alın** (dosya adı tarihlidir).
- Depolama dolarsa veya gizli sekmede çalışıyorsanız uygulama sizi uyarır;
  bu uyarıyı görürseniz hemen `Kaydet` ile dosyaya indirin.
- Kayıtlı veri bozulursa açılışta uyarı çıkar ve varsa önceki yedek geri yüklenir.

## Dağıtım düğmeleri

| Düğme | Ne yapar |
|---|---|
| **Dağıt** | Yalnız seçili okulu dağıtır. |
| **Tümünü Dağıt** | Tüm okulları **birlikte** dağıtır (ortak öğretmen çakışmaları aynı anda çözülür). Mevcut yerleşimi siler ve sıfırdan kurar — bu yüzden önce onay sorar. |
| **Eksikleri Tamamla** | Mevcut programı korur, yalnız yerleşmemiş dersleri yerleştirir. Gerektiği kadar dersi oynatır. **Elinizde iyi bir program varsa bunu kullanın.** |
| **Dağıtımı Sil** | Tüm okullardaki yerleşmiş dersleri temizler (tanımlar durur). |

Arama en fazla 3 dakika sürer; süre dolarsa o ana kadarki en iyi sonuç saklanır ve
ekranda "süre doldu" uyarısı çıkar.

## Detaylı kullanım kılavuzu

Tüm özellikler için **`KILAVUZ.md`** dosyasına bakın: ders/sınıf/öğretmen/derslik ekleme,
saatleri açma-kapama, teneffüs ve öğle arası, ders tanımlama, kısıtlar, dağıtım,
raporlar, PDF/Excel çıktısı ve daha fazlası.

## İsteğe bağlı: tek tıkla başlatma (Python'u olanlar için)

Python 3 kuruluysa **`baslat.vbs`** dosyasına çift tıklayabilirsiniz:
yerel bir sunucu başlatır ve uygulamayı tarayıcınızda açar.
Python yoksa bu adımı atlayın — `index.html` doğrudan çalışır.

## Dosyalar

| Dosya | Açıklama |
|---|---|
| `index.html` | Uygulama (çift tıkla açılır, kurulum gerekmez) |
| `app.js` | Çözücü + arayüz |
| `styles.css` | Tasarım |
| `fonts.css`, `fonts/` | Yazı tipleri ve ikonlar (klasör içinde, internet gerekmez) |
| `icon.svg`, `icon-dark.svg` | Uygulama simgesi |
| `xlsx.full.min.js` | Excel çıktısı kütüphanesi |
| `ornek/planla-ornek.json` | Denemek için örnek okul verisi |
| `KILAVUZ.md` | Detaylı Türkçe kullanım kılavuzu |
| `baslat.vbs`, `baslat.bat`, `sunucu.py` | İsteğe bağlı: tek tıkla başlatma (Python 3 gerekir) |
