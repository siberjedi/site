/* ============================================================
   Planla! — Grid-tabanlı ders programı üretici
   Ücretsizdir: dilediğiniz gibi kullanabilir ve paylaşabilirsiniz.
   ============================================================ */

/* ─── STATE (çoklu okul) ─── */
const SCHOOL_DFLT = {
  name:"Okul",days:["Pazartesi","Salı","Çarşamba","Perşembe","Cuma"],
  periods:10,classes:[],courses:[],schoolClosed:{},classClosed:{},
  lessons:[],defs:[],periodTimes:[],selectedClass:null,schoolLunch:{},
  constraints:{spreadCourse:false,spreadTeacher:false,coursePairs:[],courseGap:0,minBreak:10,requireLunch:true,maxSameRun:0}
};
// Kısıt nesnesini eksik alanlar sessizce kapanmasın diye doldurur
function normConstraints(c){
  return Object.assign({spreadCourse:false,spreadTeacher:false,coursePairs:[],courseGap:0,minBreak:10,requireLunch:true,maxSameRun:0}, c||{});
}

let S = null;
let _saveWarnAt=0;    // kayıt hatası uyarısı en fazla 30 sn'de bir gösterilir
let _backupAt=0;      // dönüşümlü yedek en fazla 5 dk'da bir alınır
let loadWarning=null; // bozuk kayıt uyarısı (açılışta toast ile gösterilir)

function newSchool(id){ return {id,...JSON.parse(JSON.stringify(SCHOOL_DFLT))} }

// Bozuk kayıt / yedekten geri yükleme için ortak dönüştürme (yeni ve eski format)
function normalizeState(d){
  if(d.schools){
    if(typeof d.darkMode!=="boolean") d.darkMode=false;
    if(!Array.isArray(d.rooms)) d.rooms=[];
    if(typeof d.viewAll!=="boolean") d.viewAll=false;
    migrateTeachers(d);
    return d; // yeni format
  }
  // Migration: eski format
  const s=newSchool("s1");
  s.name="Okul"; s.days=d.days||SCHOOL_DFLT.days; s.periods=d.periods||10;
  s.classes=d.classes||[]; s.courses=d.courses||[];
  s.schoolClosed=d.schoolClosed||{}; s.classClosed=d.classClosed||{};
  s.periodTimes=d.periodTimes||[]; s.selectedClass=d.selectedClass||null;
  s.constraints=d.constraints||{spreadCourse:false,spreadTeacher:false,coursePairs:[]};
  if(d.defs) s.defs=d.defs;
  else if(d.lessons&&d.lessons.length){
    const seen={};
    for(const l of d.lessons){
      const key=`${l.course}|${l.teacher}|${l.className}`;
      if(!seen[key]) seen[key]={course:l.course,teacher:l.teacher,className:l.className,hours:l.hours||2,block:Math.min(l.hours||2,2)};
      else seen[key].hours=Math.max(seen[key].hours,l.hours||2);
    }
    s.defs=Object.values(seen).map(x=>({...x,id:uid()}));
  }
  if(!s.courses.length&&s.defs.length){
    const cs=new Set();
    for(const def of s.defs) cs.add(def.course);
    s.courses=[...cs].sort((a,b)=>a.localeCompare(b,"tr"));
  }
  const out={schools:[s],teachers:d.teachers||[],teacherClosed:d.teacherClosed||{},
    teacherCourses:d.teacherCourses||{},currentSchool:"s1",selectedTeacher:d.selectedTeacher||null,selectedRoom:d.selectedRoom||null,
    rooms:[],viewAll:false,
    darkMode:!!d.darkMode};
  migrateTeachers(out);
  return out;
}
function emptyState(){
  const s=newSchool("s1");
  return {schools:[s],teachers:[],teacherClosed:{},teacherCourses:{},currentSchool:"s1",selectedTeacher:null,selectedRoom:null,rooms:[],darkMode:false};
}
function loadState(){
  let r=null;
  try{ r=localStorage.getItem("dagitmatik2"); }catch(e){}
  if(!r) return emptyState();
  try{
    return normalizeState(JSON.parse(r));
  }catch(e){
    // Veri var ama okunamadı: sessizce yutma, bozuk kaydı sakla
    try{ localStorage.setItem("dagitmatik2_bozuk_"+Date.now(), r); }catch(e2){}
    loadWarning="⚠ Kayıtlı veriniz okunamadı. Bozuk kayıt yedeklendi; 'Aç' ile bir yedek dosyanızı yükleyebilirsiniz.";
    try{
      const b=localStorage.getItem("dagitmatik2_yedek1");
      if(b){
        loadWarning="⚠ Son kayıt bozuktu, bir önceki yedek geri yüklendi.";
        return normalizeState(JSON.parse(b));
      }
    }catch(e2){}
    return emptyState();
  }
}

// Eski kayıtlarda teacher/teacher2 alanlarını teachers dizisine dönüştürür
function migrateTeachers(state){
  for(const sc of state.schools||[]){
    for(const d of sc.defs||[]) if(!Array.isArray(d.teachers)) setTeachers(d, defTeachers(d));
    for(const l of sc.lessons||[]) if(!Array.isArray(l.teachers)) setTeachers(l, lessonTeachers(l));
  }
  return state;
}

function saveState(){
  // Dönüşümlü yedek: saveState her hücre tıklamasında çalıştığı için her seferinde
  // yedeklersek yedek iki tık sonra değersizleşir ve kotayı üç katına çıkarır.
  // Bu yüzden en fazla 5 dakikada bir yedek alınır — yedekler anlamlı ölçüde eski kalır.
  if(Date.now()-_backupAt>300000){
    try{
      const cur=localStorage.getItem("dagitmatik2");
      if(cur!==null){
        const b1=localStorage.getItem("dagitmatik2_yedek1");
        if(b1!==null) localStorage.setItem("dagitmatik2_yedek2",b1);
        localStorage.setItem("dagitmatik2_yedek1",cur);
        _backupAt=Date.now();
      }
    }catch(e){}
  }
  try{
    localStorage.setItem("dagitmatik2",JSON.stringify({
      schools:S.schools,teachers:S.teachers,teacherClosed:S.teacherClosed,
      teacherCourses:S.teacherCourses,currentSchool:S.currentSchool,
      selectedTeacher:S.selectedTeacher,darkMode:!!S.darkMode,rooms:S.rooms,selectedRoom:S.selectedRoom||null,viewAll:!!S.viewAll
    }));
  }catch(e){
    if(Date.now()-_saveWarnAt>30000){
      _saveWarnAt=Date.now();
      toast("⚠ Tarayıcıya kaydedilemedi (depolama dolu veya engelli). Çalışmanızı kaybetmemek için 'Kaydet' ile dosyaya indirin.","err");
    }
  }
}

// Yerleşemeyen tanımların kimlikleri: bir sonraki dağıtımda zor dersler ilk denemeden
// itibaren öne alınsın diye kalıcı saklanır. Yalnız id listesi tutulur (küçük).
function loadHardDefs(){
  try{ const r=localStorage.getItem("planlaHardDefs"); const a=r?JSON.parse(r):[]; return Array.isArray(a)?a:[]; }catch(e){ return []; }
}
function saveHardDefs(ids){
  try{ localStorage.setItem("planlaHardDefs", JSON.stringify([...new Set(ids)].slice(0,500))); }catch(e){}
}

function curSchool(){ return S.schools.find(s=>s.id===S.currentSchool)||S.schools[0] }

S = loadState();
// Mevcut kayıt bozuksa (iki kere push hatası → 76/38 gibi) otomatik düzelt: aynı sınıf+gün+periyot için tek ders kalsın
(function dedupLessonsOnLoad(){
  let fixed=false;
  for(const sc of S.schools||[]){
    const seen=new Set(); const out=[];
    for(const l of sc.lessons||[]){
      const k=`${l.className}|${l.day}|${l.period}`;
      if(seen.has(k)) { fixed=true; continue; }
      seen.add(k); out.push(l);
    }
    if(out.length!==(sc.lessons||[]).length) sc.lessons=out;
  }
  if(fixed) saveState();
})();

/* ─── UTILITIES ─── */
const $ = id => document.getElementById(id);
const uid = () => Math.random().toString(36).slice(2,10)+Date.now().toString(36);
const sk = (d,p) => `${d}|${p}`;
/* Sürüm damgası (index.html'deki app.js?v=NN).
   İşçi hem kendisini hem app.js'i AYNI sürümle yüklemeli; aksi hâlde güncellemeden sonra
   sayfa yeni app.js'i, işçi tarayıcı önbelleğinden ESKİ app.js'i çalıştırabiliyor.
   Bunu bizzat yaşadım: işçide değiştirdiğim tıkanma eşiği devreye girmedi. */
const APP_SURUM=(typeof self!=="undefined"&&self.__APP_SURUM)?self.__APP_SURUM:(function(){
  try{ const el=document.querySelector('script[src*="app.js"]'); const m=el&&String(el.getAttribute("src")||"").match(/[?&]v=([^&]+)/); return m?m[1]:"0"; }catch(e){ return "0"; }
})();
const tLabel=(t1,t2)=>t2?`${t1} + ${t2}`:(t1||"");
// ÇOKLU ÖĞRETMEN desteği: tanım/dersteki TÜM öğretmenler (geriye dönük teacher/teacher2)
function defTeachers(d){ return (d&&Array.isArray(d.teachers)&&d.teachers.length)?d.teachers:(d&&d.teacher?[d.teacher,...(d.teacher2?[d.teacher2]:[])].filter(Boolean):[]); }
// Öğretmen talep haritası: her öğretmenin verilen okul kümesindeki TÜM defs'lerdeki toplam
// ders saati (ve hangi okullarda dersi olduğunun kümesi). Çözücü sıralaması ile
// crossSchoolTeacherIssues aynı talep hesabını bu ortak yardımcıdan alır.
function teacherLoadMap(schools){
  const load={}, bySchool={};
  for(const sc of schools){
    for(const def of sc.defs||[]){
      const h=Math.max(1,Number(def.hours)||1);
      for(const t of defTeachers(def)){
        load[t]=(load[t]||0)+h;
        (bySchool[t]=bySchool[t]||new Set()).add(sc.id);
      }
    }
  }
  return {load,bySchool};
}
function lessonTeachers(l){ return (l&&Array.isArray(l.teachers)&&l.teachers.length)?l.teachers:(l&&l.teacher?[l.teacher,...(l.teacher2?[l.teacher2]:[])].filter(Boolean):[]); }
function tLabelArr(ts){ return (ts||[]).filter(Boolean).join(" + "); }
function defLabel(d){ return tLabelArr(defTeachers(d)); }
function lessonLabel(l){ return tLabelArr(lessonTeachers(l)); }
// Öğretmen listesini teacher/teacher2 alanlarıyla senkron tutar
function setTeachers(obj, list){
  const arr=[...(list||[])].filter(Boolean);
  obj.teachers=[...new Set(arr)];
  obj.teacher=obj.teachers[0]||null;
  obj.teacher2=obj.teachers[1]||null;
  return obj;
}
// Tanım/derste aynı ders-sınıf eşleşmesini kıyaslamak için kararlı anahtar
// Sınıf çoğulluğu: teachers[] deseninin sınıf karşılığı. className birincil sınıf olarak kalır,
// classNames yoksa tek elemanlı liste döner — eski kayıtlar dönüştürmesiz çalışır.
function defClasses(d){ return (d&&Array.isArray(d.classNames)&&d.classNames.length)?d.classNames:(d&&d.className?[d.className]:[]); }
function lessonClasses(l){ return (l&&Array.isArray(l.classNames)&&l.classNames.length)?l.classNames:(l&&l.className?[l.className]:[]); }
/* Ayni sinifta ust uste gelmesi istenmeyen ikili: ayni ders ADI (ogretmenleri farkli
   olabilir) veya ayni OGRETMEN (dersleri farkli olabilir). spreadCourse kurali TANIM
   bazli calistigi icin bu iki durumu gormuyordu: bir sinifta INGILIZCE iki ayri
   ogretmenle iki ayri tanimsa 2+2 blok bitisik dusup 4 saat ust uste ders olabiliyordu;
   ayni sekilde bir ogretmenin AYT MATEMATIK + TYT MATEMATIK'i arka arkaya gelebiliyordu. */
function sameRunFamily(a,b){
  if(!a||!b) return false;
  if(a.course===b.course) return true;
  const ta=a.teachers||[a.teacher], tb=b.teachers||[b.teacher];
  for(const t of ta) if(t && tb.indexOf(t)>=0) return true;
  return false;
}
function blockClasses(b){ return (b&&Array.isArray(b.classNames)&&b.classNames.length)?b.classNames:(b&&b.className?[b.className]:[]); }
function setClasses(obj, list){
  const arr=[...new Set([...(list||[])].filter(Boolean))];
  obj.classNames=arr; obj.className=arr[0]||null; return obj;
}
function refKey(course,teachers,className){
  const cls=Array.isArray(className)?[...new Set(className)].sort().join("+"):className;
  return `${course}|${[...new Set(teachers)].sort().join("+")}|${cls}`;
}
// ÇOKLU ÖĞRETMEN/SINIF: ek seçim alanları <select multiple> (Ctrl ile çoklu seçim, diğer alanlarla aynı etkileşim)
function extraChecks(container){
  if(!container) return [];
  return [...(container.selectedOptions||[])].map(o=>o.value).filter(Boolean);
}
function renderExtraTeachers(container, selected){
  if(!container) return;
  const sel=new Set(selected||[]);
  container.innerHTML=S.teachers.length
    ? S.teachers.map(t=>`<option value="${esc(t)}"${sel.has(t)?" selected":""}>${esc(t)}</option>`).join("")
    : '<option disabled>Önce öğretmen ekleyin</option>';
}
// BİRLEŞİK SINIF: Ek Sınıflar alanı — Sınıf alanında seçili olmayan sınıfları listeler; mevcut seçimi korur (H2.3)
/* Ek Ogretmen / Ek Sinif alanlari opsiyonel; form kalabaligi olmasin diye kapali
   baslar, butonla acilir. Bir tanim duzenlenirken icinde secim varsa otomatik acilir. */
function setOptField(ad, acik){
  const govde=$(ad+"Body"), btn=$(ad+"Toggle");
  if(!govde||!btn) return;
  govde.hidden=!acik;
  btn.setAttribute("aria-expanded", acik?"true":"false");
  btn.classList.toggle("open", !!acik);
  const ikon=btn.querySelector(".opt-sign");
  if(ikon) ikon.textContent = acik ? "−" : "+";
}
function toggleOptField(ad){ setOptField(ad, $(ad+"Body") && $(ad+"Body").hidden); }
function renderDefExtraClasses(){
  const exSel=$("defExtraClass");
  if(!exSel) return;
  const chosen=new Set([...(exSel.selectedOptions||[])].map(o=>o.value));
  const primary=new Set([...$("defClass").selectedOptions].map(o=>o.value));
  const list=[...curSchool().classes].sort(trSort).filter(c=>!primary.has(c));
  exSel.innerHTML=list.length
    ? list.map(c=>`<option value="${esc(c)}"${chosen.has(c)?" selected":""}>${esc(c)}</option>`).join("")
    : `<option disabled>${curSchool().classes.length?"Tüm sınıflar Sınıf alanında seçili":"Önce sınıf ekleyin"}</option>`;
}
const esc = s => {const d=document.createElement('div');d.textContent=s;return d.innerHTML};
const trSort = (a,b) => (a||'').localeCompare(b||'', 'tr');
const toMin = t => { const [h,m]=String(t).split(':').map(Number); return h*60+m; };

/* ─── SLOT DURUMU (okul bazlı) ─── */
function schoolOpenIn(school,d,p){ return !((school.schoolClosed||{})[sk(d,p)]) }
function classOpenIn(school,cl,d,p){
  return schoolOpenIn(school,d,p) && !(school.classClosed&&school.classClosed[cl] && school.classClosed[cl][sk(d,p)])
}
function teacherOpenIn(school,t,d,p){
  if(!schoolOpenIn(school,d,p)) return false;
  if(S.teacherClosed[t] && S.teacherClosed[t][school.id] && S.teacherClosed[t][school.id][sk(d,p)]) return false;
  // Diğer okullarda duvar saati olarak çakışan dersi var mı?
  const ptC=school.periodTimes&&school.periodTimes[p-1];
  if(!ptC) return true;
  const cS=toMin(ptC.start), cE=toMin(ptC.end);
  for(const sc of S.schools){
    if(sc.id===school.id) continue;
    for(const l of sc.lessons){
      if(l.day!==d||!lessonTeachers(l).includes(t)) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const oS=toMin(pt.start), oE=toMin(pt.end);
      if(cS<oE&&oS<cE) return false; // duvar saati çakışması
    }
  }
  return true;
}
function schoolOpen(d,p){ return schoolOpenIn(curSchool(),d,p) }
function classOpen(cl,d,p){ return classOpenIn(curSchool(),cl,d,p) }
function teacherOpen(t,d,p){ return teacherOpenIn(curSchool(),t,d,p) }

// Öğle arası: kullanıcı schoolLunch (gün|saat) ile belirler; belirtilmediyse okulun
// TÜM günlerde kapalı ve öğlen bandında olan saati otomatik bulunur (geriye dönük).
function schoolHasLunch(sc){ return !!sc.schoolLunch && Object.keys(sc.schoolLunch).some(k=>sc.schoolLunch[k]); }
function schoolAutoLunchPeriod(sc){
  const closed=sc.schoolClosed||{};
  const allDay={};
  for(const k of Object.keys(closed)){ const [day,p]=k.split('|'); allDay[p]=(allDay[p]||0)+1; }
  for(const [p,cnt] of Object.entries(allDay)){
    if(cnt!==(sc.days||[]).length) continue;
    const pt=sc.periodTimes&&sc.periodTimes[p-1];
    if(!pt) continue;
    const s=toMin(pt.start), e=toMin(pt.end);
    if(s<toMin("11:30")||e>toMin("14:30")) continue;
    return Number(p);
  }
  return null;
}
// Belirli bir gün için okulun öğle arası ders saati (kullanıcı ayarı öncelikli)
function schoolLunchDayPeriod(sc, day){
  if(!sc.schoolLunch) return null;
  const prefix=day+"|";
  for(const k of Object.keys(sc.schoolLunch)){
    if(sc.schoolLunch[k] && k.indexOf(prefix)===0) return Number(k.slice(prefix.length));
  }
  return null;
}
// Belirli bir gün için öğle arası pencereleri (tüm okullar). Gün için kullanıcı ayarı yoksa
// okulun otomatik (tüm günler kapalı) öğle arasına düşer.
function lunchWindowsForDay(day){
  const out=[];
  for(const sc of S.schools){
    if(!(sc.defs||[]).length) continue;
    let lp=schoolLunchDayPeriod(sc, day);
    if(lp==null) lp=schoolAutoLunchPeriod(sc);
    if(lp==null) continue;
    const pt=sc.periodTimes&&sc.periodTimes[lp-1];
    if(!pt) continue;
    out.push({start:toMin(pt.start),end:toMin(pt.end),school:sc.name});
  }
  return out;
}
// Okul görünümü hücre döngüsü: aç → kapat → öğle arası → aç (gün bazlı)
function cycleSchoolCell(d,p){
  const sc=curSchool();
  const k=sk(d,p);
  const closed=sc.schoolClosed||(sc.schoolClosed={});
  const lunch=sc.schoolLunch||(sc.schoolLunch={});
  if(closed[k] && lunch[k]){
    // öğle arası → aç
    delete lunch[k];
    delete closed[k];
    toast(`${d} ${p}. saat açıldı (öğle arası kaldırıldı).`);
  }else if(closed[k]){
    // kapalı → öğle arası
    lunch[k]=true;
    toast(`${d} ${p}. saat öğle arası olarak işaretlendi.`);
  }else{
    // aç → kapat
    closed[k]=true;
    toast(`${d} ${p}. saat kapatıldı.`);
  }
  saveState();
}
function teacherGlobalLesson(t,d,p){
  for(const school of S.schools){
    const l=school.lessons.find(l=>l.day===d&&l.period===p&&lessonTeachers(l).includes(t));
    if(l) return {lesson:l, schoolId:school.id, schoolName:school.name};
  }
  return null;
}

function toggleSchool(d,p){
  const k=sk(d,p);
  if(curSchool().schoolClosed[k]) delete curSchool().schoolClosed[k];
  else curSchool().schoolClosed[k]=true;
  saveState();
}
function toggleClass(cl,d,p){
  const k=sk(d,p);
  if(!curSchool().classClosed[cl]) curSchool().classClosed[cl]={};
  if(curSchool().classClosed[cl][k]) delete curSchool().classClosed[cl][k];
  else curSchool().classClosed[cl][k]=true;
  saveState();
}
function toggleTeacher(t,d,p,schoolId){
  const sid = schoolId || S.currentSchool;
  if(!S.teacherClosed[t]) S.teacherClosed[t]={};
  if(!S.teacherClosed[t][sid]) S.teacherClosed[t][sid]={};
  const k=sk(d,p);
  if(S.teacherClosed[t][sid][k]) delete S.teacherClosed[t][sid][k];
  else S.teacherClosed[t][sid][k]=true;
  saveState();
}

function lessonAt(d,p){
  return curSchool().lessons.find(l => l.day===d && l.period===p);
}

function classLessonAt(className,d,p,school=curSchool()){
  return school.lessons.find(l => lessonClasses(l).includes(className) && l.day===d && l.period===p);
}

function teacherLessonAt(teacher,d,p,school=curSchool()){
  return school.lessons.find(l => l.day===d && l.period===p && lessonTeachers(l).includes(teacher));
}

function courseColor(c){
  let h=0;
  for(let i=0;i<c.length;i++) h=((h<<5)-h)+c.charCodeAt(i);
  return `c${Math.abs(h)%10}`;
}

/* ─── DERS EKLE/SİL ─── */
function addLesson(course, teacher, className, day, period, hours){
  hours=hours||1;
  for(let o=0;o<hours;o++){
    const pp=period+o;
    if(pp>curSchool().periods) return false;
    if(!classOpen(className,day,pp)||!teacherOpen(teacher,day,pp)) return false;
    if(classLessonAt(className,day,pp)||teacherLessonAt(teacher,day,pp)) return false;
  }
  const id=uid();
  const totalHours=hours;
  for(let o=0;o<hours;o++){
    curSchool().lessons.push({id,course,teacher,className,day,period:period+o,hours:totalHours,part:o+1});
  }
  if(!S.teachers.includes(teacher)) S.teachers.push(teacher);
  if(!curSchool().classes.includes(className)) curSchool().classes.push(className);
  saveState();
  return true;
}

function removeLesson(id){
  curSchool().lessons = curSchool().lessons.filter(l=>l.id!==id);
  saveState();
  refresh();
}

function clearLessons(){
  curSchool().lessons=[];
  saveState();
  refresh();
}

/* ============================================================
   GRID RENDERER
   ============================================================ */
function renderGrid(container, mode, entity, schoolOverride){
  const school=schoolOverride||curSchool();
  container.innerHTML="";
  if(!school.days.length||!school.periods){ container.innerHTML='<div class="empty">Önce okul saatlerini tanımlayın.</div>'; return; }
  const autoLunchP=schoolAutoLunchPeriod(school);

  // Tüm dersleri bir kere tara, (day,period) → ders haritası oluştur
  const lessonMap={};
  for(const l of school.lessons){
    if(mode==="school") continue; // okul görünümü ders göstermez
    // Birleşik ders, listelendiği HER sınıfın çizelgesinde görünmeli.
    if(mode==="class"&&!lessonClasses(l).includes(entity)) continue;
    if(mode==="teacher"&&!lessonTeachers(l).includes(entity)) continue;
    const key=sk(l.day,l.period);
    if(!lessonMap[key]) lessonMap[key]=l; // ilk eklenen kalsın (çakışma olmamalı)
  }

  const wrap=document.createElement("div");
  wrap.style.overflow="auto";
  const tbl=document.createElement("table");

  const hdr=document.createElement("tr");
  const fc=document.createElement("th");
  fc.style.cssText="position:sticky;left:0;z-index:3";
  hdr.appendChild(fc);
  for(let p=1;p<=school.periods;p++){
    const th=document.createElement("th");
    const t=school.periodTimes&&school.periodTimes[p-1];
    th.innerHTML=t&&t.start?`${p}<br><span style="font-weight:400;font-size:10px;opacity:.7">${t.start}-${t.end}</span>`:String(p);
    if(p===school.periods) th.style.borderRight="1px solid #2a2d33";
    hdr.appendChild(th);
  }
  tbl.appendChild(hdr);

  for(const day of school.days){
    const dayLunchP = schoolLunchDayPeriod(school, day) ?? autoLunchP;
    const tr=document.createElement("tr");
    const dc=document.createElement("td");
    dc.className="day-cell";
    dc.textContent=day;
    tr.appendChild(dc);

    for(let p=1;p<=school.periods;p++){
      const td=document.createElement("td");
      td.className="grid-cell";
      td.dataset.day=day;
      td.dataset.period=p;

      const lesson=lessonMap[sk(day,p)]||null;
      const prevLesson=lessonMap[sk(day,p-1)]||null;
      const isBlockStart=lesson&&(!prevLesson||prevLesson.id!==lesson.id);

      if(lesson){
        td.classList.add("lesson",courseColor(lesson.course));
        td.title=`${lesson.course}\nSınıf: ${lesson.className}\nÖğretmen: ${lessonLabel(lesson)}${lesson.room?`\nDerslik: ${lesson.room}`:""}`;

        // Her hücreye etiketi yaz
        if(mode==="class"){
          td.innerHTML=`${esc(lesson.course)}<br><span class="more">${esc(lessonLabel(lesson))}</span>`;
        }else{
          td.appendChild(document.createTextNode(esc(lesson.className)));
        }
        if(isBlockStart){
          const del=document.createElement("button");
          del.className="del-lesson";del.textContent="×";
          del.dataset.lessonId=lesson.id;
          del.addEventListener("click",e=>{e.stopPropagation();removeLesson(lesson.id);});
          td.appendChild(del);
        }
      }else if(mode==="teacher"){
        // Bu okulun period'u ile duvar saati çakışan diğer okul dersleri
        const pt=school.periodTimes&&school.periodTimes[p-1];
        let other=null;
        if(pt){
          const cS=toMin(pt.start), cE=toMin(pt.end);
          for(const sc of S.schools){
            if(sc.id===school.id) continue;
            const l=sc.lessons.find(l=>l.day===day&&lessonTeachers(l).includes(entity)&&(sc.periodTimes&&sc.periodTimes[l.period-1])&&(function(){const o=sc.periodTimes[l.period-1];const oS=toMin(o.start),oE=toMin(o.end);return cS<oE&&oS<cE})());
            if(l){other={lesson:l,schoolName:sc.name};break;}
          }
        }
        if(other){
          td.classList.add("lesson","other-school");
          td.title=`${other.schoolName} → ${other.lesson.course}\n${other.lesson.className}`;
          if(!lessonMap[sk(day,p-1)]) td.appendChild(document.createTextNode("["+esc(other.schoolName.slice(0,3))+"]"));
        }else{
          td.classList.add(teacherOpenIn(school,entity,day,p)?"open":"closed");
          td.title=teacherOpenIn(school,entity,day,p)?"Tıkla: kapat  |  Sağ tık: ders ekle":"Tıkla: aç";
        }
      }else if(mode==="class"){
        td.classList.add(classOpenIn(school,entity,day,p)?"open":"closed");
        td.title=classOpenIn(school,entity,day,p)?"Tıkla: kapat  |  Sağ tık: ders ekle":"Tıkla: aç";
      }else{ // school
        td.classList.add(schoolOpenIn(school,day,p)?"open":"closed");
        td.title=schoolOpenIn(school,day,p)?"Tıkla: kapat":"Tıkla: öğle arası yap  |  tekrar tıkla: aç";
      }
      if(dayLunchP && p===dayLunchP){
        td.classList.add("lunch");
        if(!td.textContent) td.textContent="ÖĞLE ARASI";
        td.title=(td.title?td.title+"\n":"")+"Öğle arası (yemek molası) — tıkla: aç";
      }
      tr.appendChild(td);
    }
    tbl.appendChild(tr);
  }
  wrap.appendChild(tbl);
  container.appendChild(wrap);
}

// Öğretmenin TÜM okullardaki derslerini tek bir duvar saati zaman çizelgesinde gösterir
function renderTeacherCombined(container, entity, kind, schoolFilter){
  container.innerHTML="";
  kind=kind||"teacher";
  // Gün aralığı: ders tanımlı okulların periodTimes'ından min başlangıç / max bitiş (10 dk'ya yuvarla)
  let dayStart=Infinity, dayEnd=-Infinity;
  for(const sc of S.schools){
    if(!(sc.defs||[]).length) continue;
    if(schoolFilter&&sc.name!==schoolFilter) continue;
    for(const pt of (sc.periodTimes||[])){
      dayStart=Math.min(dayStart, toMin(pt.start));
      dayEnd=Math.max(dayEnd, toMin(pt.end));
    }
  }
  if(!isFinite(dayStart)){ container.innerHTML='<div class="empty">Okul saatleri tanımlı değil.</div>'; return; }
  dayStart=Math.floor(dayStart/10)*10;
  dayEnd=Math.ceil(dayEnd/10)*10;
  const STEP=10, cols=Math.max(1,Math.round((dayEnd-dayStart)/STEP));
  const ft=m=>String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0");
  const days=curSchool().days;
  const byDay={};
  for(const sc of S.schools){
    if(schoolFilter&&sc.name!==schoolFilter) continue;
    for(const l of sc.lessons||[]){
      const want=kind==="room"?l.room:(lessonTeachers(l).includes(entity)?entity:null);
      if(!want||want!==entity) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      (byDay[l.day]=byDay[l.day]||[]).push({course:l.course,className:l.className,school:sc.name,teachers:lessonTeachers(l),teacher:l.teacher,teacher2:l.teacher2,s:toMin(pt.start),e:toMin(pt.end)});
    }
  }
  const colIdx=t=>Math.max(0,Math.min(cols-1,Math.floor((t-dayStart)/STEP)));

  const wrap=document.createElement("div"); wrap.style.overflow="auto";
  const legend=document.createElement("div");
  legend.style.cssText="font-size:11px;color:var(--text2);margin-bottom:6px;";
  // Açıklama satırı gerçek okullardan üretilir; adlar koda gömülü değil.
  {
    const _roz=okulRozetleri(), _renk=["--badge-ok","--badge-err","--badge-info","--badge-warn"];
    let _h="", _i=0;
    // Boş okullar (tanımı ve dersi olmayan) açıklamada yer almasın — sekmelerdeki süzgecin aynısı.
    const _okullar=S.schools.filter(x=>(x.defs||[]).length||(x.lessons||[]).length)||S.schools;
    for(const _sc of (_okullar.length?_okullar:S.schools)){
      const _c=_renk[_i++%_renk.length];
      _h+=`<span style="background:var(${_c});color:var(${_c}t);padding:0 6px;border-radius:4px;margin-right:6px">[${esc(_roz[_sc.name]||"")}] ${esc(_sc.name)}</span>`;
    }
    legend.innerHTML=_h+'<span style="background:var(--badge-warn);color:var(--badge-warnt);padding:0 6px;border-radius:4px">sarı = öğle arası</span><span style="color:var(--text3);margin-left:6px">(üst skala 10 dk/dilim)</span>';
  }
  wrap.appendChild(legend);
  const tbl=document.createElement("table"); tbl.style.borderCollapse="collapse";
  const htr=document.createElement("tr");
  const fc=document.createElement("th");
  fc.textContent="Gün"; fc.style.cssText="position:sticky;left:0;z-index:3;background:var(--bg);color:var(--text);padding:4px 8px;border:1px solid var(--border);font-weight:600;";
  htr.appendChild(fc);
  for(let i=0;i<cols;i++){
    const th=document.createElement("th");
    th.textContent=ft(dayStart+i*STEP);
    th.title=`${ft(dayStart+i*STEP)}-${ft(dayStart+(i+1)*STEP)}`;
    const leftBold=(i%3===0)?'border-left:2px solid var(--surface-tint);':'';
    th.style.cssText=`font-size:7px;padding:2px 0;background:var(--text);color:var(--surface);border:1px solid var(--border);min-width:22px;height:26px;font-weight:500;${leftBold}`;
    htr.appendChild(th);
  }
  tbl.appendChild(htr);

  const dayShort=d=>d.slice(0,3); // Pazartesi→Paz, Salı→Sal, Çarşamba→Çar, Perşembe→Per, Cuma→Cum
  for(const day of days){
    const lessons=(byDay[day]||[]).sort((a,b)=>a.s-b.s);
    const tr=document.createElement("tr");
    const dc=document.createElement("td"); dc.className="day-cell"; dc.textContent=dayShort(day); dc.title=day; tr.appendChild(dc);
    const cells=new Array(cols).fill(0);
    for(const l of lessons){
      const c1=colIdx(l.s), c2=colIdx(Math.max(l.e-1,l.s));
      for(let i=c1;i<=c2;i++) cells[i]={lesson:l};
    }
    for(const lw of lunchWindowsForDay(day)){
      const c1=colIdx(lw.start), c2=colIdx(Math.max(lw.end-1,lw.start));
      for(let i=c1;i<=c2;i++){ if(cells[i]===0) cells[i]={lunch:true, school:lw.school}; }
    }
    // Teneffüs: her dersin ARDINDAN gelen standart ara (o okulun bir sonraki ders saati başlangıcına kadar;
    // arkada ders olmasa bile işaretlenir). Öğle arası ve gün sonu hariç.
    for(const l of lessons){
      const sc=S.schools.find(x=>x.name===l.school);
      const times=(sc&&sc.periodTimes)||[];
      const pIdx=times.findIndex(pt=>toMin(pt.end)===l.e);
      if(pIdx>=0 && pIdx+1<times.length){
        const nextStart=toMin(times[pIdx+1].start);
        if(nextStart>l.e && nextStart-l.e<=40){
          const c1=colIdx(l.e), c2=colIdx(Math.max(nextStart-1,l.e));
          for(let i=c1;i<=c2;i++){ if(cells[i]===0) cells[i]={tenef:true}; }
        }
      }
    }
    let i=0;
    while(i<cols){
      const c=cells[i];
      let j=i+1;
      if(c&&c.lunch){ while(j<cols&&cells[j]&&cells[j].lunch&&cells[j].school===c.school) j++; }
      else if(c&&c.lesson){ while(j<cols&&cells[j]&&cells[j].lesson===c.lesson) j++; }
      else if(c&&c.tenef){ while(j<cols&&cells[j]&&cells[j].tenef) j++; }
      else{ while(j<cols&&cells[j]===0) j++; }
      const td=document.createElement("td");
      td.colSpan=j-i;
      if(c===0){ td.className="grid-cell open"; td.style.minWidth="22px"; }
      else if(c&&c.tenef){
        td.className="grid-cell tenef";
        td.textContent="ARA";
        td.title="Teneffüs";
        td.style.minWidth=(j-i)*22+"px";
      }
      else if(c&&c.lunch){
        td.className="grid-cell lunch";
        td.textContent=`ÖĞLE ${(okulRozetleri()[c.school]||"")}`;
        td.title=`${c.school} öğle arası`;
        td.style.minWidth=(j-i)*22+"px";
      }
      else if(c&&c.lesson){
        const l=c.lesson;
        td.className="grid-cell lesson "+courseColor(l.course);
        const sbadge=okulRozetleri()[l.school]||"";
        td.innerHTML=`<div style="font-weight:700;line-height:1.2">[${sbadge}] ${esc(l.className)}</div><div style="font-size:8px;opacity:.85">${kind==="room"?esc(l.course):ft(l.s)+"-"+ft(l.e)}</div>`;
        td.title=`${l.school} ${l.className} ${l.course}${kind==="room"?` Öğr: ${tLabelArr(l.teachers||[l.teacher])}`:""}  ${ft(l.s)}-${ft(l.e)}`;
        td.style.minWidth=(j-i)*22+"px";
      }
      tr.appendChild(td);
      i=j;
    }
    tbl.appendChild(tr);
  }
  wrap.appendChild(tbl);
  container.appendChild(wrap);
}

// Tüm okulların mevcut çizelgesini kısıt ve tutarlılık açısından doğrular.
// Öğretmenlerin hatasız program yapabilmesi için dağıtım sonrası ve dosya açılışında kullanılır.
function verifySchedule(){
  const issues=[];
  const schools=S.schools.filter(s=>(s.defs||[]).length);
  const teacherSet=new Set(S.teachers||[]);
  for(const sc of schools){
    const cSet=new Set(sc.courses), clSet=new Set(sc.classes);
    const classBusy={}, teacherBusy={};
    const defHours={};
    for(const def of sc.defs||[]) defHours[refKey(def.course,defTeachers(def),defClasses(def))]=(defHours[refKey(def.course,defTeachers(def),defClasses(def))]||0)+Math.max(1,Number(def.hours)||1);
    const placed={};
    for(const l of sc.lessons||[]){
      const key=refKey(l.course,lessonTeachers(l),lessonClasses(l));
      placed[key]=(placed[key]||0)+1;
      if(!cSet.has(l.course)) issues.push(`Tanımsız ders: ${sc.name} ${l.className} ${l.course}`);
      for(const t of lessonTeachers(l)) if(!teacherSet.has(t)) issues.push(`Tanımsız öğretmen: ${sc.name} ${l.className} ${t}`);
      for(const cl of lessonClasses(l)) if(!clSet.has(cl)) issues.push(`Tanımsız sınıf: ${sc.name} ${l.course} ${cl}`);
      for(const cl of lessonClasses(l)){
        const k=`${cl}|${l.day}|${l.period}`;
        if(classBusy[k]) issues.push(`Sınıf çakışması: ${sc.name} ${l.day} ${l.period}.s ${cl} (${l.course})`);
        else classBusy[k]=1;
      }
      for(const t of lessonTeachers(l)){
        const tk=`${t}|${l.day}|${l.period}`;
        if(teacherBusy[tk]) issues.push(`Öğretmen çakışması: ${sc.name} ${l.day} ${l.period}.s ${t} (${l.course})`);
        else teacherBusy[tk]=1;
      }
      if((sc.schoolClosed||{})[`${l.day}|${l.period}`]) issues.push(`Kapalı (okul) saate ders: ${sc.name} ${l.className} ${l.course} ${l.day} ${l.period}.s`);
      for(const cl of lessonClasses(l)) if(sc.classClosed&&sc.classClosed[cl]&&sc.classClosed[cl][`${l.day}|${l.period}`]) issues.push(`Kapalı (sınıf) saate ders: ${sc.name} ${cl} ${l.course} ${l.day} ${l.period}.s`);
    }
    for(const [k,h] of Object.entries(defHours)){
      const p=placed[k]||0;
      if(p!==h) issues.push(`Eksik/Fazla saat: ${sc.name} ${k} → çizelgede ${p}, tanım ${h}`);
    }
    for(const def of sc.defs||[]){
      if(!def.blockFixed) continue;
      const ls=sc.lessons.filter(l=>refKey(l.course,lessonTeachers(l),lessonClasses(l))===refKey(def.course,defTeachers(def),defClasses(def)));
      if(ls.length>1){
        const byDay={};
        for(const l of ls)(byDay[l.day]=byDay[l.day]||[]).push(l.period);
        for(const [day,pers] of Object.entries(byDay)){
          pers.sort((a,b)=>a-b);
          for(let i=1;i<pers.length;i++) if(pers[i]!==pers[i-1]+1){ issues.push(`Tek blok değil: ${sc.name} ${def.className} ${def.course} ${day} [${pers.join(',')}]`); break; }
        }
      }
    }
  }
  const dayMap=new Map();
  // Derslik çakışması: aynı derslik aynı saat aralığında yalnız bir derste kullanılabilir (tüm okullar).
  // Okulların ders saatleri farklı olabileceğinden saat aralığı örtüşmesine göre kontrol edilir.
  const roomIntervals={};
  for(const sc of schools){
    for(const l of sc.lessons||[]){
      if(!l.room) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const k=`${l.room}|${l.day}`;
      (roomIntervals[k]=roomIntervals[k]||[]).push({start:toMin(pt.start),end:toMin(pt.end),label:`${sc.name} ${l.className} ${l.course}`});
    }
  }
  for(const [k,ints] of Object.entries(roomIntervals)){
    const [room,day]=k.split('|');
    for(let i=0;i<ints.length;i++) for(let j=i+1;j<ints.length;j++){
      if(ints[i].start<ints[j].end&&ints[j].start<ints[i].end){
        issues.push(`Derslik çakışması: ${room} ${day} (${ints[i].label} ↔ ${ints[j].label})`);
      }
    }
  }
  for(const sc of schools){
    for(const l of sc.lessons||[]){
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const iv={start:toMin(pt.start),end:toMin(pt.end),school:sc.name,course:l.course,className:l.className};
      for(const t of lessonTeachers(l)){
        const k=`${t}|${l.day}`;
        if(!dayMap.has(k)) dayMap.set(k,[]);
        dayMap.get(k).push(iv);
      }
    }
  }
  for(const [key,ints] of dayMap){
    const [teacher,day]=key.split('|');
    ints.sort((a,b)=>a.start-b.start);
    for(let i=0;i<ints.length;i++) for(let j=i+1;j<ints.length;j++){
      if(ints[i].start<ints[j].end&&ints[j].start<ints[i].end) issues.push(`Çapraz çakışma: ${teacher} ${day} (${ints[i].school} ${ints[i].course} ↔ ${ints[j].school} ${ints[j].course})`);
    }
    for(let i=1;i<ints.length;i++){
      if(ints[i-1].school===ints[i].school) continue;
      const gap=ints[i].start-ints[i-1].end;
      if(gap<10) issues.push(`Teneffüs<10dk: ${teacher} ${day} ${ints[i-1].school} ${ints[i-1].course} → ${ints[i].school} ${ints[i].course}`);
    }
    const lunchWin=lunchWindowsForDay(day);
    if(lunchWin.length){
      const hasLunch=ints=>lunchWin.some(lw=>!ints.some(iv=>iv.start<lw.end&&lw.start<iv.end));
      if(!hasLunch(ints)) issues.push(`Öğle arası yok: ${teacher} ${day}`);
    }
  }
  return issues;
}

// ─── ARAMA BÜTÇESİ ───
// SOLVE_SOFT_MS ve COMPLETE_BUDGET_MS artık DURDURUCU DEĞİLDİR; yalnız YUMUŞAK UYARI EŞİĞİDİR.
// Eşik geçilince progress metnine ⏳ eklenir ve kullanıcıya "Bitir ile en iyiyi kaydedebilirsin"
// bilgisi gösterilir; arama tamamı yerleşene ya da kullanıcı Bitir'e basana kadar DEVAM EDER.
// GERÇEK durdurucu yalnız HARD_STOP_MS (1 saat) güvenlik ağıdır; pratikte hiç devreye girmemelidir.
let SOLVE_SOFT_MS=180000;            // yumuşak eşik: sıfırdan dağıtım 3 dk sonra ⏳ uyarısı (arama durmaz)
// "Eksikleri Tamamla" yıkıcı değildir (mevcut program korunur) ve hedeflidir.
// Ölçüm: 180 sn'de +1 saat, 371 sn'de +4 saat bulunuyor.
const COMPLETE_BUDGET_MS=600000;        // yumuşak eşik: eksikleri tamamla 10 dk sonra ⏳ uyarısı (arama durmaz)
// Ana arama tıkanınca (N denemedir iyileşme yok) sıfırdan aramaya devam etmek yerine
// iyileştirme fazlarına ve otomatik onarım turuna geçilir: ölçümde boşluğu kapatan
// şey rastgele yeni denemeler değil, mevcut yerleşimden artımlı onarım oldu.
// Tıkanma ZAMANA bağlıdır, deneme sayısına değil: bu veride bir deneme ~8 sn sürüyor,
// 120 denemelik eşik 16 dakika beklemek demekti. 90 sn iyileşme yoksa strateji değişir.
// İşçide (Web Worker) arayüzü canlı tutma derdi yok; orada çok daha uzun arayabiliriz.
// Ana iş parçacığında kısa tutulur ki sayfa yanıt vermeye devam etsin.
let STALL_MS=90000;
/* Onarım turlarının tıkanma eşiği AYRI tutuluyor. Sebep ölçülmüş: bu veride sıfırdan
   arama hiçbir bütçeyle tamamlanmıyor, işi bitiren onarım + bitiriş fazı. Tek eşik
   kullanınca işçide sıfırdan faz 7 dakika bekliyor ve asıl kazandıran faza geç geçiliyordu.
   Sıfırdan faz erken pes etsin, onarım uzun sürsün. */
let REPAIR_STALL_MS=270000;
let HARD_STOP_MS=3600000;             // güvenlik ağı: 1 saatte zorunlu dur (normalde hiç devreye girmez)

/* ============================================================
   ÇÖZÜCÜ (kısıt-tabanlı çoklu deneme)
   ============================================================ */
async function solve(opts={}){
  if(!curSchool().defs.length){toast("Hiç ders tanımlanmamış. Önce Dersler sekmesinden ders ekleyin.","err");return null;}

  const school=curSchool();
  const days=school.days;
  const periods=school.periods;
  const validation=validateScheduleData(school);
  if(validation.errors.length){
    const result={totalBlocks:0,placedBlocks:0,totalHours:0,placedHours:0,
      forcedFailed:[],failed:[],allFailed:[],capacityIssues:[],validationErrors:validation.errors,validationWarnings:validation.warnings,flexible:false};
    showScheduleResult(result);
    toast(`${validation.errors.length} veri hatası var. Dağıtım başlamadı.`,"err");
    return result;
  }
  const flexible=!!opts.flexibleBlocks;
  // Yumuşak eşik + güvenlik ağı: arama durmaz; softAt yalnız ⏳ uyarısı için, hardStop yalnız felaket sigortası.
  const startedAt=Date.now();
  const softAt=startedAt+SOLVE_SOFT_MS;
  const hardStop=startedAt+HARD_STOP_MS;
  // Öğretmen yükü: öğretmenin tüm okullardaki toplam ders saati (sıralama kırıcısı için)
  // Yük TÜM okullardan hesaplanır: öğretmenin diğer okuldaki dersleri de duvar saatinde
  // yer kapattığı için tek okulluk dağıtımda da zorluğu artırır.
  const teacherLoad=teacherLoadMap(S.schools.filter(s=>(s.defs||[]).length)).load;
  function blockParts(hours,maxBlk,fixed){
    const parts=[];
    let rem=hours;
    if(fixed){
      parts.push(hours); return parts;
    }
    if(!flexible||maxBlk<=1){
      while(rem>0){const sz=Math.min(maxBlk,rem);parts.push(sz);rem-=sz;}
      return parts;
    }
    const mode=Math.random();
    if(mode<0.34){
      while(rem>0){const sz=Math.min(maxBlk,rem);parts.push(sz);rem-=sz;}
    }else if(mode<0.72){
      parts.push(Math.min(maxBlk,rem)); rem-=parts[0];
      while(rem>0){parts.push(1);rem--;}
    }else{
      while(rem>0){parts.push(1);rem--;}
    }
    return parts;
  }

  // Alternatif blok bölüşümleri; kompakt olan önce gelir (2+2+1 -> 2+1+1+1 -> 1+1+1+1+1)
  const altsCache={};
  function altsFor(def){
    if(altsCache[def.id]) return altsCache[def.id];
    const hours=Math.max(1,Number(def.hours)||1);
    if(def.blockFixed){ altsCache[def.id]=[[hours]]; return altsCache[def.id]; }
    const maxBlk=Math.max(1,Number(def.block)||1);
    altsCache[def.id]=altDecompositions(hours,maxBlk).slice().sort((a,b)=>a.length-b.length);
    return altsCache[def.id];
  }

  // Hiç yerleştirilemeyecek dersler: uygun saat yoksa o ders imkansızdır
  const noCandidateDefs=[],noCandidateDefIds=new Set();
  for(const def of school.defs){
    const testSize=def.blockFixed?Math.max(1,Number(def.hours)||1):1;
    const b1={...def,size:testSize};
    let has=false;
    for(const day of days){ for(let start=1;start<=periods-testSize+1;start++){ if(baseCanPlace(b1,day,start)){ has=true; break; } } if(has) break; }
    if(!has){ noCandidateDefs.push(def); noCandidateDefIds.add(def.id); }
  }
  const activeDefs=school.defs.filter(d=>!noCandidateDefIds.has(d.id));
  if(!activeDefs.length&&!noCandidateDefs.length){toast("Ders yok.","err");return null;}
  if(!S.teachers.length||!school.classes.length){toast("Sınıf veya öğretmen yok.","err");return null;}
  solveCancelled=false;

  // Başlangıç blok seti (kapasite hesabı ve toplamlar için)
  const allBlocks=[];
  for(const g of activeDefs){
    const maxBlk=Math.max(1,Number(g.block)||1);
    let part=1;
    for(const sz of blockParts(Math.max(1,Number(g.hours)||1),maxBlk,g.blockFixed)){
      allBlocks.push({...g,size:sz,bid:uid(),defId:g.id,partNo:part++});
    }
  }

  const ck=(cl,d,p)=>`${cl}|${d}|${p}`;
  const tk=(t,d,p)=>`${t}|${d}|${p}`;
  const dk=(d,p)=>`${d}|${p}`;
  const rk=(r,d,p)=>`${r}|${d}|${p}`;
  const blockKey=b=>`${b.course}|${b.teacher}|${b.className}`;
  // "Aynı dersin parçaları" kısıtları (spreadCourse / courseGap) TANIM (def) bazlıdır:
  // aynı öğretmen-sınıf-ders tanımının blokları günlere yayılır; aynı adlı FARKLI tanımlar
  // (örn. iki ayrı İNGİLİZCE tanımı / farklı öğretmen) birbirini engellemez.
  const defKey=b=>b.defId||blockKey(b);
  const blockLabel=b=>`${b.className} ${b.course} (${tLabelArr(b.teachers||[b.teacher])})`;

  // Diğer okullardaki derslik kullanımları (derslikler tüm okulların ortak mekânıdır;
  // aynı derslik aynı anda yalnız bir derste kullanılabilir). Okulların ders saatleri
  // farklı olabildiğinden çakışma ZAMAN bazlı kontrol edilir (saat aralığı örtüşmesi).
  const roomBusyOther={}; // room|day -> [aralık]
  for(const sc of S.schools){
    if(sc.id===S.currentSchool) continue;
    for(const l of sc.lessons||[]){
      if(!l.room) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const k=`${l.room}|${l.day}`;
      (roomBusyOther[k]=roomBusyOther[k]||[]).push({start:toMin(pt.start),end:toMin(pt.end)});
    }
  }

  // ─── Yeni kısıtlar (dağıtım öncesi özelleştirilir) ───
  const C=normConstraints(curSchool().constraints);
  const courseGap=Math.max(0,Math.floor(Number(C.courseGap)||0));
  const minBreak=Math.max(0,Math.floor(Number(C.minBreak)||0));
  const maxSameRun=Math.max(0,Math.floor(Number(C.maxSameRun)||0));

  // Öğle arası pencereleri (gün bazlı): kullanıcının belirlediği schoolLunch veya otomatik tespit
  const lunchWinByDay={};
  for(const day of days) lunchWinByDay[day]=lunchWindowsForDay(day);
  const requireLunch=!!C.requireLunch && Object.values(lunchWinByDay).some(w=>w.length>0);
  // Diğer okullardaki sabit derslerin öğretmen|gün -> [aralık] haritası
  const otherInts={};
  for(const sc of S.schools){
    if(sc.id===S.currentSchool) continue;
    for(const l of sc.lessons||[]){
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      for(const t of lessonTeachers(l)){
        const k=`${t}|${l.day}`;
        (otherInts[k]=otherInts[k]||[]).push({start:toMin(pt.start),end:toMin(pt.end),schoolId:sc.id});
      }
    }
  }
  function blockInterval(b,start){
    const pt=school.periodTimes;
    const p0=start, p1=start+b.size-1;
    if(!pt[p0-1]||!pt[p1-1]) return null;
    return {start:toMin(pt[p0-1].start), end:toMin(pt[p1-1].end), schoolId:school.id};
  }
  function teacherDayIntervals(state,t,day){
    const cur=(state.teacherDayIntervals||{})[`${t}|${day}`]||[];
    const oth=otherInts[`${t}|${day}`]||[];
    return cur.concat(oth);
  }
  // Teneffüs şartı SADECE farklı okullar arası geçişlerde geçerlidir.
  // Aynı okul içinde ders saatleri arasında zaten ara vardır.
  function breaksBreak(ints,bi){
    for(const iv of ints){
      if(iv.schoolId===bi.schoolId) continue;
      if(iv.end>bi.start-minBreak && iv.start<bi.end+minBreak) return true;
    }
    return false;
  }
  function hasFreeLunch(ints,bi,day){
    const win=lunchWinByDay[day];
    if(!win||!win.length) return true; // o gün öğle arası tanımlı değilse şart yok
    const all=bi?ints.concat([bi]):ints;
    for(const lw of win){
      let free=true;
      for(const iv of all){ if(iv.start<lw.end&&lw.start<iv.end){ free=false; break; } }
      if(free) return true;
    }
    return false;
  }
  const pairConflicts={};
  for(const pr of (C.coursePairs||[])){
    if(!pr.a||!pr.b||pr.a===pr.b) continue;
    (pairConflicts[pr.a]=pairConflicts[pr.a]||new Set()).add(pr.b);
    (pairConflicts[pr.b]=pairConflicts[pr.b]||new Set()).add(pr.a);
  }
  const courseBlockCount={};
  for(const b of allBlocks) courseBlockCount[defKey(b)]=(courseBlockCount[defKey(b)]||0)+1;
  // bid -> blok: ust uste kurali komsu hucredeki blogun ders/ogretmenini gormek zorunda
  const blockRegS={}; for(const b of allBlocks) blockRegS[b.bid]=b;
  // b (day,start) konumuna konarsa ayni sinifta olusacak "akraba" ardisik saat sayisi
  function sameRunLen(state,b,day,start){
    let en=0;
    for(const cl of blockClasses(b)){
      let sol=0;
      for(let p=start-1;p>=1;p--){ const o=blockRegS[state.classBusy[ck(cl,day,p)]]; if(!o||o.bid===b.bid||!sameRunFamily(o,b)) break; sol++; }
      let sag=0;
      for(let p=start+b.size;p<=periods;p++){ const o=blockRegS[state.classBusy[ck(cl,day,p)]]; if(!o||o.bid===b.bid||!sameRunFamily(o,b)) break; sag++; }
      if(sol+b.size+sag>en) en=sol+b.size+sag;
    }
    return en;
  }
  const teacherCourseSet={};
  for(const b of allBlocks) for(const t of (b.teachers||[b.teacher])) (teacherCourseSet[t]=teacherCourseSet[t]||new Set()).add(b.course);
  function blockPriority(b){
    if(C.spreadCourse && (courseBlockCount[defKey(b)]||0)>1) return true;
    if(C.spreadTeacher && (b.teachers||[b.teacher]).some(t=>(teacherCourseSet[t]?.size||0)>1)) return true;
    if(pairConflicts[b.course]) return true;
    return false;
  }
  function constraintViolation(state,b,day,start){
    if(maxSameRun>0 && start!==undefined && sameRunLen(state,b,day,start)>maxSameRun) return "maxSameRun";
    if(C.spreadCourse && (state.courseDayCount[`${defKey(b)}|${day}`]||0)>0) return "spreadCourse";
    if(courseGap>0 && start!==undefined){
      const slots=state.courseSlots[`${defKey(b)}|${day}`];
      if(slots){
        for(const s of slots){
          if(start < s.start+s.size+courseGap && s.start < start+b.size+courseGap) return "courseGap";
        }
      }
    }
    if(C.spreadTeacher){
      for(const t of (b.teachers||[b.teacher])){
        const set=state.teacherDayCourses[`${t}|${day}`];
        if(set && [...set].some(c2=>c2!==b.course)) return "spreadTeacher";
      }
    }
    const pcs=pairConflicts[b.course];
    if(pcs && pcs.size){
      const set=state.dayCourseSet[`${b.className}|${day}`];
      if(set){ for(const c2 of pcs){ if(set.has(c2)) return "coursePair"; } }
    }
    if(minBreak>0 || requireLunch){
      const bi=blockInterval(b,start);
      if(bi){
        const teachers=b.teachers&&b.teachers.length?b.teachers:[b.teacher];
        for(const t of teachers){
          const ints=teacherDayIntervals(state,t,day);
          if(minBreak>0 && breaksBreak(ints,bi)) return "break";
          if(requireLunch && !hasFreeLunch(ints,bi,day)) return "lunch";
        }
      }
    }
    return null;
  }
  function countViolations(placements){
    const dayInfo={};
    for(const p of Object.values(placements)){
      const b=p.block, day=p.day;
      if(!dayInfo[day]) dayInfo[day]={courseCount:{},teacherCourses:{},courseSlots:{},dayCourses:{}};
      dayInfo[day].courseCount[defKey(b)]=(dayInfo[day].courseCount[defKey(b)]||0)+1;
      for(const t of (b.teachers||[b.teacher])) (dayInfo[day].teacherCourses[t]=dayInfo[day].teacherCourses[t]||new Set()).add(b.course);
      (dayInfo[day].courseSlots[defKey(b)]=dayInfo[day].courseSlots[defKey(b)]||[]).push({start:p.start,size:b.size});
      (dayInfo[day].dayCourses[b.className]=dayInfo[day].dayCourses[b.className]||new Set()).add(b.course);
    }
    let spreadCourseV=0,spreadTeacherV=0,coursePairV=0,courseGapV=0,breakV=0,lunchV=0;
    for(const day in dayInfo){
      const di=dayInfo[day];
      if(C.spreadCourse) for(const c in di.courseCount) if(di.courseCount[c]>1) spreadCourseV+=di.courseCount[c]-1;
      if(C.spreadTeacher) for(const t in di.teacherCourses) if(di.teacherCourses[t].size>1) spreadTeacherV+=di.teacherCourses[t].size-1;
      if(courseGap>0){
        for(const c in di.courseSlots){
          const slots=di.courseSlots[c].sort((a,b)=>a.start-b.start);
          for(let i=1;i<slots.length;i++){
            const gap=slots[i].start-(slots[i-1].start+slots[i-1].size);
            if(gap<courseGap) courseGapV+=courseGap-gap;
          }
        }
      }
      if(C.coursePairs&&C.coursePairs.length){
        for(const cl in di.dayCourses){
          const set=di.dayCourses[cl];
          for(const pr of C.coursePairs){ if(pr.a!==pr.b&&set.has(pr.a)&&set.has(pr.b)) coursePairV++; }
        }
      }
    }
    if(minBreak>0||requireLunch){
      // öğretmen|gün -> [aralık] (bu okulun yerleşimleri + diğer okullar)
      const tInts={};
      for(const p of Object.values(placements)){
        const b=p.block, day=p.day;
        const bi=blockInterval(b,p.start);
        if(!bi) continue;
        for(const t of (b.teachers||[b.teacher])){
          const k=`${t}|${day}`;
          (tInts[k]=tInts[k]||[]).push(bi);
        }
      }
      for(const k of Object.keys(otherInts)) (tInts[k]=(tInts[k]||[])).push(...otherInts[k]);
      for(const [k,ints] of Object.entries(tInts)){
        if(ints.length<2) continue;
        ints.sort((a,b)=>a.start-b.start);
        if(minBreak>0){
          for(let i=1;i<ints.length;i++){
            const a=ints[i-1], b=ints[i];
            if(a.schoolId===b.schoolId) continue; // aynı okul içi ara zaten var
            const gap=b.start-a.end;
            if(gap<minBreak) breakV+=minBreak-gap;
          }
        }
        if(requireLunch){
          const day=k.split('|')[1];
          const free=hasFreeLunch(ints,undefined,day);
          if(!free) lunchV++;
        }
      }
    }
    return {spreadCourseV,spreadTeacherV,coursePairV,courseGapV,breakV,lunchV,total:spreadCourseV+spreadTeacherV+coursePairV+courseGapV+breakV+lunchV};
  }

  showScheduleProgress("Dağıtım hazırlanıyor...",0);

  function baseCanPlace(b,day,start){
    for(let o=0;o<b.size;o++){
      const pp=start+o;
      if(pp>periods) return false;
      for(const cl of blockClasses(b)) if(!classOpen(cl,day,pp)) return false;
      for(const t of (b.teachers||[b.teacher])) if(!teacherOpen(t,day,pp)) return false;
      if(b.avail && b.avail[`${day}|${pp}`]===false) return false; // derse özel kapalı saat
    }
    return true;
  }

  function openClassSlots(className){
    let n=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(classOpen(className,day,p)) n++;
    return n;
  }

  function openTeacherSlots(teacher){
    let n=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(teacherOpen(teacher,day,p)) n++;
    return n;
  }

  // Öğretmenin haftalık gerçek ders sınırı: her gün açık olabildiği saatlerden,
  // ders verdiği sınıflardan en az birinin de açık olduğu saatler düşülerek hesaplanır.
  // (Örn. tüm sınıflar Perşembe 6-7 kapalıysa öğretmen o gün en fazla 6 saat ders verebilir.)
  function teacherWeeklyCap(teacher, classNames){
    let cap=0;
    for(const day of days){
      let tOpen=0,anyOpen=0;
      for(let p=1;p<=periods;p++){
        if(!teacherOpen(teacher,day,p)) continue;
        tOpen++;
        for(const cl of classNames){ if(classOpen(cl,day,p)){ anyOpen++; break; } }
      }
      cap+=Math.min(tOpen,anyOpen);
    }
    return cap;
  }

  function findCapacityIssues(blocks){
    const classNeed={},teacherNeed={},teacherClasses={},issues=[];
    for(const b of blocks){
      classNeed[b.className]=(classNeed[b.className]||0)+b.size;
      for(const t of (b.teachers||[b.teacher])){
        teacherNeed[t]=(teacherNeed[t]||0)+b.size;
        (teacherClasses[t]=teacherClasses[t]||new Set()).add(b.className);
      }
    }
    for(const [name,need] of Object.entries(classNeed)){
      const open=openClassSlots(name);
      if(need>open) issues.push({type:"Sınıf",name,need,open,extra:need-open});
    }
    for(const [name,need] of Object.entries(teacherNeed)){
      const open=teacherWeeklyCap(name,teacherClasses[name]);
      if(need>open) issues.push({type:"Öğretmen",name,need,open,extra:need-open});
    }
    return issues;
  }

  const capacityIssues=findCapacityIssues(allBlocks);
  const forcedFailed=[];
  const forcedDefIds=new Set(noCandidateDefIds);
  for(const def of noCandidateDefs){
    forcedFailed.push({...def,size:Math.max(1,Number(def.hours)||1),reason:"Bu ders için hiç uygun saat yok (sınıf ve öğretmen açık saatleri çakışmıyor)."});
  }
  for(const issue of capacityIssues){
    let extra=issue.extra;
    const candidates=activeDefs
      .filter(d=>!forcedDefIds.has(d.id) && (issue.type==="Sınıf"?defClasses(d).includes(issue.name):defTeachers(d).includes(issue.name)))
      .sort((a,b)=> (Math.max(1,Number(a.hours)||1)-Math.max(1,Number(b.hours)||1)) || (a.id<b.id?-1:1));
    for(const d of candidates){
      if(extra<=0) break;
      forcedDefIds.add(d.id);
      forcedFailed.push({...d,size:Math.max(1,Number(d.hours)||1),reason:`${issue.type} kapasitesi aşılıyor: ${issue.need}/${issue.open}`});
      extra-=Math.max(1,Number(d.hours)||1);
    }
  }
  const activeDefsList=activeDefs.filter(d=>!forcedDefIds.has(d.id));
  const blockCountBase=allBlocks.filter(b=>!forcedDefIds.has(b.defId)).length;

  function canPlace(state,b,slot){
    if(b.room){
      const bi=blockInterval(b,slot.start);
      if(bi){ const others=roomBusyOther[`${b.room}|${slot.day}`]||[]; for(const iv of others){ if(iv.start<bi.end&&bi.start<iv.end) return false; } }
    }
for(let o=0;o<b.size;o++){
      const p=slot.start+o;
      for(const cl of blockClasses(b)) if(state.classBusy[ck(cl,slot.day,p)]) return false;
      for(const t of (b.teachers||[b.teacher])) if(state.teacherBusy[tk(t,slot.day,p)]) return false;
      if(b.room && state.roomBusy[rk(b.room,slot.day,p)]) return false;
    }
    return true;
  }

  function putBlock(state,b,slot){
    state.placements[b.bid]={block:b,day:slot.day,start:slot.start};
    for(let o=0;o<b.size;o++){
      const p=slot.start+o;
      for(const cl of blockClasses(b)) state.classBusy[ck(cl,slot.day,p)]=b.bid;
      for(const t of (b.teachers||[b.teacher])) state.teacherBusy[tk(t,slot.day,p)]=b.bid;
      if(b.room) state.roomBusy[rk(b.room,slot.day,p)]=b.bid;
      state.cellLoad[dk(slot.day,p)]=(state.cellLoad[dk(slot.day,p)]||0)+1;
      state.classDay[`${b.className}|${slot.day}`]=(state.classDay[`${b.className}|${slot.day}`]||0)+1;
      for(const t of (b.teachers||[b.teacher])) state.teacherDay[`${t}|${slot.day}`]=(state.teacherDay[`${t}|${slot.day}`]||0)+1;
      state.courseDay[`${defKey(b)}|${slot.day}`]=(state.courseDay[`${defKey(b)}|${slot.day}`]||0)+1;
    }
    state.courseDayCount[`${defKey(b)}|${slot.day}`]=(state.courseDayCount[`${defKey(b)}|${slot.day}`]||0)+1;
    (state.courseSlots[`${defKey(b)}|${slot.day}`]=state.courseSlots[`${defKey(b)}|${slot.day}`]||[]).push({start:slot.start,size:b.size});
    for(const t of (b.teachers||[b.teacher])) (state.teacherDayCourses[`${t}|${slot.day}`]=state.teacherDayCourses[`${t}|${slot.day}`]||new Set()).add(b.course);
    (state.dayCourseSet[`${b.className}|${slot.day}`]=state.dayCourseSet[`${b.className}|${slot.day}`]||new Set()).add(b.course);
    const bi=blockInterval(b,slot.start);
    if(bi){
      for(const t of (b.teachers||[b.teacher])) (state.teacherDayIntervals[`${t}|${slot.day}`]=state.teacherDayIntervals[`${t}|${slot.day}`]||[]).push(bi);
    }
  }

  function scoreSlot(state,b,slot){
    let score=0;
    const clsDay=state.classDay[`${b.className}|${slot.day}`]||0;
    const tchDay=Math.max(...(b.teachers||[b.teacher]).map(t=>state.teacherDay[`${t}|${slot.day}`]||0));
    const sameCourseDay=state.courseDay[`${defKey(b)}|${slot.day}`]||0;
    score+=sameCourseDay*180;
    score+=Math.max(0,clsDay-5)*18;
    score+=Math.max(0,tchDay-5)*14;
    score+=slot.start*0.9;
    score+=days.indexOf(slot.day)*0.15;
    for(let o=0;o<b.size;o++) score+=(state.cellLoad[dk(slot.day,slot.start+o)]||0)*0.4;
    return score+Math.random()*2.5;
  }

  const candCache={};
  function blockCandidates(defId,size){
    const k=defId+"|"+size;
    if(candCache[k]) return candCache[k];
    const def=activeDefs.find(d=>d.id===defId);
    const b={...def,size};
    const list=[];
    for(const day of days){ for(let start=1;start<=periods-size+1;start++){ if(baseCanPlace(b,day,start)) list.push({day,start}); } }
    candCache[k]=list;
    return list;
  }
  const defFailCount={};
  // Kalıcı zor-ders hafızası: önceki dağıtımlarda yerleşemeyenler ilk denemeden öne alınır
  let bestFailedDefs=new Set(loadHardDefs());

  function runAttempt(attempt){
    // Bloklar bu deneme için yeniden oluşturulur: yerleşemeyen / yerleşmesi zor dersler için
    // farklı blok bölüşümleri sırayla denenir (2+2+1 -> 2+1+1+1 -> 1+1+1+1+1)
    const blocks=[];
    for(const g of activeDefsList){
      const hours=Math.max(1,Number(g.hours)||1);
      const maxBlk=Math.max(1,Number(g.block)||1);
      let parts;
      if(!flexible||maxBlk<=1){
        parts=blockParts(hours,maxBlk,g.blockFixed);
      }else{
        const alts=altsFor(g);
        const hardNow=bestFailedDefs.has(g.id)||(defFailCount[g.id]||0)>0;
        if(hardNow){
          parts=alts[attempt % alts.length];
        }else{
          // Sorunsuz tanımlar en az parçalı bölüşümü (alts[0]) korur; yalnız arama tıkandığında (stuck>150) rastgele bölüşüme geçilir
          parts= stuckNow>150 ? alts[Math.floor(Math.random()*alts.length)] : alts[0];
        }
      }
      let part=1;
      for(const sz of parts){
        blocks.push({...g,size:sz,bid:uid(),defId:g.id,partNo:part++,candidates:blockCandidates(g.id,sz)});
      }
    }
    const state={
      placements:{},classBusy:{},teacherBusy:{},roomBusy:{},cellLoad:{},
      classDay:{},teacherDay:{},courseDay:{},
      courseDayCount:{},courseSlots:{},teacherDayCourses:{},dayCourseSet:{},teacherDayIntervals:{}
    };
    const placed=[],failed=[];
    // Önce yerleşemeyen / yerleşme ihtimali düşük dersler yerleştirilir
    // Blok yükü: bloğun öğretmenlerinin toplam ders saati (en büyüğü) — yükü fazla olan önce yerleşir
    const loadOf=b=>Math.max(0,...(b.teachers||[b.teacher]).map(t=>teacherLoad[t]||0));
    const ordered=[...blocks].sort((a,b)=>{
      const fx=bestFailedDefs.has(a.defId)?1:0, fy=bestFailedDefs.has(b.defId)?1:0;
      if(fx!==fy) return fy-fx;
      const cx=defFailCount[a.defId]||0, cy=defFailCount[b.defId]||0;
      if(cx!==cy) return cy-cx;
      const pa=blockPriority(a)?1:0, pb=blockPriority(b)?1:0;
      if(pa!==pb) return pb-pa;
      if(a.candidates.length!==b.candidates.length) return a.candidates.length-b.candidates.length;
      const la=loadOf(a), lb=loadOf(b); if(la!==lb) return lb-la;
      if(a.size!==b.size) return a.size-b.size;
      return Math.random()-0.5;
    });
    // En-kısıtlı-önce (most-constrained-first): her adımda GÜNCEL durumda uygun saati en az olan
    // blok yerleştirilir. Böylece yerleşmesi zor (tek saatlik, az boş yeri kalan) dersler önce
    // yerleşir; sonraki adımlar kalan boşluklara uyum sağlar. Maliyet düşüktür: yalnızca
    // öğretmen/sınıf/derslik paylaşan blokların sayısı yeniden hesaplanır.
    const remaining=[...ordered];
    const countViable=b=>{ let n=0; for(const slot of b.candidates){ if(canPlace(state,b,slot)&&!constraintViolation(state,b,slot.day,slot.start)) n++; } return n; };
    const viableCache=new Map(), dirty=new Set(remaining.map(b=>b.bid));
    while(remaining.length){
      let bi=0, bestC=Infinity;
      for(let i=0;i<remaining.length;i++){
        const b=remaining[i];
        if(dirty.has(b.bid)){ viableCache.set(b.bid,countViable(b)); dirty.delete(b.bid); }
        const c=viableCache.get(b.bid);
        if(c<bestC){ bestC=c; bi=i; }
      }
      const b=remaining[bi];
      remaining.splice(bi,1);
      const viable=b.candidates.filter(slot=>canPlace(state,b,slot) && !constraintViolation(state,b,slot.day,slot.start));
      if(!viable.length){ failed.push(b); defFailCount[b.defId]=(defFailCount[b.defId]||0)+1; continue; }
      viable.sort((x,y)=>scoreSlot(state,b,x)-scoreSlot(state,b,y));
      const pickLimit=attempt<20?1:Math.min(flexible?9:4,viable.length);
      const slot=viable[Math.floor(Math.random()*pickLimit)];
      putBlock(state,b,slot);
      placed.push(b);
      for(const rb of remaining){
        const shared=(rb.teachers||[rb.teacher]).some(t=>(b.teachers||[b.teacher]).includes(t));
        if(shared||rb.className===b.className||(b.room&&rb.room===b.room)) dirty.add(rb.bid);
      }
    }
    return {state,placed,failed};
  }

  function resultCost(result){
    let cost=result.failed.length*100000;
    const courseDays={};
    for(const p of Object.values(result.state.placements)){
      const key=defKey(p.block);
      if(!courseDays[key]) courseDays[key]={};
      courseDays[key][p.day]=(courseDays[key][p.day]||0)+1;
      cost+=p.start*0.2;
    }
    for(const daysMap of Object.values(courseDays)){
      for(const cnt of Object.values(daysMap)) if(cnt>1) cost+=(cnt-1)*500;
    }
    cost+=countViolations(result.state.placements).total*400;
    return cost;
  }

  function blankState(){
    return {placements:{},classBusy:{},teacherBusy:{},roomBusy:{},cellLoad:{},
      classDay:{},teacherDay:{},courseDay:{},courseDayCount:{},courseSlots:{},teacherDayCourses:{},dayCourseSet:{},teacherDayIntervals:{}};
  }
  function stateFromPlacements(placements){
    const st=blankState();
    for(const pid in placements){ const pl=placements[pid]; putBlock(st,pl.block,{day:pl.day,start:pl.start}); }
    return st;
  }
  // Bir dersin saatlerini farklı blok kombinasyonlarına böler (örn. 5s -> [2,2,1],[2,1,1,1],[1,1,1,1,1])
  function altDecompositions(hours,maxBlk){
    const res=[];
    function rec(rem,path){
      if(rem===0){ res.push([...path]); return; }
      for(let s=Math.min(maxBlk,rem); s>=1; s--) rec(rem-s,path.concat(s));
    }
    rec(hours,[]);
    // Daha ince (daha çok 1'lik) bölünmüşler önce denensin — yerleşme şansı daha yüksek
    res.sort((a,b)=>b.length-a.length || b[0]-a[0]);
    return res.slice(0,80);
  }
  // Bir bloğu yerleştirir; sığmazsa başka bir dersi yerinden oynatarak (kick/min-conflicts) yer açar
  let forceDeadline=0;
  function forcePlace(placements, block, depth){
    if(Date.now()>forceDeadline) return null;
    depth=depth||0;
    const st=stateFromPlacements(placements);
    const cands=[];
    for(const day of days){ for(let start=1;start<=periods-block.size+1;start++){ if(baseCanPlace(block,day,start)) cands.push({day,start}); } }
    let via=cands.filter(s=>canPlace(st,block,s)&&!constraintViolation(st,block,s.day,s.start));
    if(via.length){ const np={...placements}; const s=via.sort((x,y)=>scoreSlot(st,block,x)-scoreSlot(st,block,y))[0]; np[block.bid]={block,day:s.day,start:s.start}; return np; }
    if(depth>=2) return null;
    for(const slot of cands){
      const occ=[];
      for(let o=0;o<block.size;o++){ const p=slot.start+o;
        for(const cl of blockClasses(block)){ const cb=st.classBusy[ck(cl,slot.day,p)]; if(cb&&cb!==block.bid) occ.push(cb); }
        for(const t of (block.teachers||[block.teacher])){ const tb=st.teacherBusy[tk(t,slot.day,p)]; if(tb&&tb!==block.bid) occ.push(tb); }
      }
      // Önce tek saatlik blokları tekmele: yer değiştirmeleri kolay olduğundan daha iyi sonuç verir
      const kickList=[...new Set(occ)].sort((a,b)=>(placements[a]&&placements[a].block.size||9)-(placements[b]&&placements[b].block.size||9));
      for(const obid of kickList){
        const op=placements[obid]; if(!op) continue;
        const rem={...placements}; delete rem[obid];
        const after1=forcePlace(rem, block, depth+1);
        if(after1){
          const after2=forcePlace(after1, op.block, depth+1);
          if(after2) return after2;
        }
      }
    }
    return null;
  }
  // Yerleşemeyen derslerin bloklarını farklı kombinasyonlarla dener; başka dersleri de yerinden oynatarak tam yerleşmeyi hedefler
  function repair(best){
    const t0=Date.now();
    // Faz kendi tavanıyla çalışır; genel aramayı kısıtlamaz (yumuşak bütçe modeli)
    forceDeadline=t0+12000;
    let placements={};
    for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let pending=[...new Set(best.failed.map(b=>b.defId))];
    let passes=0;
    while(pending.length && passes<10 && !solveCancelled){
      passes++; let improvedAny=false; const stillPending=[];
      if(Date.now()>forceDeadline) break;
      for(const defId of pending){
        const sample=best.failed.find(b=>b.defId===defId);
        const hours=sample.hours, maxBlk=Math.max(1,Number(sample.block)||1);
        const alts=sample.blockFixed?[[hours]]:altDecompositions(hours,maxBlk);
        let done=false;
        for(const alt of alts){
          const altBlocks=alt.map((sz,i)=>({...sample,size:sz,bid:uid(),defId,partNo:i+1}));
          const work={};
          for(const pid in placements){ if(placements[pid].block.defId!==defId) work[pid]=placements[pid]; }
          let ok=true, cur=work;
          for(const b of altBlocks){ const np=forcePlace(cur,b,2); if(!np){ ok=false; break; } cur=np; }
          if(ok){ placements=cur; done=true; improvedAny=true; break; }
        }
        if(!done) stillPending.push(defId);
      }
      pending=stillPending;
      if(!improvedAny) break;
    }
    const st=stateFromPlacements(placements);
    const failed=best.failed.filter(b=>pending.includes(b.defId));
    // placed DİZİ olmalı: çağıranlar runAttempt ile aynı şekli varsayıp
    // best.placed.reduce(...) çağırıyor. Sayı döndürmek 'reduce is not a function' veriyordu.
    return { state:st, failed, placed:Object.values(placements).map(p=>p.block) };
  }

  // Yerleşik dersleri de yerinden oynatarak (min-conflicts) takıldığı yerel optimumdan kurtulup yerleşmeyenleri sığdırmaya çalışır
  function improve(best){
    const t0=Date.now();
    forceDeadline=t0+20000;
    let placements={};
    for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let unplaced=best.failed.map(b=>({...b,bid:uid()}));
    let snap={placements:{...placements},unplaced:[...unplaced]};
    let iter=0,lastImprove=0;
    while(iter<8000 && !solveCancelled){
      iter++;
      if(Date.now()>forceDeadline) break;
      let placedOne=false;
      for(let i=0;i<unplaced.length;i++){
        const np=forcePlace(placements,unplaced[i],3);
        if(np){ placements=np; unplaced.splice(i,1); placedOne=true; break; }
      }
      if(placedOne){
        if(unplaced.length<snap.unplaced.length){ snap={placements:{...placements},unplaced:[...unplaced]}; lastImprove=iter; }
        if(!unplaced.length) break;
        continue;
      }
      const pids=Object.keys(placements);
      if(!pids.length) break;
      // Konflikt odaklı kick: yerleşmeyen derslerin uygun saatlerini kapatan dersleri öncelikle yerinden oynat
      const stAll=stateFromPlacements(placements);
      const occ=new Set();
      for(const u of unplaced){
        for(const day of days){ for(let start=1;start<=periods-u.size+1;start++){
          if(!baseCanPlace(u,day,start)) continue;
          for(let o=0;o<u.size;o++){ const p=start+o;
            for(const cl of blockClasses(u)){ const cb=stAll.classBusy[ck(cl,day,p)]; if(cb&&cb!==u.bid) occ.add(cb); }
            for(const t of (u.teachers||[u.teacher])){ const tb=stAll.teacherBusy[tk(t,day,p)]; if(tb&&tb!==u.bid) occ.add(tb); }
          }
        }}
      }
      // Önce tek saatlik blokları öne al (yer değiştirmeleri kolay), yine de rastgele seç
      const pool=(occ.size?[...occ]:pids).sort((a,b)=>(placements[a]&&placements[a].block.size||9)-(placements[b]&&placements[b].block.size||9));
      const pid=pool[Math.floor(Math.random()*pool.length)];
      const pl=placements[pid];
      const rem={...placements}; delete rem[pid];
      const st=stateFromPlacements(rem);
      const cands=[];
      for(const day of days){ for(let start=1;start<=periods-pl.block.size+1;start++){ if(baseCanPlace(pl.block,day,start)) cands.push({day,start}); } }
      const via=cands.filter(s=>canPlace(st,pl.block,s)&&!constraintViolation(st,pl.block,s.day,s.start));
      if(via.length){
        const s=via.sort((x,y)=>scoreSlot(st,pl.block,x)-scoreSlot(st,pl.block,y))[0];
        placements={...rem}; placements[pid]={block:pl.block,day:s.day,start:s.start};
      }else{
        // Yerinden oynatılan ders için zincirleme kick ile yeni yer bul; bulunamazsa eskisi gibi kalsın
        const np=forcePlace(rem,pl.block,0);
        if(np) placements=np;
      }
      if(iter-lastImprove>3000) break;
    }
    const st=stateFromPlacements(snap.placements);
    return { state:st, failed:snap.unplaced, placed:Object.values(snap.placements).map(p=>p.block) };
  }

  // ILS: yerel optimumdan çıkmak için yerleşmeyen derslerin saatlerini kapatan ve rastgele
  // blokları söküp yeniden yerleştirerek tam yerleşmeyi hedefler
  function ils(best, deadlineMs){
    const start=Date.now();
    forceDeadline=start+deadlineMs;
    let placements={};
    for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let unplaced=best.failed.map(b=>({...b,bid:uid()}));
    let snap={placements:{...placements},unplaced:[...unplaced]};
    let lastImprove=start;
    while(Date.now()-start<deadlineMs && !solveCancelled){
      for(let i=0;i<unplaced.length;i++){
        const np=forcePlace(placements,unplaced[i],3);
        if(np){ placements=np; unplaced.splice(i,1); i--; }
      }
      if(!unplaced.length){ snap={placements:{...placements},unplaced:[]}; break; }
      if(unplaced.length<snap.unplaced.length){ snap={placements:{...placements},unplaced:[...unplaced]}; lastImprove=Date.now(); }
      if(Date.now()-lastImprove>15000) break;
      const stAll=stateFromPlacements(placements);
      const toRemove=new Set();
      for(const u of unplaced){
        for(const day of days) for(let s=1;s<=periods-u.size+1;s++){
          if(!baseCanPlace(u,day,s)) continue;
          for(let o=0;o<u.size;o++){ const p=s+o;
            for(const cl of blockClasses(u)){ const cb=stAll.classBusy[ck(cl,day,p)]; if(cb&&cb!==u.bid) toRemove.add(cb); }
            for(const t of (u.teachers||[u.teacher])){ const tb=stAll.teacherBusy[tk(t,day,p)]; if(tb&&tb!==u.bid) toRemove.add(tb); }
          }
        }
      }
      const pids=Object.keys(placements);
      const extra=4+Math.floor(Math.random()*5);
      for(let k=0;k<extra;k++){ toRemove.add(pids[Math.floor(Math.random()*pids.length)]); }
      const kept={};
      for(const pid in placements) if(!toRemove.has(pid)) kept[pid]=placements[pid];
      const ins=[];
      for(const pid of toRemove){ const pl=placements[pid]; if(pl) ins.push(pl.block); }
      for(const u of unplaced) ins.push(u);
      ins.sort((a,b)=>blockCandidates(a.defId,a.size).length-blockCandidates(b.defId,b.size).length);
      let cur=kept; const newUnplaced=[];
      for(const b of ins){ const np=forcePlace(cur,b,3); if(np) cur=np; else newUnplaced.push(b); }
      placements=cur;
      unplaced=newUnplaced;
    }
    const st=stateFromPlacements(snap.placements);
    return { state:st, failed:snap.unplaced, placed:Object.values(snap.placements).map(p=>p.block) };
  }

  let best=null,bestCost=Infinity;
  let lastImprove=0,attemptsRun=0,stuckNow=0,lastIlsAt=0;
  let timedOut=false;
  _isSolving=true; liveBest=null;
  // ── LİMİTSİZ ARAMA: kullanıcı Bitir diyene, tamamı yerleşene veya 1 saatlik güvenlik ağı (HARD_STOP_MS) dolana kadar devam eder ──
  // Her denemede en iyi (maksimum yerleşim) kombinasyon saklanır.
  let a=0; let lastYield=Date.now(); let lastText=0; let stalled=false; let lastImproveAt=Date.now();
  while(true){
    attemptsRun=a+1;
    if(solveCancelled) break;
    if(!timedOut && Date.now()>softAt) timedOut=true; // yumuşak eşik: ⏳ uyarısı (arama durmaz)
    if(Date.now()>hardStop) break;                    // güvenlik ağı (1 saat)
    const result=runAttempt(a);
    const cost=resultCost(result);
    if(!best||result.failed.length<best.failed.length||(result.failed.length===best.failed.length&&cost<bestCost)){
      // Tıkanma saati YALNIZ eksik sayısı azalınca sıfırlanır. Maliyet (ders saatlerinin
      // erkene alınması gibi kozmetik kazançlar) sayacı sürekli diri tutuyordu; hiç
      // tamamlanmayan sıfırdan faz bu yüzden bütçeyi bırakmıyordu.
      const dahaAzEksik = !best || result.failed.length < best.failed.length;
      best=result; bestCost=cost; lastImprove=a; if(dahaAzEksik) lastImproveAt=Date.now();
      // anlık en iyi sakla — progress ekranında ve Kaydet butonunda kullanılacak
      const totH = allBlocks.reduce((s,b)=>s+b.size,0);
      const plcH = best.placed.reduce((s,b)=>s+b.size,0);
      liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:totH};
    }
    bestFailedDefs=new Set(best.failed.map(b=>b.defId));
    stuckNow=a-lastImprove;
    if(!result.failed.length) break;
    // Tıkandıysa ana aramadan çık: sonraki fazlar (repair/improve/ils/ek turlar/onarım
    // zinciri) boşluğu kapatmakta çok daha etkili. Kullanıcı Bitir demeden durmayız,
    // yalnız stratejiyi değiştiririz.
    if(Date.now()-lastImproveAt>STALL_MS){ stalled=true; break; }
    // Derin tıkanmada yapısal değişiklik: blok rastgeleliği yetmez, ILS turu devreye girer
    // (en fazla her 400 tıkanma denemesinde bir; iyileşirse sayaç sıfırlanır).
    if(stuckNow>400 && a-lastIlsAt>400 && !solveCancelled && Date.now()<hardStop){
      lastIlsAt=a;
      showScheduleProgress(`Deneme ${a+1}: en iyi ${best.placed.length}/${blockCountBase} blok • eksik ${best.failed.length} blok • derin arama turu • ${Math.round((Date.now()-startedAt)/1000)} sn`,50+Math.min(42,((a%400)/400)*42));
      await waitFrame();
      const rI=ils(best,8000);
      if(rI.failed.length<best.failed.length||(rI.failed.length===best.failed.length&&resultCost(rI)<bestCost)){
        best=rI; bestCost=resultCost(best); lastImprove=a;
        const plcH=best.placed.reduce((s,b)=>s+b.size,0);
        liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)};
      }
      await waitFrame();
      if(!best.failed.length) break;
      if(solveCancelled) break;
    }
    if(Date.now()-lastText>perfTextMs() || Date.now()-lastYield>40){
      if(Date.now()-lastText>perfTextMs()) lastText=Date.now();
      const stuck=a-lastImprove;
      // Sınırsız olduğu için progress bar canlı tutulur (50-92 arası döngü)
      const pct = 50 + Math.min(42, ((a % 400)/400)*42);
      showScheduleProgress(`${timedOut?"⏳ ":""}Deneme ${a+1}: en iyi ${best.placed.length}/${blockCountBase} blok • eksik ${best.failed.length} blok • ${stuck} denemedir iyileşme yok • ${Math.round((Date.now()-startedAt)/1000)} sn — tamamı yerleşene kadar devam ediyor, istediğin an "Bitir" ile kaydedebilirsin`, pct);
      await waitFrame(); lastYield=Date.now();
      if(solveCancelled) break;
    }
    a++;
    // UI donmasın diye her 500 denemede ek nefes + zamana bağlı yield
    if(a%perfLargeInterval()===0 || Date.now()-lastYield>40){ await waitFrame(); lastYield=Date.now(); }
  }

  // İlk tur sonrası hala eksik varsa: alternatif blok / kick / ILS iyileştirmeleri
  // Bunlar da limitsiz döngünün parçası - kullanıcı iptal edene kadar periyodik denenir
  if(best && best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Yerleşemeyen dersler için alternatif bloklar deneniyor...",94);
    await waitFrame();
    const r = repair(best);
    if(r.failed.length < best.failed.length || (r.failed.length===best.failed.length && resultCost(r) < bestCost)){
      best=r; bestCost=resultCost(best);
      const plcH = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)};
    }
  }
  if(best && best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Yerleşemeyen dersler için son yerleşim turu yapılıyor...",96);
    await waitFrame();
    const r = improve(best);
    if(r.failed.length < best.failed.length || (r.failed.length===best.failed.length && resultCost(r) < bestCost)){
      best=r; bestCost=resultCost(best);
      const plcH = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)};
    }
  }
  if(best && best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Kalan dersler için derin arama yapılıyor...",97);
    await waitFrame();
    const r = ils(best,20000);
    if(r.failed.length < best.failed.length || (r.failed.length===best.failed.length && resultCost(r) < bestCost)){
      best=r; bestCost=resultCost(best);
      const plcH = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)};
    }
  }
  // ── LİMİTSİZ EK TURLAR: hala eksik varsa kullanıcı Bitir diyene veya süre dolana kadar devam et ──
  let extraRound=0;
  // Ek turlar da sonsuza kadar sürmesin: iyileşme getirmeyen tur sayısı sınırı aşınca
  // çıkılır ki OTOMATİK ONARIM TURU'na (chain) sıra gelsin — ölçümde boşluğu asıl
  // kapatan faz o. Kullanıcı isterse sonuç ekranından yeniden dağıtabilir.
  let kisirTur=0;
  const KISIR_TUR_SINIRI=4;
  while(best && best.failed.length>0 && !solveCancelled){
    extraRound++;
    if(!timedOut && Date.now()>softAt) timedOut=true; // yumuşak eşik: ⏳ uyarısı (arama durmaz)
    if(Date.now()>hardStop) break;                    // güvenlik ağı (1 saat)
    // Ek turlar da tıkanmışsa bekletme: otomatik onarım turuna geç.
    if(Date.now()-lastImproveAt>STALL_MS) break;
    const pct = 92 + (extraRound % 5);
    showScheduleProgress(`${timedOut?"⏳ ":""}Ek tur ${extraRound}: en iyi ${best.placed.length}/${blockCountBase} blok (${best.failed.length} eksik) • ${Math.round((Date.now()-startedAt)/1000)} sn — tamamı yerleşene kadar devam ediyor, istediğin an "Bitir" ile kaydedebilirsin`, pct);
    await waitFrame();
    // 200 yeni rastgele deneme
    for(let k=0;k<200;k++){
      if(solveCancelled) break;
      if(Date.now()>hardStop) break;
      const r = runAttempt(a + k + extraRound*1000);
      const c = resultCost(r);
      if(!best || r.failed.length < best.failed.length || (r.failed.length===best.failed.length && c < bestCost)){
        best=r; bestCost=c; lastImprove=a+k;
        const plcH = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)};
      }
      stuckNow=(a+k)-lastImprove;
      if(!r.failed.length){ best=r; const plcH2 = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH2, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)}; break; }
      if(stuckNow>400 && (a+k)-lastIlsAt>400 && !solveCancelled && Date.now()<hardStop){ lastIlsAt=a+k; showScheduleProgress(`${timedOut?"⏳ ":""}Ek tur ${extraRound}: derin arama turu • en iyi ${best.placed.length}/${blockCountBase} blok (${best.failed.length} eksik) • ${Math.round((Date.now()-startedAt)/1000)} sn`,92+(extraRound%5)); await waitFrame(); const rI=ils(best,8000); if(rI.failed.length<best.failed.length||(rI.failed.length===best.failed.length&&resultCost(rI)<bestCost)){ best=rI; bestCost=resultCost(best); lastImprove=a+k; const plcH = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)}; } await waitFrame(); if(!best.failed.length) break; if(solveCancelled) break; }
      if(k%perfInterval()===0 || Date.now()-lastYield>40){ await waitFrame(); lastYield=Date.now(); }
    }
    a += 200;
    if(!best.failed.length) break;
    if(solveCancelled) break;
    // Periyodik ILS ile sıkışmayı aç
    const oncekiEksikS=best.failed.length;
    const r2 = ils(best, 8000);
    if(r2.failed.length < best.failed.length || (r2.failed.length===best.failed.length && resultCost(r2) < bestCost)){
      best=r2; bestCost=resultCost(best);
      const plcH = best.placed.reduce((s,b)=>s+b.size,0); liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed:[...forcedFailed,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:allBlocks.reduce((s,b)=>s+b.size,0)};
    }
    if(!best.failed.length) break;
    if(best.failed.length>=oncekiEksikS){ kisirTur++; } else { kisirTur=0; }
    if(kisirTur>=KISIR_TUR_SINIRI) break;
    await waitFrame();
  }
  // Kullanıcı iptal ettiyse ve hiç en iyi yoksa boş dön
  if(!best){
    if(solveCancelled){
      toast("Dağıtım durduruldu.","err");
      return {totalBlocks:allBlocks.length,activeBlocks:blockCountBase,placedBlocks:0,totalHours:allBlocks.reduce((s,b)=>s+b.size,0),placedHours:0,forcedFailed,failed:[],allFailed:[...forcedFailed],capacityIssues,validationWarnings:validation.warnings,flexible,attempts:attemptsRun,lessons:[]};
    }
    best={state:blankState(),placed:[],failed:[]};
  }
  const placedCount=Array.isArray(best.placed)?best.placed.length:best.placed;
  school.lessons=[];
for(const p of Object.values(best.state.placements)){
    const b=p.block;
    for(let o=0;o<b.size;o++){
      const lesson={id:b.bid, course:b.course, className:b.className,
        day:p.day, period:p.start+o, hours:b.size, part:o+1, room:b.room||null};
      setTeachers(lesson, b.teachers||[b.teacher]);
      setClasses(lesson, blockClasses(b));
      school.lessons.push(lesson);
    }
  }

  saveState(); renderDefs(); refresh();
  const allFailed=[...forcedFailed,...best.failed];
  const result={
    totalBlocks:allBlocks.length,activeBlocks:blockCountBase,placedBlocks:placedCount,
    totalHours:allBlocks.reduce((s,b)=>s+b.size,0),
    placedHours:school.lessons.length,
    forcedFailed,failed:best.failed,allFailed,capacityIssues,noCandidate:[],validationWarnings:validation.warnings,
    constraintViolations:countViolations(best.state.placements),
    flexible,attempts:attemptsRun,timedOut,lessons:school.lessons.map(l=>({...l}))
  };
  // anlık en iyi güncellemeyi globalde de yansıt
  const plcH = result.placedHours;
  liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed, allFailed, placedBlocks:placedCount, totalBlocks:allBlocks.length, placedHours:plcH, totalHours:result.totalHours};
  if(!opts.silentResult){
    _isSolving=false;
    showScheduleResult(result);
    if(allFailed.length===0){
      toast(`✓ Tüm dersler yerleşti (${placedCount} blok).`,"ok");
    }else{
      const cap=capacityIssues[0];
      const why=cap?` ${cap.type}: ${cap.name} ${cap.need}/${cap.open}.`:"";
      const examples=allFailed.slice(0,3).map(b=>blockLabel(b)).join(", ");
      toast(`⚠ ${placedCount}/${allBlocks.length} blok yerleşti.${why} Yerleşmeyen: ${examples}${allFailed.length>3?"...":""}`,"err");
    }
  } else {
    // silent çağrı (autoSolve içinden): _isSolving bayrağını koru, üst seviye kapatacak
  }
  return result;
}

// ─── ORTAK TÜM OKULLAR ÇÖZÜCÜ ───
// Birden fazla okul ve ortak öğretmen/derslik varsa TÜM okulların bloklarını tek havuzda,
// öğretmen/derslik çakışması duvar saati ile ortak kontrol edilerek birlikte çözer.
// Tek okul → solve() ile aynı sonucu verir, dayatmaya gerek yok.
async function solveAllJoint(opts={}){
  // Bu ikisi fonksiyonun EN BASINDA tanımlanmalı: completeOnly dalı aşağıdaki ana
  // arama bloğundan ÖNCE çalışıyor ve yield için bunları kullanıyor. Aşağıda
  // tanımlanırsa "Cannot access 'lastYield' before initialization" (TDZ) hatası olur.
  let lastYield=Date.now(); let lastText=0;
  const activeSchools = S.schools.filter(s=> (s.defs||[]).length);
  if(!activeSchools.length){ toast("Dağıtılacak okul yok.","err"); return null; }
  // her okul için ön doğrulama
  for(const sc of activeSchools){
    const v = validateScheduleData(sc);
    if(v.errors.length){
      const result={totalBlocks:0,placedBlocks:0,totalHours:0,placedHours:0,forcedFailed:[],failed:[],allFailed:[],capacityIssues:[],validationErrors:v.errors,validationWarnings:v.warnings,flexible:false};
      showScheduleResult(result);
      toast(`${sc.name}: ${v.errors.length} veri hatası var. Dağıtım başlamadı.`,"err");
      return result;
    }
  }
  const flexible = !!opts.flexibleBlocks;
  // Yumuşak eşik + güvenlik ağı: arama durmaz; softAt yalnız ⏳ uyarısı için, hardStop yalnız felaket sigortası.
  const startedAt=Date.now();
  const softAt=startedAt+(opts.completeOnly?COMPLETE_BUDGET_MS:SOLVE_SOFT_MS);
  const hardStop=startedAt+HARD_STOP_MS;
  // Öğretmen yükü: öğretmenin tüm okullardaki toplam ders saati (sıralama kırıcısı için)
  const teacherLoad=teacherLoadMap(activeSchools).load;
  const schoolById = {}; for(const sc of activeSchools) schoolById[sc.id]=sc;
  // Okul-bazlı statik açık kontroller (diğer okulun yerleşmiş derslerini saymadan)
  function sOpenStatic(s,d,p){ return !((s.schoolClosed||{})[sk(d,p)]); }
  function cOpenStatic(s,cl,d,p){ return sOpenStatic(s,d,p) && !(s.classClosed&&s.classClosed[cl]&&s.classClosed[cl][sk(d,p)]); }
  function tStaticOpen(s,t,d,p){ if(!sOpenStatic(s,d,p)) return false; if(S.teacherClosed[t]&&S.teacherClosed[t][s.id]&&S.teacherClosed[t][s.id][sk(d,p)]) return false; return true; }
  function baseCanPlaceJoint(b,day,start){
    const sc=schoolById[b.schoolId];
    for(let o=0;o<b.size;o++){
      const pp=start+o;
      if(pp>sc.periods) return false;
      for(const cl of blockClasses(b)) if(!cOpenStatic(sc,cl,day,pp)) return false;
      for(const t of (b.teachers||[b.teacher])) if(!tStaticOpen(sc,t,day,pp)) return false;
      if(b.avail && b.avail[`${day}|${pp}`]===false) return false;
    }
    return true;
  }
  function blockPartsJoint(hours,maxBlk,fixed){
    const parts=[]; let rem=hours;
    if(fixed){ parts.push(hours); return parts; }
    if(!flexible||maxBlk<=1){ while(rem>0){const sz=Math.min(maxBlk,rem);parts.push(sz);rem-=sz;} return parts; }
    const mode=Math.random();
    if(mode<0.34){ while(rem>0){const sz=Math.min(maxBlk,rem);parts.push(sz);rem-=sz;} }
    else if(mode<0.72){ parts.push(Math.min(maxBlk,rem)); rem-=parts[0]; while(rem>0){parts.push(1);rem--;} }
    else{ while(rem>0){parts.push(1);rem--;} }
    return parts;
  }
  function altDecompositionsJoint(hours,maxBlk){
    const res=[]; function rec(rem,path){ if(rem===0){res.push([...path]);return;} for(let s=Math.min(maxBlk,rem);s>=1;s--) rec(rem-s,path.concat(s)); } rec(hours,[]);
    res.sort((a,b)=>b.length-a.length || b[0]-a[0]); return res.slice(0,80);
  }
  const altsCacheJ={};
  function altsForJoint(def){
    if(altsCacheJ[def.id]) return altsCacheJ[def.id];
    const hours=Math.max(1,Number(def.hours)||1);
    if(def.blockFixed){ altsCacheJ[def.id]=[[hours]]; return altsCacheJ[def.id]; }
    const maxBlk=Math.max(1,Number(def.block)||1);
    altsCacheJ[def.id]=altDecompositionsJoint(hours,maxBlk).slice().sort((a,b)=>a.length-b.length);
    return altsCacheJ[def.id];
  }
  // Hiç uygun saati olmayan tanımlar (her okul kendi içinde)
  const noCandIds=new Set(), noCandDefs=[];
  for(const sc of activeSchools){
    for(const def of sc.defs){
      const testSize=def.blockFixed?Math.max(1,Number(def.hours)||1):1;
      const b1={...def,size:testSize,schoolId:sc.id};
      let has=false;
      for(const day of sc.days){ for(let start=1;start<=sc.periods-testSize+1;start++){ if(baseCanPlaceJoint(b1,day,start)){has=true;break;}} if(has) break; }
      if(!has){ noCandDefs.push({...def,schoolId:sc.id,schoolName:sc.name}); noCandIds.add(def.id); }
    }
  }
  // Kapasite hesabı için tüm bloklar (aktif tanımlar)
  const activeDefsBySchool={};
  for(const sc of activeSchools) activeDefsBySchool[sc.id]=sc.defs.filter(d=>!noCandIds.has(d.id));
  const allBlocksJ=[];
  for(const sc of activeSchools){
    for(const g of activeDefsBySchool[sc.id]){
      const maxBlk=Math.max(1,Number(g.block)||1);
      let part=1;
      for(const sz of blockPartsJoint(Math.max(1,Number(g.hours)||1),maxBlk,g.blockFixed)){
        allBlocksJ.push({...g,size:sz,bid:uid(),defId:g.id,schoolId:sc.id,schoolName:sc.name,partNo:part++});
      }
    }
  }
  if(!allBlocksJ.length && !noCandDefs.length){ toast("Ders yok.","err"); return null; }
  // Okul-bazlı kısıtlar
  const CbySchool={}, gapBySchool={}, breakBySchool={}, lunchReqBySchool={}, pairBySchool={}, maxRunBySchool={};
  const lunchWinByDayGlobal={};
  // tüm günler birleşimi (ortak takvim)
  const allDays = [...new Set(activeSchools.flatMap(s=>s.days))];
  for(const day of allDays) lunchWinByDayGlobal[day]=lunchWindowsForDay(day);
  for(const sc of activeSchools){
    const C=normConstraints(sc.constraints);
    CbySchool[sc.id]=C;
    gapBySchool[sc.id]=Math.max(0,Math.floor(Number(C.courseGap)||0));
    maxRunBySchool[sc.id]=Math.max(0,Math.floor(Number(C.maxSameRun)||0));
    breakBySchool[sc.id]=Math.max(0,Math.floor(Number(C.minBreak)||0));
    lunchReqBySchool[sc.id]=!!C.requireLunch && Object.values(lunchWinByDayGlobal).some(w=>w.length>0);
    const pc={}; for(const pr of (C.coursePairs||[])){ if(!pr.a||!pr.b||pr.a===pr.b) continue; (pc[pr.a]=pc[pr.a]||new Set()).add(pr.b); (pc[pr.b]=pc[pr.b]||new Set()).add(pr.a); } pairBySchool[sc.id]=pc;
  }
  function defKeyJ(b){ return b.defId ? `${b.schoolId}|${b.defId}` : `${b.schoolId}|${b.course}|${b.teachers}|${b.className}`; }
  const blockLabelJ=b=>`${b.schoolName} ${b.className} ${b.course} (${tLabelArr(b.teachers||[b.teacher])})`;
  function blockIntervalJoint(b,start){
    const sc=schoolById[b.schoolId];
    const pt=sc.periodTimes;
    const p0=start, p1=start+b.size-1;
    if(!pt[p0-1]||!pt[p1-1]) return null;
    return {start:toMin(pt[p0-1].start), end:toMin(pt[p1-1].end), schoolId:b.schoolId};
  }
  // Ortak state yapıları (okul-id önekli where needed)
  function blankStateJ(){
    return {placements:{},classBusy:{},teacherIntervals:{},roomIntervals:{},cellLoad:{},classDay:{},teacherDay:{},courseDay:{},courseDayCount:{},courseSlots:{},teacherDayCourses:{},dayCourseSet:{}};
  }
  function stateFromPlacementsJ(placements){
    const st=blankStateJ();
    for(const pid in placements){ const pl=placements[pid]; putBlockJ(st,pl.block,{day:pl.day,start:pl.start}); }
    return st;
  }
  // kapasite (sınıf/öğretmen) — her okul kendi içinde
  function openClassSlotsJ(sc, cl){
    let n=0; for(const day of sc.days) for(let p=1;p<=sc.periods;p++) if(cOpenStatic(sc,cl,day,p)) n++;
    return n;
  }
  function teacherWeeklyCapJ(teacher, classNames, sc){
    let cap=0; for(const day of sc.days){ let tOpen=0,anyOpen=0; for(let p=1;p<=sc.periods;p++){ if(!tStaticOpen(sc,teacher,day,p)) continue; tOpen++; for(const cl of classNames){ if(cOpenStatic(sc,cl,day,p)){anyOpen++;break;}} } cap+=Math.min(tOpen,anyOpen); } return cap;
  }
  // CanPlace / PutBlock / ConstraintViolation (joint)
  function canPlaceJ(state,b,slot){
    const bi=blockIntervalJoint(b,slot.start);
    if(b.room && bi){
      const arr=state.roomIntervals[`${b.room}|${slot.day}`]||[];
      for(const iv of arr) if(iv.start<bi.end && bi.start<iv.end) return false;
    }
    for(let o=0;o<b.size;o++){
      const p=slot.start+o;
      for(const cl of blockClasses(b)) if(state.classBusy[`${b.schoolId}|${cl}|${slot.day}|${p}`]) return false;
    }
    if(bi){
      for(const t of (b.teachers||[b.teacher])){
        const arr=state.teacherIntervals[`${t}|${slot.day}`]||[];
        for(const iv of arr) if(iv.start<bi.end && bi.start<iv.end) return false;
      }
    }
    return true;
  }
  function putBlockJ(state,b,slot){
    blockRegJ[b.bid]=b;
    state.placements[b.bid]={block:b,day:slot.day,start:slot.start};
    for(let o=0;o<b.size;o++){
      const p=slot.start+o;
      for(const cl of blockClasses(b)) state.classBusy[`${b.schoolId}|${cl}|${slot.day}|${p}`]=b.bid;
      state.cellLoad[`${b.schoolId}|${slot.day}|${p}`]=(state.cellLoad[`${b.schoolId}|${slot.day}|${p}`]||0)+1;
      state.classDay[`${b.schoolId}|${b.className}|${slot.day}`]=(state.classDay[`${b.schoolId}|${b.className}|${slot.day}`]||0)+1;
      for(const t of (b.teachers||[b.teacher])) state.teacherDay[`${t}|${slot.day}`]=(state.teacherDay[`${t}|${slot.day}`]||0)+1;
      state.courseDay[`${defKeyJ(b)}|${slot.day}`]=(state.courseDay[`${defKeyJ(b)}|${slot.day}`]||0)+1;
    }
    state.courseDayCount[`${defKeyJ(b)}|${slot.day}`]=(state.courseDayCount[`${defKeyJ(b)}|${slot.day}`]||0)+1;
    (state.courseSlots[`${defKeyJ(b)}|${slot.day}`]=state.courseSlots[`${defKeyJ(b)}|${slot.day}`]||[]).push({start:slot.start,size:b.size,bid:b.bid});
    // Set yerine sayaç: blok geri alınırken (removeBlockJ) tam olarak eski hâline dönebilmeli.
    for(const t of (b.teachers||[b.teacher])) cntInc(state.teacherDayCourses,`${t}|${slot.day}`,b.course);
    cntInc(state.dayCourseSet,`${b.schoolId}|${b.className}|${slot.day}`,b.course);
    const bi=blockIntervalJoint(b,slot.start);
    if(bi){
      bi.bid=b.bid;   // hangi bloğun aralığı olduğu: hem silmek hem işgalci bulmak için
      for(const t of (b.teachers||[b.teacher])) (state.teacherIntervals[`${t}|${slot.day}`]=state.teacherIntervals[`${t}|${slot.day}`]||[]).push(bi);
      if(b.room) (state.roomIntervals[`${b.room}|${slot.day}`]=state.roomIntervals[`${b.room}|${slot.day}`]||[]).push(bi);
    }
  }
  function cntInc(m,key,name){ const d=m[key]||(m[key]={}); d[name]=(d[name]||0)+1; }
  function cntDec(m,key,name){ const d=m[key]; if(!d) return; d[name]=(d[name]||0)-1; if(d[name]<=0) delete d[name]; }
  // putBlockJ'in tam tersi. Bunun olmaması yüzünden zincir arama her adımda TÜM programı
  // sıfırdan kuruyordu (640 blok x her özyineleme); bir tanım denemesi saniyeler sürüyordu.
  function removeBlockJ(state,b){
    const pl=state.placements[b.bid]; if(!pl) return;
    const day=pl.day, start=pl.start;
    delete state.placements[b.bid];
    const dk=defKeyJ(b);
    for(let o=0;o<b.size;o++){
      const p=start+o;
      for(const cl of blockClasses(b)) delete state.classBusy[`${b.schoolId}|${cl}|${day}|${p}`];
      state.cellLoad[`${b.schoolId}|${day}|${p}`]=(state.cellLoad[`${b.schoolId}|${day}|${p}`]||0)-1;
      state.classDay[`${b.schoolId}|${b.className}|${day}`]=(state.classDay[`${b.schoolId}|${b.className}|${day}`]||0)-1;
      for(const t of (b.teachers||[b.teacher])) state.teacherDay[`${t}|${day}`]=(state.teacherDay[`${t}|${day}`]||0)-1;
      state.courseDay[`${dk}|${day}`]=(state.courseDay[`${dk}|${day}`]||0)-1;
    }
    state.courseDayCount[`${dk}|${day}`]=(state.courseDayCount[`${dk}|${day}`]||0)-1;
    const cs=state.courseSlots[`${dk}|${day}`];
    if(cs){ const i=cs.findIndex(x=>x.bid===b.bid); if(i>=0) cs.splice(i,1); }
    for(const t of (b.teachers||[b.teacher])) cntDec(state.teacherDayCourses,`${t}|${day}`,b.course);
    cntDec(state.dayCourseSet,`${b.schoolId}|${b.className}|${day}`,b.course);
    for(const t of (b.teachers||[b.teacher])){ const a=state.teacherIntervals[`${t}|${day}`]; if(a){ const i=a.findIndex(iv=>iv.bid===b.bid); if(i>=0) a.splice(i,1); } }
    if(b.room){ const a=state.roomIntervals[`${b.room}|${day}`]; if(a){ const i=a.findIndex(iv=>iv.bid===b.bid); if(i>=0) a.splice(i,1); } }
  }
  // Anlık görüntü / geri alma: yalnız yeri değişen bloklara dokunur, tüm programı yeniden kurmaz.
  const blockRegJ={};
  function snapJ(st){ const m={}; for(const bid in st.placements){ const p=st.placements[bid]; m[bid]=p.day+""+p.start; } return m; }
  function restoreJ(st,snap){
    for(const bid of Object.keys(st.placements)){
      const cur=st.placements[bid];
      if(snap[bid]!==cur.day+""+cur.start) removeBlockJ(st,cur.block);
    }
    for(const bid in snap){
      if(st.placements[bid]) continue;
      const v=snap[bid], i=v.indexOf("");
      putBlockJ(st,blockRegJ[bid],{day:v.slice(0,i),start:+v.slice(i+1)});
    }
  }
  // b (day,start) konumuna konarsa ayni sinifta olusacak "akraba" ardisik saat sayisi
  function sameRunLenJ(st,b,day,start){
    const sc=schoolById[b.schoolId]; let en=0;
    const blokOf=bid=>{ const p=st.placements[bid]; return p?p.block:null; };
    for(const cl of blockClasses(b)){
      let sol=0;
      for(let p=start-1;p>=1;p--){ const o=blokOf(st.classBusy[`${b.schoolId}|${cl}|${day}|${p}`]); if(!o||o.bid===b.bid||!sameRunFamily(o,b)) break; sol++; }
      let sag=0;
      for(let p=start+b.size;p<=sc.periods;p++){ const o=blokOf(st.classBusy[`${b.schoolId}|${cl}|${day}|${p}`]); if(!o||o.bid===b.bid||!sameRunFamily(o,b)) break; sag++; }
      if(sol+b.size+sag>en) en=sol+b.size+sag;
    }
    return en;
  }
  // Kurali ihlal ettiren KOMSU bloklar. Bunlar slotu isgal etmedigi icin occupantsJ
  // onlari dondurmez; zincir arama da bu yuzden bos ama kisitli slotlari hic denemezdi.
  function sameRunBlockersJ(st,b,day,start){
    const sc=schoolById[b.schoolId], out=new Set();
    const blokOf=bid=>{ const p=st.placements[bid]; return p?p.block:null; };
    for(const cl of blockClasses(b)){
      for(let p=start-1;p>=1;p--){ const o=blokOf(st.classBusy[`${b.schoolId}|${cl}|${day}|${p}`]); if(!o||o.bid===b.bid||!sameRunFamily(o,b)) break; out.add(o.bid); }
      for(let p=start+b.size;p<=sc.periods;p++){ const o=blokOf(st.classBusy[`${b.schoolId}|${cl}|${day}|${p}`]); if(!o||o.bid===b.bid||!sameRunFamily(o,b)) break; out.add(o.bid); }
    }
    return [...out];
  }
  // Bu slotu tutan diğer bloklar. Aralıklar bid taşıdığı için tüm yerleşimi taramaya gerek kalmadı.
  function occupantsJ(st,b,day,start){
    const out=new Set();
    for(let o=0;o<b.size;o++){
      const p=start+o;
      for(const cl of blockClasses(b)){ const cb=st.classBusy[`${b.schoolId}|${cl}|${day}|${p}`]; if(cb&&cb!==b.bid) out.add(cb); }
    }
    const bi=blockIntervalJoint(b,start);
    if(bi){
      for(const t of (b.teachers||[b.teacher])){
        const arr=st.teacherIntervals[`${t}|${day}`]||[];
        for(const iv of arr) if(iv.start<bi.end&&bi.start<iv.end&&iv.bid!==b.bid) out.add(iv.bid);
      }
      if(b.room){ const arr=st.roomIntervals[`${b.room}|${day}`]||[]; for(const iv of arr) if(iv.start<bi.end&&bi.start<iv.end&&iv.bid!==b.bid) out.add(iv.bid); }
    }
    const res=[]; for(const id of out) if(st.placements[id]) res.push(id);
    return res;
  }
  /* Slot BOŞ ama kısıt engelliyorsa suçlu blokları bulur.
     Ölçülen gerçek tıkanıklık buydu: dersin gideceği saat sınıf/öğretmen/derslik olarak tamamen
     boş, ama oraya konursa öğretmenin o günkü TEK boş öğle penceresi kapanıyor ve requireLunch
     ihlal oluyor. Öğle arasını yiyen dersler o slotta olmadığı için "işgalci" sayılmıyor,
     dolayısıyla zincir arama bu tıkanıklığı hiç göremiyordu. Artık onlar da kaldırılabiliyor. */
  function constraintBlockersJ(st,b,day,start){
    const out=new Set();
    const sc=schoolById[b.schoolId]; const C=CbySchool[sc.id];
    const dk=defKeyJ(b);
    const gap=gapBySchool[sc.id];
    if(maxRunBySchool[sc.id]>0 && sameRunLenJ(st,b,day,start)>maxRunBySchool[sc.id]){
      for(const bid of sameRunBlockersJ(st,b,day,start)) out.add(bid);
    }
    if(C.spreadCourse||gap>0){
      const slots=st.courseSlots[`${dk}|${day}`]||[];
      for(const sl of slots){
        if(C.spreadCourse){ out.add(sl.bid); continue; }
        if(start<sl.start+sl.size+gap && sl.start<start+b.size+gap) out.add(sl.bid);
      }
    }
    const minBreak=breakBySchool[sc.id], reqLunch=lunchReqBySchool[sc.id];
    if(minBreak>0||reqLunch){
      const bi=blockIntervalJoint(b,start);
      if(bi){
        const win=lunchWinByDayGlobal[day]||[];
        for(const t of (b.teachers||[b.teacher])){
          const arr=st.teacherIntervals[`${t}|${day}`]||[];
          for(const iv of arr){
            if(minBreak>0 && iv.schoolId!==bi.schoolId && iv.end>bi.start-minBreak && iv.start<bi.end+minBreak) out.add(iv.bid);
            if(reqLunch) for(const lw of win) if(iv.start<lw.end&&lw.start<iv.end){ out.add(iv.bid); break; }
          }
        }
      }
    }
    const res=[]; for(const id of out) if(st.placements[id]&&id!==b.bid) res.push(id);
    return res;
  }
  function hasFreeLunchJ(ints,bi,day){
    const win=lunchWinByDayGlobal[day];
    if(!win||!win.length) return true;
    const all=bi?ints.concat([bi]):ints;
    for(const lw of win){ let free=true; for(const iv of all){ if(iv.start<lw.end&&lw.start<iv.end){free=false;break;}} if(free) return true; }
    return false;
  }
  function constraintViolationJ(state,b,day,start){
    const sc=schoolById[b.schoolId]; const C=CbySchool[sc.id];
    if(maxRunBySchool[sc.id]>0 && start!==undefined && sameRunLenJ(state,b,day,start)>maxRunBySchool[sc.id]) return "maxSameRun";
    if(C.spreadCourse && (state.courseDayCount[`${defKeyJ(b)}|${day}`]||0)>0) return "spreadCourse";
    const gap=gapBySchool[sc.id];
    if(gap>0 && start!==undefined){
      const slots=state.courseSlots[`${defKeyJ(b)}|${day}`];
      if(slots){ for(const s of slots){ if(start < s.start+s.size+gap && s.start < start+b.size+gap) return "courseGap"; } }
    }
    if(C.spreadTeacher){
      for(const t of (b.teachers||[b.teacher])){
        const m=state.teacherDayCourses[`${t}|${day}`];
        if(m && Object.keys(m).some(c2=>c2!==b.course)) return "spreadTeacher";
      }
    }
    const pcs=pairBySchool[sc.id][b.course];
    if(pcs && pcs.size){
      const m=state.dayCourseSet[`${b.schoolId}|${b.className}|${day}`];
      if(m){ for(const c2 of pcs) if(m[c2]>0) return "coursePair"; }
    }
    const minBreak=breakBySchool[sc.id], reqLunch=lunchReqBySchool[sc.id];
    if(minBreak>0 || reqLunch){
      const bi=blockIntervalJoint(b,start);
      if(bi){
        for(const t of (b.teachers||[b.teacher])){
          const ints=state.teacherIntervals[`${t}|${day}`]||[];
          if(minBreak>0){ for(const iv of ints){ if(iv.schoolId===bi.schoolId) continue; if(iv.end>bi.start-minBreak && iv.start<bi.end+minBreak) return "break"; } }
          if(reqLunch && !hasFreeLunchJ(ints,bi,day)) return "lunch";
        }
      }
    }
    return null;
  }
  // kısıt ihlal sayımı (rapor için)
  function countViolationsJ(placements){
    const dayInfo={}; // day -> schoolId|...
    for(const p of Object.values(placements)){
      const b=p.block, day=p.day;
      if(!dayInfo[day]) dayInfo[day]={courseCount:{},teacherCourses:{},courseSlots:{},dayCourses:{}};
      dayInfo[day].courseCount[defKeyJ(b)]=(dayInfo[day].courseCount[defKeyJ(b)]||0)+1;
      for(const t of (b.teachers||[b.teacher])) (dayInfo[day].teacherCourses[t]=dayInfo[day].teacherCourses[t]||new Set()).add(b.course);
      (dayInfo[day].courseSlots[defKeyJ(b)]=dayInfo[day].courseSlots[defKeyJ(b)]||[]).push({start:p.start,size:b.size});
      (dayInfo[day].dayCourses[`${b.schoolId}|${b.className}`]=dayInfo[day].dayCourses[`${b.schoolId}|${b.className}`]||new Set()).add(b.course);
    }
    let spreadCourseV=0,spreadTeacherV=0,coursePairV=0,courseGapV=0,breakV=0,lunchV=0,maxSameRunV=0;
    // "ust uste" ihlali: sinif-gun izgarasinda ayni ders/ogretmen dizisi sinirdan uzunsa
    {
      const izgara={};   // okulId|sinif|gun -> {saat: blok}
      for(const p of Object.values(placements)){
        const b=p.block;
        for(const cl of blockClasses(b)) for(let o=0;o<b.size;o++){
          const k=`${b.schoolId}|${cl}|${p.day}`;
          (izgara[k]=izgara[k]||{})[p.start+o]=b;
        }
      }
      for(const k in izgara){
        const sid=k.split("|")[0], lim=maxRunBySchool[sid]||0;
        if(!lim || !schoolById[sid]) continue;
        const sc=schoolById[sid], hucreler=izgara[k], gorulen=new Set();
        for(let pp=1;pp<=sc.periods;pp++){
          const b0=hucreler[pp]; if(!b0) continue;
          for(const olcut of [b0.course,...(b0.teachers||[b0.teacher])]){
            if(gorulen.has(pp+"|"+olcut)) continue;
            let q=pp;
            while(q<=sc.periods && hucreler[q] && (hucreler[q].course===olcut || (hucreler[q].teachers||[hucreler[q].teacher]).indexOf(olcut)>=0)){ gorulen.add(q+"|"+olcut); q++; }
            if(q-pp>lim) maxSameRunV++;
          }
        }
      }
    }
    for(const day in dayInfo){
      const di=dayInfo[day];
      for(const c in di.courseCount) if(di.courseCount[c]>1){
        const [sid]=c.split("|"); if(CbySchool[sid]&&CbySchool[sid].spreadCourse) spreadCourseV+=di.courseCount[c]-1;
      }
      for(const t in di.teacherCourses) if(di.teacherCourses[t].size>1){
        // herhangi bir okulun kuralı açıksa say
        let any=false; for(const sc of activeSchools) if(CbySchool[sc.id].spreadTeacher && activeSchools.some(s=>s.defs.some(d=>defTeachers(d).includes(t)))) {any=true;break;}
        if(any) spreadTeacherV+=di.teacherCourses[t].size-1;
      }
      for(const c in di.courseSlots){
        const sid=c.split("|")[0]; const gap=gapBySchool[sid]||0; if(gap>0){
          const slots=di.courseSlots[c].sort((a,b)=>a.start-b.start);
          for(let i=1;i<slots.length;i++){ const g=slots[i].start-(slots[i-1].start+slots[i-1].size); if(g<gap) courseGapV+=gap-g; }
        }
      }
      for(const key in di.dayCourses){
        const sid=key.split("|")[0]; const set=di.dayCourses[key];
        for(const pr of (CbySchool[sid]&&CbySchool[sid].coursePairs||[])){ if(pr.a!==pr.b&&set.has(pr.a)&&set.has(pr.b)) coursePairV++; }
      }
    }
    // break/lunch global
    const tInts={};
    for(const p of Object.values(placements)){
      const b=p.block, day=p.day; const bi=blockIntervalJoint(b,p.start); if(!bi) continue;
      for(const t of (b.teachers||[b.teacher])){ const k=`${t}|${day}`; (tInts[k]=tInts[k]||[]).push(bi); }
    }
    for(const [k,ints] of Object.entries(tInts)){
      if(ints.length<2) continue; ints.sort((a,b)=>a.start-b.start);
      const day=k.split("|")[1];
      // break için herhangi bir okulun kuralı
      let maxBreak=0; for(const sc of activeSchools) maxBreak=Math.max(maxBreak,breakBySchool[sc.id]||0);
      if(maxBreak>0){ for(let i=1;i<ints.length;i++){ const a=ints[i-1],b=ints[i]; if(a.schoolId===b.schoolId) continue; const gap=b.start-a.end; if(gap<maxBreak) breakV+=maxBreak-gap; } }
      const needLunch = Object.values(lunchReqBySchool).some(v=>v);
      if(needLunch){ if(!hasFreeLunchJ(ints,undefined,day)) lunchV++; }
    }
    return {spreadCourseV,spreadTeacherV,coursePairV,courseGapV,breakV,lunchV,maxSameRunV,total:spreadCourseV+spreadTeacherV+coursePairV+courseGapV+breakV+lunchV+maxSameRunV};
  }
  // kapasite kontrolü (her okul kendi içinde)
  function openClassSlotsFor(sc, cl){ let n=0; for(const day of sc.days) for(let p=1;p<=sc.periods;p++) if(cOpenStatic(sc,cl,day,p)) n++; return n; }
  function teacherCapFor(sc, teacher, classNames){ let cap=0; for(const day of sc.days){ let tOpen=0,anyOpen=0; for(let p=1;p<=sc.periods;p++){ if(!tStaticOpen(sc,teacher,day,p)) continue; tOpen++; for(const cl of classNames){ if(cOpenStatic(sc,cl,day,p)){anyOpen++;break;}} } cap+=Math.min(tOpen,anyOpen); } return cap; }
  function findCapacityIssuesJ(blocks){
    const issues=[]; // okul bazlı
    const bySchool={}; for(const b of blocks){ (bySchool[b.schoolId]=bySchool[b.schoolId]||[]).push(b); }
    for(const sc of activeSchools){
      const bss=bySchool[sc.id]||[]; const classNeed={}, teacherNeed={}, teacherClasses={};
      for(const b of bss){ classNeed[b.className]=(classNeed[b.className]||0)+b.size; for(const t of (b.teachers||[b.teacher])){ teacherNeed[t]=(teacherNeed[t]||0)+b.size; (teacherClasses[t]=teacherClasses[t]||new Set()).add(b.className); } }
      for(const [name,need] of Object.entries(classNeed)){ const open=openClassSlotsFor(sc,name); if(need>open) issues.push({type:"Sınıf",name:`${sc.name} ${name}`,need,open,extra:need-open}); }
      for(const [name,need] of Object.entries(teacherNeed)){ const open=teacherCapFor(sc,name,teacherClasses[name]); if(need>open) issues.push({type:"Öğretmen",name:`${sc.name} ${name}`,need,open,extra:need-open}); }
    }
    return issues;
  }
  const capacityIssuesJ=findCapacityIssuesJ(allBlocksJ);
  const forcedFailedJ=[]; const forcedIds=new Set(noCandIds);
  for(const d of noCandDefs) forcedFailedJ.push({...d,size:Math.max(1,Number(d.hours)||1),reason:"Hiç uygun saat yok."});
  for(const issue of capacityIssuesJ){
    let extra=issue.extra;
    // ilgili okulun tanımlarından en küçük saatlileri ele
    const scName=issue.name.split(" ")[0]; const targetSc=activeSchools.find(s=>s.name===scName) || activeSchools[0];
    const candidates= (activeDefsBySchool[targetSc.id]||[]).filter(d=>!forcedIds.has(d.id) && (issue.type==="Sınıf"?d.className===issue.name.split(" ").slice(1).join(" "):defTeachers(d).includes(issue.name.split(" ").slice(1).join(" "))))
      .sort((a,b)=> (Math.max(1,Number(a.hours)||1)-Math.max(1,Number(b.hours)||1)) || (a.id<b.id?-1:1));
    for(const d of candidates){ if(extra<=0) break; forcedIds.add(d.id); forcedFailedJ.push({...d,size:Math.max(1,Number(d.hours)||1),schoolId:targetSc.id,schoolName:targetSc.name,reason:`${issue.type} kapasitesi aşılıyor: ${issue.need}/${issue.open}`}); extra-=Math.max(1,Number(d.hours)||1); }
  }
  // aktif bloklar (imkansızlar çıkarıldı)
  const activeBlocksJ = allBlocksJ.filter(b=>!forcedIds.has(b.defId));
  const blockCountBaseJ = activeBlocksJ.length;
  // cand cache
  const candCacheJ={};
  function blockCandsJ(defId,size,schoolId){
    const k=schoolId+"|"+defId+"|"+size;
    if(candCacheJ[k]) return candCacheJ[k];
    const sc=schoolById[schoolId]; const def=activeSchools.flatMap(s=>s.defs).find(d=>d.id===defId);
    const b={...def,size,schoolId};
    const list=[]; for(const day of sc.days){ for(let start=1;start<=sc.periods-size+1;start++){ if(baseCanPlaceJoint(b,day,start)) list.push({day,start}); } }
    candCacheJ[k]=list; return list;
  }
  // blok öncelik (kısıta göre)
  const courseBlockCountJ={}; for(const b of activeBlocksJ) courseBlockCountJ[defKeyJ(b)]=(courseBlockCountJ[defKeyJ(b)]||0)+1;
  const teacherCourseSetJ={}; for(const b of activeBlocksJ) for(const t of (b.teachers||[b.teacher])) (teacherCourseSetJ[t]=teacherCourseSetJ[t]||new Set()).add(b.course);
  function blockPriorityJ(b){
    const C=CbySchool[b.schoolId];
    if(C.spreadCourse && (courseBlockCountJ[defKeyJ(b)]||0)>1) return true;
    if(C.spreadTeacher && (b.teachers||[b.teacher]).some(t=>(teacherCourseSetJ[t]?.size||0)>1)) return true;
    if(pairBySchool[b.schoolId][b.course]) return true;
    return false;
  }
  function scoreSlotJ(state,b,slot){
    let score=0;
    const clsDay=state.classDay[`${b.schoolId}|${b.className}|${slot.day}`]||0;
    const tchDay=Math.max(...(b.teachers||[b.teacher]).map(t=>state.teacherDay[`${t}|${slot.day}`]||0));
    const sameCourseDay=state.courseDay[`${defKeyJ(b)}|${slot.day}`]||0;
    score+=sameCourseDay*180;
    score+=Math.max(0,clsDay-5)*18;
    score+=Math.max(0,tchDay-5)*14;
    score+=slot.start*0.9;
    const sc=schoolById[b.schoolId];
    score+=sc.days.indexOf(slot.day)*0.15;
    for(let o=0;o<b.size;o++) score+=(state.cellLoad[`${b.schoolId}|${slot.day}|${slot.start+o}`]||0)*0.4;
    return score+Math.random()*2.5;
  }
  const defFailCountJ={}; let bestFailedDefsJ=new Set(loadHardDefs());
  function runAttemptJ(attempt){
    const blocks=[];
    for(const sc of activeSchools){
      for(const g of activeDefsBySchool[sc.id]){
        if(forcedIds.has(g.id)) continue;
        const hours=Math.max(1,Number(g.hours)||1); const maxBlk=Math.max(1,Number(g.block)||1);
        let parts;
        if(!flexible||maxBlk<=1) parts=blockPartsJoint(hours,maxBlk,g.blockFixed);
        else{
          const alts=altsForJoint(g);
          const hardNow=bestFailedDefsJ.has(g.id)||(defFailCountJ[g.id]||0)>0;
          if(hardNow) parts=alts[attempt % alts.length];
          // Sorunsuz tanımlar en az parçalı bölüşümü (alts[0]) korur; yalnız arama tıkandığında (stuck>150) rastgele bölüşüme geçilir
          else parts= stuckNow>150 ? alts[Math.floor(Math.random()*alts.length)] : alts[0];
        }
        let part=1; for(const sz of parts){ blocks.push({...g,size:sz,bid:uid(),defId:g.id,schoolId:sc.id,schoolName:sc.name,partNo:part++,candidates:blockCandsJ(g.id,sz,sc.id)}); }
      }
    }
    const state=blankStateJ(); const placed=[],failed=[];
    // Blok yükü: bloğun öğretmenlerinin toplam ders saati (en büyüğü) — yükü fazla olan önce yerleşir
    const loadOf=b=>Math.max(0,...(b.teachers||[b.teacher]).map(t=>teacherLoad[t]||0));
    const ordered=[...blocks].sort((a,b)=>{
      const fx=bestFailedDefsJ.has(a.defId)?1:0, fy=bestFailedDefsJ.has(b.defId)?1:0; if(fx!==fy) return fy-fx;
      const cx=defFailCountJ[a.defId]||0, cy=defFailCountJ[b.defId]||0; if(cx!==cy) return cy-cx;
      const pa=blockPriorityJ(a)?1:0,pb=blockPriorityJ(b)?1:0; if(pa!==pb) return pb-pa;
      if(a.candidates.length!==b.candidates.length) return a.candidates.length-b.candidates.length;
      const la=loadOf(a), lb=loadOf(b); if(la!==lb) return lb-la;
      if(a.size!==b.size) return a.size-b.size;
      return Math.random()-0.5;
    });
    const remaining=[...ordered];
    const countViable=b=>{ let n=0; for(const slot of b.candidates){ if(canPlaceJ(state,b,slot)&&!constraintViolationJ(state,b,slot.day,slot.start)) n++; } return n; };
    const viableCache=new Map(), dirty=new Set(remaining.map(b=>b.bid));
    while(remaining.length){
      let bi=0,bestC=Infinity;
      for(let i=0;i<remaining.length;i++){ const b=remaining[i]; if(dirty.has(b.bid)){ viableCache.set(b.bid,countViable(b)); dirty.delete(b.bid);} const c=viableCache.get(b.bid); if(c<bestC){bestC=c;bi=i;}}
      const b=remaining[bi]; remaining.splice(bi,1);
      const viable=b.candidates.filter(slot=>canPlaceJ(state,b,slot) && !constraintViolationJ(state,b,slot.day,slot.start));
      if(!viable.length){ failed.push(b); defFailCountJ[b.defId]=(defFailCountJ[b.defId]||0)+1; continue; }
      viable.sort((x,y)=>scoreSlotJ(state,b,x)-scoreSlotJ(state,b,y));
      const pickLimit=attempt<20?1:Math.min(flexible?9:4,viable.length);
      const slot=viable[Math.floor(Math.random()*pickLimit)];
      putBlockJ(state,b,slot); placed.push(b);
      for(const rb of remaining){ const shared=(rb.teachers||[rb.teacher]).some(t=>(b.teachers||[b.teacher]).includes(t)); if(shared|| (rb.schoolId===b.schoolId && rb.className===b.className) || (b.room&&rb.room===b.room)) dirty.add(rb.bid); }
    }
    return {state,placed,failed};
  }
  function resultCostJ(result){
    let cost=result.failed.length*100000;
    const courseDays={};
    for(const p of Object.values(result.state.placements)){ const key=defKeyJ(p.block); if(!courseDays[key]) courseDays[key]={}; courseDays[key][p.day]=(courseDays[key][p.day]||0)+1; cost+=p.start*0.2; }
    for(const m of Object.values(courseDays)) for(const cnt of Object.values(m)) if(cnt>1) cost+=(cnt-1)*500;
    cost+=countViolationsJ(result.state.placements).total*400;
    return cost;
  }
  let forceDeadlineJ=0;
  let origPosJ={};              // completeOnly'de bloğun ÖNCEKİ yeri; zincir mümkünse oraya koysun
  // Zincirde aynı anda kaldırılabilecek en fazla ders. 3'e çıkarmayı denedim: 6/6 koşuda
  // sonuç kötüleşti (derinlik-4 araması daha değerli), 2'de bırakıldı.
  const kickLimitJ=2;
  const slotCacheJ={};
  function candsForJ(b){
    // Anahtar bloğun üzerinde saklanır: aynı tanımdan gelseler de sınıf/öğretmen listesi
    // farklı olabilir (çizelgeden türetilen bloklar), o yüzden hepsi anahtara giriyor.
    // Not: _ck SAYILMAYAN (non-enumerable) olarak yazılır; {...blok} ile kopyalanan yeni bir
    // bloğa (farklı size!) eski anahtarın sızmaması için şart.
    let key=b._ck;
    if(!key){
      key=`${b.defId||b.bid}|${b.size}|${blockClasses(b).join(",")}|${(b.teachers||[b.teacher]).join(",")}`;
      try{ Object.defineProperty(b,"_ck",{value:key,enumerable:false,configurable:true,writable:true}); }catch(e){}
    }
    const hit=slotCacheJ[key]; if(hit) return hit;
    const sc=schoolById[b.schoolId]; const out=[];
    for(const day of sc.days) for(let start=1;start<=sc.periods-b.size+1;start++) if(baseCanPlaceJoint(b,day,start)) out.push({day,start});
    slotCacheJ[key]=out; return out;
  }
  /* Zincirleme yer açma (ejection chain) — YERİNDE mutasyonla.
     Referans Python çözücüsüyle aynı biçim: bir slottaki TÜM işgalciler (en fazla 2) aynı anda
     kaldırılır, blok konur, sonra işgalciler bir alt derinlikte yeniden yerleştirilir.
     Önceki hâli her adımda tek işgalci çıkarıp aynı bloğu yeniden deniyordu; slot boşalmadığı
     için derinlik boşa gidiyordu ve her özyinelemede tüm program sıfırdan kuruluyordu. */
  function forcePlaceMutJ(st,b,depth,moved){
    if(Date.now()>forceDeadlineJ) return false;
    const cands=candsForJ(b);
    const good=[];
    for(const c of cands) if(canPlaceJ(st,b,c)&&!constraintViolationJ(st,b,c.day,c.start)) good.push(c);
    if(good.length){
      const keep=origPosJ[b.bid];
      good.sort((x,y)=>{
        const kx=(keep&&keep.day===x.day&&keep.start===x.start)?0:1;
        const ky=(keep&&keep.day===y.day&&keep.start===y.start)?0:1;
        return kx-ky||scoreSlotJ(st,b,x)-scoreSlotJ(st,b,y);
      });
      putBlockJ(st,b,good[0]);
      return true;
    }
    if(depth<=0) return false;
    const sh=cands.slice();
    for(let i=sh.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; const t=sh[i]; sh[i]=sh[j]; sh[j]=t; }
    const limit=Math.min(sh.length,50);
    for(let i=0;i<limit;i++){
      if(Date.now()>forceDeadlineJ) return false;
      const c=sh[i];
      let occ=occupantsJ(st,b,c.day,c.start);
      if(!occ.length){
        // Buraya gelindiyse "good" boştu; işgalcisi de olmayan bir aday saati engelleyen tek şey
        // bir kısıttır (çoğunlukla öğle penceresi). Ek bir kısıt sınaması gerekmiyor.
        occ=constraintBlockersJ(st,b,c.day,c.start);
        if(!occ.length) continue;
      }
      if(occ.length>kickLimitJ) continue;
      let yetim=false; for(const o of occ) if(st.placements[o].block.orphan){ yetim=true; break; }
      if(yetim) continue;
      occ.sort((x,y)=>st.placements[x].block.size-st.placements[y].block.size);
      const snap=snapJ(st);
      const obs=occ.map(o=>st.placements[o].block);
      for(const ob of obs) removeBlockJ(st,ob);
      if(canPlaceJ(st,b,c)&&!constraintViolationJ(st,b,c.day,c.start)){
        putBlockJ(st,b,c);
        let ok=true;
        for(const ob of obs) if(!forcePlaceMutJ(st,ob,depth-1,moved)){ ok=false; break; }
        if(ok){ for(const o of occ) moved.add(o); return true; }
      }
      restoreJ(st,snap);
    }
    return false;
  }
  /* Kopyalayan eski arayüz (repairJ / ilsJ hâlâ kullanıyor).
     DİKKAT: imza değişti — 3. parametre artık en büyük zincir derinliği. */
  function forcePlaceJ(placements,block,maxDepth){
    const st=stateFromPlacementsJ(placements);
    if(!forcePlaceMutJ(st,block,maxDepth==null?2:maxDepth,new Set())) return null;
    const out={};
    for(const bid in st.placements){ const pl=st.placements[bid]; out[bid]={block:pl.block,day:pl.day,start:pl.start}; }
    return out;
  }
  // repair/improve/ils joint (basitleştirilmiş: repair ve ils yeterli)
  function repairJ(best){
    const t0=Date.now(); forceDeadlineJ=t0+12000;
    const st=stateFromPlacementsJ(best.state.placements);   // durum BİR kez kurulur
    let pending=[...new Set(best.failed.map(b=>b.defId))];
    let passes=0;
    while(pending.length && passes<10 && !solveCancelled){
      passes++; let improved=false; const still=[];
      if(Date.now()>forceDeadlineJ) break;
      for(const defId of pending){
        const sample=best.failed.find(b=>b.defId===defId);
        const hours=sample.hours, maxBlk=Math.max(1,Number(sample.block)||1);
        const alts=sample.blockFixed?[[hours]]:altDecompositionsJoint(hours,maxBlk);
        let done=false;
        for(const alt of alts){
          const snap=snapJ(st);
          // bu tanımın hâlihazırdaki parçalarını kaldır, bölüşümü baştan dene
          for(const bid of Object.keys(st.placements)) if(st.placements[bid].block.defId===defId) removeBlockJ(st,st.placements[bid].block);
          let ok=true;
          for(let k=0;k<alt.length;k++){
            const b={...sample,size:alt[k],bid:uid(),defId,partNo:k+1,schoolId:sample.schoolId,schoolName:sample.schoolName};
            if(!forcePlaceMutJ(st,b,2,new Set())){ ok=false; break; }
          }
          if(ok){ done=true; improved=true; break; }
          restoreJ(st,snap);
        }
        if(!done) still.push(defId);
      }
      pending=still; if(!improved) break;
    }
    const failed=best.failed.filter(b=>pending.includes(b.defId));
    // placed DİZİ olmalı (çağıranlar reduce/map uyguluyor).
    return {state:st, failed, placed:Object.values(st.placements).map(p=>p.block)};
  }
  function ilsJ(best, deadlineMs){
    const start=Date.now(); forceDeadlineJ=start+deadlineMs;
    let placements={}; for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let unplaced=best.failed.map(b=>({...b,bid:uid()}));
    let snap={placements:{...placements},unplaced:[...unplaced]};
    let lastImprove=start;
    while(Date.now()-start<deadlineMs && !solveCancelled){
      for(let i=0;i<unplaced.length;i++){ const np=forcePlaceJ(placements,unplaced[i],3); if(np){ placements=np; unplaced.splice(i,1); i--; } }
      if(!unplaced.length){ snap={placements:{...placements},unplaced:[]}; break; }
      if(unplaced.length<snap.unplaced.length){ snap={placements:{...placements},unplaced:[...unplaced]}; lastImprove=Date.now(); }
      if(Date.now()-lastImprove>15000) break;
      const stAll=stateFromPlacementsJ(placements);
      const toRemove=new Set();
      for(const u of unplaced){
        const sc=schoolById[u.schoolId];
        for(const day of sc.days) for(let s=1;s<=sc.periods-u.size+1;s++){
          if(!baseCanPlaceJoint(u,day,s)) continue;
          const bi=blockIntervalJoint(u,s);
          for(let o=0;o<u.size;o++){ const p=s+o; for(const cl of blockClasses(u)){ const cb=stAll.classBusy[`${u.schoolId}|${cl}|${day}|${p}`]; if(cb) toRemove.add(cb); } }
          if(bi){ for(const t of (u.teachers||[u.teacher])){ const arr=stAll.teacherIntervals[`${t}|${day}`]||[]; for(const iv of arr) if(iv.start<bi.end&&bi.start<iv.end){ for(const pid in stAll.placements){ const pl=stAll.placements[pid]; if((pl.block.teachers||[pl.block.teacher]).includes(t) && pl.day===day) toRemove.add(pid); } } } }
        }
      }
      const pids=Object.keys(placements); const extra=4+Math.floor(Math.random()*5);
      for(let k=0;k<extra;k++) toRemove.add(pids[Math.floor(Math.random()*pids.length)]);
      const kept={}; for(const pid in placements) if(!toRemove.has(pid)) kept[pid]=placements[pid];
      const ins=[]; for(const pid of toRemove){ const pl=placements[pid]; if(pl) ins.push(pl.block); } for(const u of unplaced) ins.push(u);
      ins.sort((a,b)=>blockCandsJ(a.defId,a.size,a.schoolId).length-blockCandsJ(b.defId,b.size,b.schoolId).length);
      let cur=kept; const newUnplaced=[];
      for(const b of ins){ const np=forcePlaceJ(cur,b,3); if(np) cur=np; else newUnplaced.push(b); }
      placements=cur; unplaced=newUnplaced;
    }
    const st=stateFromPlacementsJ(snap.placements);
    return {state:st, failed:snap.unplaced, placed:Object.values(snap.placements).map(p=>p.block)};
  }
  // ── Görev D: Eksikleri Tamamla (completeOnly) — mevcut programı koruyarak yalnız eksikleri yerleştir ──
  if(opts.completeOnly){
    _isSolving=true; liveBest=null; solveCancelled=false;
    showScheduleProgress("Eksikler tamamlanıyor: mevcut program korunuyor...",5);
    // forceDeadlineJ her tanım denemesinden önce KISA süreye kurulur (aşağıda):
    // tek bir forcePlaceJ çağrısı bölünemediği için uzun sınır sayfayı dakikalarca kilitler.
    // 1. Mevcut yerleşimi placements haline getir (aynı id = tek blok)
    const placements0={}; const origPos={};
    const defByIdC={}; for(const sc of activeSchools) for(const d of sc.defs||[]) defByIdC[d.id]=d;
    const assignedCountC={};
    for(const sc of activeSchools){
      const byId={};
      for(const l of sc.lessons||[]){ const lid=l.id||uid(); (byId[lid]=byId[lid]||[]).push(l); }
      for(const gid in byId){
        const grp=byId[gid];
        const l0=grp[0];
        const ts=lessonTeachers(l0);
        const key=refKey(l0.course,ts,lessonClasses(l0));
        const cands=(sc.defs||[]).filter(d=>refKey(d.course,defTeachers(d),defClasses(d))===key);
        if(!cands.length){
          // Yetim: yerinde bırak, asla oynatma
          const size=grp.length;
          let start=l0.period; for(const l of grp) start=Math.min(start,l.period);
          const blk={schoolId:sc.id,schoolName:sc.name,course:l0.course,className:l0.className,classNames:lessonClasses(l0),teachers:[...ts],teacher:ts[0]||null,teacher2:ts[1]||null,room:l0.room||null,size,day:l0.day,start,bid:gid,defId:null,hours:size,block:size,blockFixed:true,avail:null,orphan:true};
          placements0[gid]={block:blk,day:l0.day,start};
          origPos[gid]={day:l0.day,start};
          continue;
        }
        // Tekrarlı tanımda doluluğu en az olana ata
        cands.sort((a,b)=>((assignedCountC[a.id]||0)/Math.max(1,Number(a.hours)||1))-((assignedCountC[b.id]||0)/Math.max(1,Number(b.hours)||1)));
        const def=cands[0];
        assignedCountC[def.id]=(assignedCountC[def.id]||0)+grp.length;
        const dts=defTeachers(def);
        const size=grp.length;
        let start=l0.period; for(const l of grp) start=Math.min(start,l.period);
        const blk={schoolId:sc.id,schoolName:sc.name,course:def.course,className:def.className,classNames:(lessonClasses(l0).length?lessonClasses(l0):defClasses(def)),teachers:[...ts.length?ts:dts],teacher:(ts.length?ts:dts)[0]||null,teacher2:(ts.length?ts:dts)[1]||null,room:l0.room||def.room||null,size,day:l0.day,start,bid:gid,defId:def.id,hours:Math.max(1,Number(def.hours)||1),block:def.block,blockFixed:def.blockFixed,avail:def.avail};
        placements0[gid]={block:blk,day:l0.day,start};
        origPos[gid]={day:l0.day,start};
      }
    }
    const initialHours=activeSchools.reduce((s,sc)=>s+((sc.lessons||[]).length),0);
    const totalDefHours=activeSchools.reduce((s,sc)=>s+(sc.defs||[]).reduce((a,d)=>a+Math.max(1,Number(d.hours)||1),0),0);
    // 2. Eksik tanımları bul (tanımlı saat eksi çizelgedeki satır sayısı)
    const placedByDefC={};
    for(const gid in placements0){ const b=placements0[gid].block; if(b.defId) placedByDefC[b.defId]=(placedByDefC[b.defId]||0)+b.size; }
    const missingEntries=[];
    for(const sc of activeSchools) for(const def of sc.defs||[]){
      const need=Math.max(1,Number(def.hours)||1)-(placedByDefC[def.id]||0);
      if(need>0) missingEntries.push({def,sc,missing:need});
    }
    function altsForMissingC(miss,def){
      if(def.blockFixed) return [[miss]];
      const maxBlk=Math.max(1,Number(def.block)||1);
      const all=altDecompositionsJoint(miss,maxBlk);
      all.sort((a,b)=>a.length-b.length||b[0]-a[0]);
      return all.slice(0,80);
    }
    function makeMissingBlockC(def,sc,size){
      const ts=defTeachers(def);
      return {schoolId:sc.id,schoolName:sc.name,course:def.course,className:def.className,classNames:defClasses(def),teachers:[...ts],teacher:ts[0]||null,teacher2:ts[1]||null,room:def.room||null,size,bid:uid(),defId:def.id,hours:Math.max(1,Number(def.hours)||1),block:def.block,blockFixed:def.blockFixed,avail:def.avail};
    }
    function countMovedC(pl){ let n=0; for(const bid in origPos){ const cur=pl[bid]; if(!cur){n++;continue;} if(cur.day!==origPos[bid].day||cur.start!==origPos[bid].start) n++; } return n; }
    function movedInStateC(st){ let n=0; for(const bid in origPos){ const cur=st.placements[bid]; if(!cur){n++;continue;} if(cur.day!==origPos[bid].day||cur.start!==origPos[bid].start) n++; } return n; }
    /* 3. Eksikleri yerleştir.
       Referans (Python) çözücüsüyle aynı akış: tek bir DEĞİŞEBİLİR durum üzerinde çalışılır,
       her bölüşüm için derinlik 0→4 tırmandırılır, başarısız denemede anlık görüntüye dönülür.
       Önceki hâl her adımda programın kopyasını çıkarıp durumu sıfırdan kuruyordu; bir tur
       dakikalar sürdüğü için tur sayısı bir elin parmaklarını geçmiyordu. */
    origPosJ=origPos;
    const stC=stateFromPlacementsJ(placements0);
    const snap0=snapJ(stC);
    let bestSnap=snap0;
    let bestUnplacedDefs=[...missingEntries];
    let bestMoved=0;
    let bestUnplacedCount=missingEntries.length;
    // Ölçüt SAAT olmalı, tanım sayısı değil: 2 tanım x 1'er saat ile 2 tanım x (1+3) saat
    // aynı sayılıyordu ve arama 639'dan 637'ye DÜŞEBİLİYORDU (600 sn'lik koşuda görüldü).
    let bestEksikSaat=missingEntries.reduce((a,e)=>a+e.missing,0);
    let roundsC=0;
    /* BİTİRİŞ ARAMASI.
       Normal tur her seferinde en baştan başlıyor: 12 eksik dersin 10'unu yeniden yerleştirip
       aynı son 2'de takılıyor, yani bütçenin çoğu zaten çözülmüş kısmı tekrar çözmeye gidiyor.
       Bu faz EN İYİ duruma dönüp bütün bütçeyi kalan derslere ayırır. Problem küçüldüğü için
       zincir çok daha derine inebilir (turdaki 4 yerine 5-10) ve her deneme rastgele yeniden
       başladığı için bu, tek bir dersin üstünde onlarca bağımsız derin arama demektir.
       Turların ARASINDA çağrılır: iki strateji de bütçeden pay alsın. */
    const derinliklerB=[4,5,6,8,10];
    let bTur=0;
    async function bitirisAramasi(sureMs){
      const bitis=Math.min(hardStop, Date.now()+sureMs);
      // Plato yürüyüşü: her denemede aynı "en iyi"ye dönersek hep aynı komşuluğu tarıyoruz.
      // Eşit sonuç veren farklı bir dizilim bulunca ARADA SIRA ona geçiyoruz; en iyi kayıt
      // (bestSnap) bozulmuyor, yalnız arama tabanı değişiyor. Ölçümde asıl kazancı bu verdi.
      let calisma=bestSnap, calismaKalan=bestUnplacedDefs, calismaEksik=bestEksikSaat;
      while(!solveCancelled && Date.now()<bitis && bestEksikSaat>0){
        bTur++;
        restoreJ(stC,calisma);
        const md=derinliklerB[bTur%derinliklerB.length];
        const kalanlar=[...calismaKalan].sort(()=>Math.random()-0.5);
        const yerlesmeyen=[];
        let tamGezildi=true;
        for(const entry of kalanlar){
          if(solveCancelled||Date.now()>bitis){ tamGezildi=false; break; }
          if(Date.now()-lastYield>40){ await waitFrame(); lastYield=Date.now(); if(solveCancelled){ tamGezildi=false; break; } }
          const alts=altsForMissingC(entry.missing,entry.def);
          let done=false;
          for(const alt of alts){
            if(done||solveCancelled||Date.now()>bitis) break;
            const snapA=snapJ(stC);
            forceDeadlineJ=Math.min(bitis, Date.now()+3000);
            let ok=true;
            for(const sz of alt){
              const blk=makeMissingBlockC(entry.def,entry.sc,sz);
              if(!forcePlaceMutJ(stC,blk,md,new Set())){ ok=false; break; }
            }
            if(ok){ done=true; break; }
            restoreJ(stC,snapA);
          }
          if(!done) yerlesmeyen.push(entry);
        }
        // Yarıda kesilen tur kabul edilmemeli: denenmemiş dersler yerlesmeyen'e girmediği için
        // eksik saat sahte biçimde düşük çıkar (tur döngüsünde aynı hatayı düzeltmiştim).
        const bEksik=yerlesmeyen.reduce((a,e)=>a+e.missing,0);
        if(tamGezildi){
          if(bEksik<bestEksikSaat){
            bestSnap=snapJ(stC); bestUnplacedDefs=[...yerlesmeyen]; bestUnplacedCount=yerlesmeyen.length;
            bestEksikSaat=bEksik; bestMoved=movedInStateC(stC);
            calisma=bestSnap; calismaKalan=bestUnplacedDefs; calismaEksik=bEksik;
            showScheduleProgress(`${Date.now()>softAt?"⏳ ":""}Bitiriş araması: ${bestEksikSaat} saat kaldı • ${Math.round((Date.now()-startedAt)/1000)} sn`,95);
          }else if(bEksik<=calismaEksik&&Math.random()<0.5){
            calisma=snapJ(stC); calismaKalan=[...yerlesmeyen]; calismaEksik=bEksik;   // plato adımı
          }else if(bTur%17===0){
            calisma=bestSnap; calismaKalan=bestUnplacedDefs; calismaEksik=bestEksikSaat;  // ara sıra en iyiye dön
          }
        }
        await waitFrame(); lastYield=Date.now();
      }
      restoreJ(stC,bestSnap);
    }
    if(!missingEntries.length){
      bestUnplacedDefs=[]; bestUnplacedCount=0; bestEksikSaat=0; bestMoved=0;
    }else{
      let sonIyilesmeC=Date.now();
      const ONARIM_STALL_MS=REPAIR_STALL_MS;
      while(!solveCancelled && Date.now()<hardStop){
        if(Date.now()-sonIyilesmeC>ONARIM_STALL_MS) break;
        roundsC++;
        const turBasi=Date.now();
        restoreJ(stC,snap0);
        const order=[...missingEntries].sort(()=>Math.random()-0.5);
        const unplaced=[];
        // Yarıda kesilen tur "en iyi" sayılmamalı: denenmemiş tanımlar unplaced'a hiç girmediği
        // için eksik sayısı sahte biçimde düşük çıkıyor ve iyi sonucun üstüne yazıyordu.
        let tamTur=true;
        for(const entry of order){
          if(solveCancelled||Date.now()>hardStop){ tamTur=false; break; }
          // Arayüze en geç 40 ms'de bir nefes ver (tarayıcı "yanıt vermiyor" demesin).
          if(Date.now()-lastYield>40){ await waitFrame(); lastYield=Date.now(); if(solveCancelled){ tamTur=false; break; } }
          const alts=altsForMissingC(entry.missing,entry.def);
          let done=false;
          for(const alt of alts){
            if(done||solveCancelled||Date.now()>hardStop) break;
            const snapA=snapJ(stC);
            for(let md=0;md<=4;md++){
              forceDeadlineJ=Math.min(hardStop, Date.now()+4000);
              let ok=true;
              for(const sz of alt){
                const blk=makeMissingBlockC(entry.def,entry.sc,sz);
                if(!forcePlaceMutJ(stC,blk,md,new Set())){ ok=false; break; }
              }
              if(ok){ done=true; break; }
              restoreJ(stC,snapA);
              if(Date.now()>hardStop) break;
            }
          }
          if(!done) unplaced.push(entry);
        }
        /* Hedefli yıkım-onarım DENENDİ, KALDIRILDI.
           Fikir: kalan tanımın öğretmenine/dersliğine ait bütün dersleri söküp baştan yerleştirmek.
           Ölçüm (6 koşu x 240 sn): sonuç iyileşmedi, tur sayısı 8'den 4'e düştü — ~40 bloğu birden
           yeniden yerleştirmek çok pahalı ve "hepsi girmezse hiçbiri" kuralı neredeyse hiç tutmuyor.
           Kazanan yöntem, çok sayıda kısa tur + bağımsız işçiler (paralel arama). */
        const moved=movedInStateC(stC);
        const eksikSaat=unplaced.reduce((a,e)=>a+e.missing,0);
        if(tamTur&&(eksikSaat<bestEksikSaat||(eksikSaat===bestEksikSaat&&moved<bestMoved))){
          bestSnap=snapJ(stC); bestUnplacedDefs=[...unplaced]; bestUnplacedCount=unplaced.length; bestEksikSaat=eksikSaat; bestMoved=moved; sonIyilesmeC=Date.now();
        }
        let plcH=0; for(const bid in stC.placements) plcH+=stC.placements[bid].block.size;
        liveBest={state:stC,placed:[],failed:unplaced,forcedFailed:[],allFailed:unplaced,placedBlocks:Object.keys(stC.placements).length,totalBlocks:Object.keys(stC.placements).length+unplaced.length,placedHours:plcH,totalHours:totalDefHours,isJoint:true};
        showScheduleProgress(`${Date.now()>softAt?"⏳ ":""}Tur ${roundsC}: en iyi ${bestEksikSaat} saat eksik, ${bestMoved} ders oynatıldı • ${Math.round((Date.now()-startedAt)/1000)} sn — boşluklar kapatılana kadar devam ediyor, istediğin an "Bitir" ile kaydedebilirsin`,Math.min(92,10+roundsC*3));
        await waitFrame(); lastYield=Date.now();
        if(bestEksikSaat===0) break;   // tam yerleşim bulundu; oynatma sayısını cila fazı düşürür
        if(Date.now()>hardStop) break;
        /* Bütçe paylaşımı. Ölçüm: 640/641 durumundan başlayıp bütün bütçeyi tek eksik derse
           veren 6 koşudan 3'ü tam yerleşimi buldu (biri 11 sn'de). Yani arama yeteneği var,
           eksik olan bütçeydi: az sayıda ders kalınca baştan çözmek boşa gidiyor, o yüzden
           kalan 4 saatin altına düşünce ağırlık bitiriş aramasına kayıyor. */
        if(bestEksikSaat>0&&bestEksikSaat<=8){
          const pay = bestEksikSaat<=4 ? 90000 : Math.max(15000,Math.round((Date.now()-turBasi)*0.8));
          await bitirisAramasi(pay);
          if(bestEksikSaat===0) break;
        }
      }
    }
    // Turlar tıkandıysa kalan bütçenin bir kısmını son bir derin aramaya ver.
    if(bestEksikSaat>0&&!solveCancelled&&Date.now()<hardStop) await bitirisAramasi(300000);
    /* 4. Cila: yeri değişmiş dersleri eski yerine döndür (gerekirse 1-2 dersi zincirle taşıyarak).
       Yalnız toplam değişiklik AZALIYORSA kabul edilir. */
    restoreJ(stC,bestSnap);
    for(let round=0;round<12;round++){
      if(solveCancelled||Date.now()>hardStop) break;
      const movedBids=Object.keys(origPos).filter(bid=>{ const cur=stC.placements[bid]; return cur&&(cur.day!==origPos[bid].day||cur.start!==origPos[bid].start); });
      if(!movedBids.length) break;
      movedBids.sort(()=>Math.random()-0.5);
      let changed=false;
      for(const bid of movedBids){
        if(solveCancelled||Date.now()>hardStop) break;
        if(Date.now()-lastYield>40){ await waitFrame(); lastYield=Date.now(); if(solveCancelled) break; }
        const cur=stC.placements[bid]; if(!cur) continue;
        const orig=origPos[bid];
        if(cur.day===orig.day&&cur.start===orig.start) continue;
        const blk=cur.block;
        if(blk.orphan) continue;
        if(!baseCanPlaceJoint(blk,orig.day,orig.start)) continue;
        const before=movedInStateC(stC);
        const snapP=snapJ(stC);
        removeBlockJ(stC,blk);
        const occ=occupantsJ(stC,blk,orig.day,orig.start);
        let uygun=occ.length<=2;
        for(const o of occ) if(stC.placements[o].block.orphan){ uygun=false; break; }
        if(uygun){
          const obs=occ.map(o=>stC.placements[o].block);
          for(const ob of obs) removeBlockJ(stC,ob);
          if(canPlaceJ(stC,blk,{day:orig.day,start:orig.start})&&!constraintViolationJ(stC,blk,orig.day,orig.start)){
            putBlockJ(stC,blk,{day:orig.day,start:orig.start});
            forceDeadlineJ=Math.min(hardStop, Date.now()+3000);
            let ok=true;
            for(const ob of obs) if(!forcePlaceMutJ(stC,ob,2,new Set())){ ok=false; break; }
            if(ok&&movedInStateC(stC)<before){ changed=true; continue; }
          }
        }
        restoreJ(stC,snapP);
      }
      if(!changed) break;
    }
    const polished={};
    for(const bid in stC.placements){ const pl=stC.placements[bid]; polished[bid]={block:pl.block,day:pl.day,start:pl.start}; }
    origPosJ={};
    const finalMoved=countMovedC(polished);
    const resultHours=Object.values(polished).reduce((s,p)=>s+p.block.size,0);
    const addedHours=resultHours-initialHours;
    // 5. Asla kötüleştirme
    if(resultHours<initialHours){
      _isSolving=false;
      toast("Eksikler bu kısıtlarla yerleştirilemedi; program değiştirilmedi.","err");
      return {totalBlocks:Object.keys(polished).length+bestUnplacedDefs.length,activeBlocks:Object.keys(polished).length,placedBlocks:Object.keys(placements0).length,totalHours:totalDefHours,placedHours:initialHours,forcedFailed:[],failed:bestUnplacedDefs.map(e=>({...e.def,size:e.missing,schoolId:e.sc.id,schoolName:e.sc.name})),allFailed:bestUnplacedDefs.map(e=>({...e.def,size:e.missing,schoolId:e.sc.id,schoolName:e.sc.name})),capacityIssues:[],validationWarnings:[],flexible,attempts:roundsC,timedOut:(Date.now()>softAt),isJoint:true,completed:{eklenenSaat:0,oynatilanDers:0},lessons:activeSchools.flatMap(sc=>(sc.lessons||[]).map(l=>({...l})))};
    }
    for(const sc of activeSchools) sc.lessons=[];
    for(const p of Object.values(polished)){
      const b=p.block; const sc=schoolById[b.schoolId]; if(!sc) continue;
      for(let o=0;o<b.size;o++){
        const lesson={id:b.bid,course:b.course,className:b.className,day:p.day,period:p.start+o,hours:b.size,part:o+1,room:b.room||null};
        setTeachers(lesson,b.teachers||[b.teacher]);
        setClasses(lesson, blockClasses(b));
        sc.lessons.push(lesson);
      }
    }
    saveState(); renderDefs(); refresh();
    const failedC=bestUnplacedDefs.map(e=>({...e.def,size:e.missing,schoolId:e.sc.id,schoolName:e.sc.name}));
    const resultC={
      totalBlocks:Object.keys(polished).length+failedC.length,activeBlocks:Object.keys(polished).length,placedBlocks:Object.keys(polished).length,
      totalHours:totalDefHours,placedHours:resultHours,
      forcedFailed:[],failed:failedC,allFailed:[...failedC],capacityIssues:[],validationWarnings:[],constraintViolations:countViolationsJ(polished),flexible,attempts:roundsC,timedOut:(Date.now()>softAt),isJoint:true,
      lessons:activeSchools.flatMap(sc=>sc.lessons.map(l=>({...l}))),
      completed:{eklenenSaat:addedHours,oynatilanDers:finalMoved}
    };
    liveBest={state:stateFromPlacementsJ(polished),placed:[],failed:failedC,forcedFailed:[],allFailed:[...failedC],placedBlocks:resultC.placedBlocks,totalBlocks:resultC.totalBlocks,placedHours:resultHours,totalHours:totalDefHours,isJoint:true};
    // J3: completeOnly bitişi — yerleşemeyen tanımları kalıcı hatırla; tam yerleşimde temizle
    saveHardDefs(failedC.length?failedC.map(b=>b.defId||b.id).filter(Boolean):[]);
    _isSolving=false;
    if(!opts.silentResult){
      showScheduleResult(resultC);
      if(!failedC.length) toast(`✓ Eksikler tamamlandı: +${addedHours} saat, ${finalMoved} ders yer değiştirdi.`,"ok");
      else toast(`⚠ Eksiklerin bir kısmı yerleşti: +${addedHours} saat, ${finalMoved} ders yer değiştirdi. Yerleşmeyen ${failedC.length} tanım.`,"err");
    }
    return resultC;
  }
  // ── LİMİTSİZ ARAMA (joint): kullanıcı Bitir diyene, tamamı yerleşene veya 1 saatlik güvenlik ağı (HARD_STOP_MS) dolana kadar ──
  _isSolving=true; liveBest=null; solveCancelled=false;
  showScheduleProgress("Ortak dağıtım hazırlanıyor (tüm okullar birlikte)...",0);
  let best=null,bestCost=Infinity,lastImprove=0,attemptsRun=0, a=0, stuckNow=0, lastIlsAt=0;
  let timedOut=false; let stalled=false; let lastImproveAt=Date.now();
  while(true){
    attemptsRun=a+1; if(solveCancelled) break;
    if(!timedOut && Date.now()>softAt) timedOut=true; // yumuşak eşik: ⏳ uyarısı (arama durmaz)
    if(Date.now()>hardStop) break;                    // güvenlik ağı (1 saat)
    const result=runAttemptJ(a);
    const cost=resultCostJ(result);
    if(!best||result.failed.length<best.failed.length||(result.failed.length===best.failed.length&&cost<bestCost)){
      // Tıkanma saati YALNIZ eksik sayısı azalınca sıfırlanır. Maliyet (ders saatlerinin
      // erkene alınması gibi kozmetik kazançlar) sayacı sürekli diri tutuyordu; hiç
      // tamamlanmayan sıfırdan faz bu yüzden bütçeyi bırakmıyordu.
      const dahaAzEksik = !best || result.failed.length < best.failed.length;
      best=result; bestCost=cost; lastImprove=a; if(dahaAzEksik) lastImproveAt=Date.now();
      const totH=allBlocksJ.reduce((s,b)=>s+b.size,0);
      const plcH=best.placed.reduce((s,b)=>s+b.size,0);
      liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:totH, isJoint:true};
    }
    bestFailedDefsJ=new Set(best.failed.map(b=>b.defId));
    stuckNow=a-lastImprove;
    if(!result.failed.length) break;
    // Tıkandıysa ana aramadan çık: sonraki fazlar (repair/improve/ils/ek turlar/onarım
    // zinciri) boşluğu kapatmakta çok daha etkili. Kullanıcı Bitir demeden durmayız,
    // yalnız stratejiyi değiştiririz.
    if(Date.now()-lastImproveAt>STALL_MS){ stalled=true; break; }
    // Derin tıkanmada yapısal değişiklik: ILS turu (en fazla her 400 tıkanma denemesinde bir)
    if(stuckNow>400 && a-lastIlsAt>400 && !solveCancelled && Date.now()<hardStop){
      lastIlsAt=a;
      showScheduleProgress(`Ortak dağıtım denemesi ${a+1}: en iyi ${best.placed.length}/${blockCountBaseJ} blok • eksik ${best.failed.length} blok • derin arama turu • ${Math.round((Date.now()-startedAt)/1000)} sn`,50+Math.min(42,((a%400)/400)*42));
      await waitFrame();
      const rI=ilsJ(best,8000);
      if(rI.failed.length<best.failed.length||(rI.failed.length===best.failed.length&&resultCostJ(rI)<bestCost)){
        best=rI; bestCost=resultCostJ(best); lastImprove=a;
        const plcH=best.placed.reduce((s,b)=>s+b.size,0);
        liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), isJoint:true};
      }
      await waitFrame();
      if(!best.failed.length) break;
      if(solveCancelled) break;
    }
    // Sayfa kilitlenmesin diye YIELD süreye bağlıdır: her modda en geç 40 ms'de bir tarayıcıya
    // kontrol geri verilir. perfMode yalnızca ilerleme METNİNİN ne sıklıkta yenileneceğini
    // belirler (asıl maliyet DOM güncellemesidir). Önceden yield de perfMode'a bağlıydı;
    // Turbo'da 100 deneme boyunca hiç nefes alınmadığı için tarayıcı
    // "sayfa yanıt vermiyor" uyarısı veriyordu.
    const yaziZamani = (Date.now()-lastText > perfTextMs());
    if(yaziZamani){
      lastText=Date.now();
      const stuck=a-lastImprove;
      const pct=50+Math.min(42,((a%400)/400)*42);
      showScheduleProgress(`${timedOut?"⏳ ":""}Ortak dağıtım denemesi ${a+1}: en iyi ${best.placed.length}/${blockCountBaseJ} blok • eksik ${best.failed.length} blok • ${stuck} denemedir iyileşme yok • ${Math.round((Date.now()-startedAt)/1000)} sn — tamamı yerleşene kadar devam ediyor, istediğin an "Bitir" ile kaydedebilirsin`,pct);
    }
    if(yaziZamani || Date.now()-lastYield>40){
      await waitFrame(); lastYield=Date.now();
      if(solveCancelled) break;
    }
    a++;
  }
  if(best && best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Ortak dağıtım: yerleşmeyenler için alternatif bloklar deneniyor...",94); await waitFrame();
    const r=repairJ(best); if(r.failed.length<best.failed.length||(r.failed.length===best.failed.length&&resultCostJ(r)<bestCost)){ best=r; bestCost=resultCostJ(best); const plcH=best.placed.reduce((s,b)=>s+b.size,0); liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), isJoint:true}; }
  }
  if(best && best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Ortak dağıtım: derin arama...",97); await waitFrame();
    const r=ilsJ(best,20000); if(r.failed.length<best.failed.length||(r.failed.length===best.failed.length&&resultCostJ(r)<bestCost)){ best=r; bestCost=resultCostJ(best); const plcH=best.placed.reduce((s,b)=>s+b.size,0); liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), isJoint:true}; }
  }
  let extraRound=0;
  // Ek turlar sonsuza kadar sürmesin: iyileşme getirmeyen tur sayısı sınırı aşınca çıkılır
  // ki OTOMATİK ONARIM TURU'na (chain) sıra gelsin — ölçümde boşluğu asıl kapatan faz o.
  let kisirTur=0;
  const KISIR_TUR_SINIRI=4;
  while(best && best.failed.length>0 && !solveCancelled){
    extraRound++;
    if(!timedOut && Date.now()>softAt) timedOut=true; // yumuşak eşik: ⏳ uyarısı (arama durmaz)
    if(Date.now()>hardStop) break;                    // güvenlik ağı (1 saat)
    // Ek turlar da tıkanmışsa bekletme: otomatik onarım turuna geç.
    if(Date.now()-lastImproveAt>STALL_MS) break;
    const pct=92+(extraRound%5);
    showScheduleProgress(`${timedOut?"⏳ ":""}Ortak dağıtım ek tur ${extraRound}: en iyi ${best.placed.length}/${blockCountBaseJ} blok (${best.failed.length} eksik) • ${Math.round((Date.now()-startedAt)/1000)} sn — tamamı yerleşene kadar devam ediyor, istediğin an "Bitir" ile kaydedebilirsin`,pct);
    await waitFrame();
    for(let k=0;k<200;k++){ if(solveCancelled) break; if(Date.now()>hardStop) break; if(Date.now()-lastImproveAt>STALL_MS) break; const r=runAttemptJ(a+k+extraRound*1000); const c=resultCostJ(r); if(!best||r.failed.length<best.failed.length||(r.failed.length===best.failed.length&&c<bestCost)){ const azaldi=!best||r.failed.length<best.failed.length; best=r; bestCost=c; lastImprove=a+k; if(azaldi) lastImproveAt=Date.now(); const plcH=best.placed.reduce((s,b)=>s+b.size,0); liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), isJoint:true}; } stuckNow=(a+k)-lastImprove; if(!r.failed.length){ best=r; break; } if(stuckNow>400 && (a+k)-lastIlsAt>400 && !solveCancelled && Date.now()<hardStop){ lastIlsAt=a+k; showScheduleProgress(`Ortak dağıtım ek tur ${extraRound}: derin arama turu • en iyi ${best.placed.length}/${blockCountBaseJ} blok (${best.failed.length} eksik) • ${Math.round((Date.now()-startedAt)/1000)} sn`,92+(extraRound%5)); await waitFrame(); const rI=ilsJ(best,8000); if(rI.failed.length<best.failed.length||(rI.failed.length===best.failed.length&&resultCostJ(rI)<bestCost)){ const azaldi2=rI.failed.length<best.failed.length; best=rI; bestCost=resultCostJ(best); lastImprove=a+k; if(azaldi2) lastImproveAt=Date.now(); const plcH=best.placed.reduce((s,b)=>s+b.size,0); liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), isJoint:true}; } await waitFrame(); if(!best.failed.length) break; if(solveCancelled) break; } if(k%perfInterval()===0 || Date.now()-lastYield>40){ await waitFrame(); lastYield=Date.now(); } }
    a+=200; if(!best.failed.length) break; if(solveCancelled) break;
    const oncekiEksik=best.failed.length;
    const r2=ilsJ(best,8000); if(r2.failed.length<best.failed.length||(r2.failed.length===best.failed.length&&resultCostJ(r2)<bestCost)){ best=r2; bestCost=resultCostJ(best); const plcH=best.placed.reduce((s,b)=>s+b.size,0); liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:[...forcedFailedJ,...best.failed], placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:plcH, totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), isJoint:true}; } if(!best.failed.length) break;
    if(best.failed.length>=oncekiEksik){ kisirTur++; } else { kisirTur=0; }
    if(kisirTur>=KISIR_TUR_SINIRI) break;
    await waitFrame();
  }
  if(!best){
    if(solveCancelled){ toast("Dağıtım durduruldu.","err"); return {totalBlocks:allBlocksJ.length,activeBlocks:blockCountBaseJ,placedBlocks:0,totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0),placedHours:0,forcedFailed:forcedFailedJ,failed:[],allFailed:[...forcedFailedJ],capacityIssues:capacityIssuesJ,validationWarnings:[],flexible,attempts:attemptsRun,lessons:[],isJoint:true}; }
    best={state:blankStateJ(),placed:[],failed:[]};
  }
  // tüm okulların lessons'ını yaz
  for(const sc of activeSchools) sc.lessons=[];
  for(const p of Object.values(best.state.placements)){
    const b=p.block; const sc=schoolById[b.schoolId];
    for(let o=0;o<b.size;o++){
      const lesson={id:b.bid, course:b.course, className:b.className, day:p.day, period:p.start+o, hours:b.size, part:o+1, room:b.room||null};
      setTeachers(lesson, b.teachers||[b.teacher]);
      setClasses(lesson, blockClasses(b));
      sc.lessons.push(lesson);
    }
  }
  saveState(); renderDefs(); refresh();
  const allFailedJ=[...forcedFailedJ,...best.failed];
  const resultJ={
    totalBlocks:allBlocksJ.length,activeBlocks:blockCountBaseJ,placedBlocks:best.placed.length,
    totalHours:allBlocksJ.reduce((s,b)=>s+b.size,0), placedHours:activeSchools.reduce((s,sc)=>s+sc.lessons.length,0),
    forcedFailed:forcedFailedJ,failed:best.failed,allFailed:allFailedJ,capacityIssues:capacityIssuesJ,validationWarnings:[],constraintViolations:countViolationsJ(best.state.placements),flexible,attempts:attemptsRun,timedOut,isJoint:true,lessons:activeSchools.flatMap(sc=>sc.lessons.map(l=>({...l})))
  };
  liveBest={state:best.state, placed:best.placed, failed:best.failed, forcedFailed:forcedFailedJ, allFailed:allFailedJ, placedBlocks:best.placed.length, totalBlocks:allBlocksJ.length, placedHours:resultJ.placedHours, totalHours:resultJ.totalHours, isJoint:true};
  let finalResult=resultJ;
  // ── OTOMATİK ARTIMLI ONARIM: sıfırdan dağıtım eksikle bittiyse, mevcut yerleşim lessons'a
  // yazılmış durumdayken completeOnly modda bir onarım turu zincirle. _chained bayrağı
  // zincirlemeyin yalnız bir kez yapılmasını sağlar (sonsuz özyineleme yok). ──
  if(best.failed.length>0 && !solveCancelled && !opts.completeOnly && !opts._chained){
    showScheduleProgress("Kalan dersler için onarım turu: mevcut yerleşim korunarak boşluklar kapatılıyor...",95);
    await waitFrame();
    const repaired=await solveAllJoint({...opts, completeOnly:true, silentResult:true, _chained:true});
    if(repaired && typeof repaired.totalBlocks==="number" && (repaired.failed||[]).length<=best.failed.length){
      finalResult={...repaired, chained:true};
    }
  }
  // J3: dağıtım bitti — yerleşemeyen tanımları kalıcı hatırla; tam yerleşimde temizle
  saveHardDefs((finalResult.allFailed||[]).length?(finalResult.allFailed).map(b=>b.defId||b.id).filter(Boolean):[]);
  if(!opts.silentResult){
    _isSolving=false;
    // joint sonuç raporu: her okul için özet
    showScheduleResult(finalResult);
    // ek özet (okul bazlı) zaten showScheduleResult içinde değil, toast yeterli
    if((finalResult.allFailed||[]).length===0) toast(`✓ Ortak dağıtım: tüm okullar yerleşti (${finalResult.placedHours} saat).`,"ok");
    else toast(`⚠ Ortak dağıtım: ${finalResult.placedHours}/${finalResult.totalHours} saat yerleşti. Yerleşmeyen ${(finalResult.allFailed||[]).length} blok.`,"err");
  }
  return finalResult;
}

/* ============================================================
   GÖRÜNÜM
   ============================================================ */
/* Okul adları koda gömülü OLMAMALI: "ORTAOKUL"/"LİSE" bu kullanıcının okullarının adıydı,
   başka birinin okulları başka adlar taşıyor ve o sekmeler boş geliyordu. Artık hem sekmeler
   hem rozetler gerçek okul listesinden üretiliyor. */
function okulRozetleri(){
  const m={}, kullanilan={};
  // Boş okullar harf kapmasın: varsayılan "Okul" yüzünden "ORTAOKUL" rozeti "OR"a düşüyordu.
  const dolu=S.schools.filter(x=>(x.defs||[]).length||(x.lessons||[]).length);
  for(const sc of (dolu.length?dolu:S.schools)){
    let r=(sc.name||"?").trim().charAt(0).toLocaleUpperCase("tr");
    if(kullanilan[r]) r=(sc.name||"?").trim().slice(0,2).toLocaleUpperCase("tr");
    let i=2; while(kullanilan[r]){ r=(sc.name||"?").trim().slice(0,++i).toLocaleUpperCase("tr")||String(i); }
    kullanilan[r]=1; m[sc.name]=r;
  }
  return m;
}
function syncViewTabs(){
  for(const id of ["teacherTabs","roomTabs"]){
    const kap=$(id); if(!kap) continue;
    const birlikte=kap.querySelector('[data-tmode="birlikte"]'); if(!birlikte) continue;
    // Önceki okul sekmelerini temizle ("birlikte" ve sekme olmayan düğmeler kalsın)
    for(const b of [...kap.querySelectorAll("[data-tmode]")]) if(b.dataset.tmode!=="birlikte") b.remove();
    const aktif=(id==="teacherTabs")?teacherViewMode:roomViewMode;
    for(const sc of S.schools){
      if(!(sc.defs||[]).length && !(sc.lessons||[]).length && S.schools.length>1) continue;
      const b=document.createElement("button");
      b.className="tab"+(aktif===sc.id?" active":"");
      b.dataset.tmode=sc.id;
      b.textContent=sc.name;
      kap.insertBefore(b,birlikte);
    }
    birlikte.classList.toggle("active", aktif==="birlikte");
  }
}
function tabOkulu(mod){ return mod==="birlikte"?null:(S.schools.find(s=>s.id===mod)||null); }
function refresh(){
  syncViewTabs();
  renderSideLists();
  const mode=document.querySelector(".nav-btn.active")?.dataset.view||"school";

  if(mode==="school"){renderGrid($("schoolGrid"),"school",null);renderSchoolTimes();}
  else if(mode==="lessons"){renderDefs();renderSideLists();if(document.querySelector("#ltab-classes")?.classList.contains("active")) renderClassDefsOverview();}
  else if(mode==="classes"){
    const sel=curSchool().selectedClass;
    $("classViewTitle").textContent=sel?`Sınıf: ${sel}`:"Sınıf Seçin";
    if(sel){renderGrid($("classGrid"),"class",sel);renderEntityDefs("class",sel);}
    else{$("classGrid").innerHTML='<div class="empty">Soldan bir sınıf seçin.</div>';$("classDefsList").innerHTML="";}
  }else if(mode==="teachers"){
    const sel=S.selectedTeacher;
    $("teacherViewTitle").textContent=sel?`Öğretmen: ${sel}`:"Öğretmen Seçin";
    if(sel){
      let sf=null;
      if(teacherViewMode!=="birlikte"){ sf=tabOkulu(teacherViewMode); renderGrid($("teacherGrid"),"teacher",sel,sf); }
      else{ renderTeacherCombined($("teacherGrid"),sel,"teacher"); }
      renderEntityDefs("teacher",sel,sf?sf.name:null);
    }
    else{$("teacherGrid").innerHTML='<div class="empty">Soldan bir öğretmen seçin.</div>';$("teacherDefsList").innerHTML="";}
  }else if(mode==="rooms"){
    renderRoomList();
    const sel=S.selectedRoom;
    $("roomViewTitle").textContent=sel?`Derslik: ${sel}`:"Derslik Seçin";
    if(sel){
      const sf=tabOkulu(roomViewMode);
      renderTeacherCombined($("roomGrid"),sel,"room",sf?sf.name:null);
      renderRoomDefs(sel,sf?sf.name:null);
    }
    else{$("roomGrid").innerHTML='<div class="empty">Soldan bir derslik seçin.</div>';$("roomDefsList").innerHTML="";}
  }else if(mode==="constraints"){
    renderConstraints();
  }else if(mode==="status"){
    renderStatus();
  }
}

// Durum raporları
// Sınıfın haftalık açık (ders yapılabilir) saat sayısı — kapasite
function classOpenSlots(sc, cl){
  let n=0;
  const days=sc.days||SCHOOL_DFLT.days, periods=sc.periods||10;
  const cc=(sc.classClosed&&sc.classClosed[cl])||{};
  for(const day of days) for(let p=1;p<=periods;p++){
    if(sc.schoolClosed&&sc.schoolClosed[`${day}|${p}`]) continue;
    if(cc[`${day}|${p}`]) continue;
    n++;
  }
  return n;
}
// Öğretmenin haftalık ders verebileceği saat kapasitesi (o okulda)
function teacherCap(sc, t, classes){
  let cap=0;
  const days=sc.days||SCHOOL_DFLT.days, periods=sc.periods||10;
  const tc=(S.teacherClosed&&S.teacherClosed[t]&&S.teacherClosed[t][sc.id])||{};
  for(const day of days){
    let tOpen=0, anyOpen=0;
    for(let p=1;p<=periods;p++){
      if(sc.schoolClosed&&sc.schoolClosed[`${day}|${p}`]) continue;
      if(tc[`${day}|${p}`]) continue;
      tOpen++;
      for(const cl of classes){ if(!(((sc.classClosed&&sc.classClosed[cl])||{})[`${day}|${p}`])){ anyOpen++; break; } }
    }
    cap+=Math.min(tOpen,anyOpen);
  }
  return cap;
}
function renderStatus(){
  const el=$("statusReport");
  if(!el) return;
  const schools=schoolsWithDefs();
  const escv=esc;
  const fmt=n=>String(n);
  // Doluluk = EKLENEN (tanımlı) saat / TOPLAM kapasite (yerleşme oranı değil)
  // Renk: %0 yeşil → %100 kırmızı (doluluk arttıkça uyarı rengi)
  const pctBadge=p=>`<span class="def-badge" style="background:hsl(${Math.round(Math.max(0,120-p*1.2))},65%,42%);color:#fff">%${p}</span>`;
  if(statusMode==="school"){
    const v=verifySchedule();
    el.innerHTML='<table class="stat-table"><thead><tr><th>Okul</th><th>Tanım</th><th>Eklenen Saat</th><th>Yerleşen</th><th>Kapasite</th><th>Doluluk</th><th>Sorun</th></tr></thead><tbody>'+
      schools.map(sc=>{
        const added=sc.defs.reduce((s,d)=>s+Math.max(1,Number(d.hours)||1),0);
        const placed=(sc.lessons||[]).length;
        let cap=0; for(const cl of sc.classes||[]) cap+=classOpenSlots(sc,cl);
        const pct=cap?Math.round(added/cap*100):0;
        const issues=v.filter(x=>x.includes(sc.name)).length;
        return `<tr><td><strong>${escv(sc.name)}</strong></td><td>${sc.defs.length}</td><td>${fmt(added)}</td><td>${fmt(placed)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td><td>${issues?`<span class="def-badge err">${issues}</span>`:"<span class=\"def-badge ok\">0</span>"}</td></tr>`;
      }).join("")+'</tbody></table>';
  }else if(statusMode==="teachers"){
    const rows=S.teachers.map(t=>{
      let added=0,placed=0,cap=0;
      const tClasses=[];
      for(const sc of schools){
        const cls=new Set();
        for(const d of sc.defs||[]){ if(defTeachers(d).includes(t)){ added+=Math.max(1,Number(d.hours)||1); for(const c of defClasses(d)) cls.add(c); } }
        for(const l of sc.lessons||[]) if(lessonTeachers(l).includes(t)) placed++;
        if(cls.size) tClasses.push([sc,cls]);
      }
      for(const [sc,cls] of tClasses) cap+=teacherCap(sc,t,cls);
      const pct=cap?Math.round(added/cap*100):0;
      return `<tr><td><strong>${escv(t)}</strong></td><td>${fmt(added)}</td><td>${fmt(placed)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td></tr>`;
    }).join("");
    el.innerHTML='<table class="stat-table"><thead><tr><th>Öğretmen</th><th>Eklenen Saat</th><th>Yerleşen</th><th>Kapasite</th><th>Doluluk</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }else if(statusMode==="class"){
    const rows=[];
    for(const sc of schools){
      for(const cl of sc.classes||[]){
        let added=0,placed=0;
        for(const d of sc.defs||[]) if(defClasses(d).includes(cl)) added+=Math.max(1,Number(d.hours)||1);
        placed=sc.lessons.filter(l=>lessonClasses(l).includes(cl)).length;
        const cap=classOpenSlots(sc,cl);
        const pct=cap?Math.round(added/cap*100):0;
        rows.push(`<tr><td><strong>${escv(sc.name)}</strong></td><td><strong>${escv(cl)}</strong></td><td>${fmt(added)}</td><td>${fmt(placed)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td></tr>`);
      }
    }
    el.innerHTML='<table class="stat-table"><thead><tr><th>Okul</th><th>Sınıf</th><th>Eklenen Saat</th><th>Yerleşen</th><th>Kapasite</th><th>Doluluk</th></tr></thead><tbody>'+rows.join("")+'</tbody></table>';
  }else if(statusMode==="room"){
    const rooms=[...(S.rooms||[])];
    if(!rooms.length){ el.innerHTML='<div class="empty">Henüz derslik tanımlanmadı.</div>'; return; }
    const ref=curSchool(); const cap=ref?(ref.days||SCHOOL_DFLT.days).length*(ref.periods||10):50;
    const rows=rooms.map(r=>{
      let added=0; const perSchool={};
      for(const sc of schools){
        const n=sc.lessons.filter(l=>l.room===r).length;
        const defs=sc.defs.filter(d=>d.room===r).length;
        if(n||defs){ perSchool[sc.name]=`${defs} tanım / ${n} yerleşen`; added+=defs; }
      }
      const pct=cap?Math.round(added/cap*100):0;
      const detail=Object.entries(perSchool).map(([k,x])=>`${escv(k)}: ${x}`).join(" • ");
      return `<tr><td><strong>${escv(r)}</strong></td><td>${fmt(added)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td><td>${detail||"—"}</td></tr>`;
    }).join("");
    el.innerHTML='<table class="stat-table"><thead><tr><th>Derslik</th><th>Eklenen (tanım)</th><th>Kapasite</th><th>Doluluk</th><th>Okullar</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }
  makeSortable(el.querySelector(".stat-table"));
}
// Durum tablolarını sütun başlığına tıklayınca sıralanabilir yapar
function makeSortable(table){
  if(!table||!table.querySelector) return;
  const thead=table.querySelector("thead"), tbody=table.querySelector("tbody");
  if(!thead||!tbody) return;
  const ths=[...thead.querySelectorAll("th")];
  ths.forEach((th,i)=>{
    th.style.cursor="pointer";
    th.title="Sıralamak için tıkla";
    th.addEventListener("click",()=>{
      const asc=th.dataset.asc!=="1";
      ths.forEach(x=>{ x.dataset.asc=""; x.textContent=x.textContent.replace(/ [▲▼]$/,""); });
      th.dataset.asc=asc?"1":"0";
      th.textContent+=(asc?" ▲":" ▼");
      const rows=[...tbody.querySelectorAll("tr")];
      const col=th.cellIndex;
      rows.sort((a,b)=>{
        const av=(a.children[col]?a.children[col].textContent:"").trim()||"";
        const bv=(b.children[col]?b.children[col].textContent:"").trim()||"";
        const an=parseFloat(av.replace(/[^0-9.]/g,""))||0;
        const bn=parseFloat(bv.replace(/[^0-9.]/g,""))||0;
        const bothNum=av&&bv&&(isFinite(an)||isFinite(bn));
        const cmp=bothNum?(an-bn):av.localeCompare(bv,"tr");
        return asc?cmp:-cmp;
      });
      rows.forEach(r=>tbody.appendChild(r));
    });
  });
}
document.querySelectorAll(".stat-btn").forEach(btn=>{
  btn.addEventListener("click",()=>{
    statusMode=btn.dataset.stat;
    document.querySelectorAll(".stat-btn").forEach(b=>b.classList.toggle("active",b===btn));
    renderStatus();
  });
});

function renderEntityDefs(mode, name, schoolFilter){
  const container=document.getElementById(mode==="class"?"classDefsList":"teacherDefsList");
  // Okul bazlı sekmede o okul; "Birlikte"/sınıf görünümünde tüm okulların tanımları
  const schools=mode==="class"?[curSchool()]:(schoolFilter?S.schools.filter(s=>s.name===schoolFilter):S.schools.filter(s=>(s.defs||[]).length));
  const placed={};
  for(const sc of schools){ for(const l of sc.lessons||[]){ const k=`${sc.id}|${refKey(l.course,lessonTeachers(l),lessonClasses(l))}`; placed[k]=(placed[k]||0)+1; } }
  const rows=[];
  for(const sc of schools){
    for(const d of sc.defs||[]){
      // Birleşik tanım, listelendiği HER sınıfın listesinde görünmeli.
      const match=mode==="class"?defClasses(d).includes(name):defTeachers(d).includes(name);
      if(!match) continue;
      const ph=placed[`${sc.id}|${refKey(d.course,defTeachers(d),defClasses(d))}`]||0;
      const cls=ph>=d.hours?"ok":ph>0?"warn":"err";
      const badge=ph>=d.hours?"Tam":ph>0?`${ph}/${d.hours}`:"Bekliyor";
      rows.push(`<tr onclick="toggleDefPanel('${d.id}')" title="Ayarları açılır pencerede düzenle">
        ${mode==="teacher"?`<td>${esc(sc.name)}</td>`:""}
        <td>${esc(defClasses(d).join(" + "))}</td><td><strong>${esc(d.course)}</strong></td>
        <td>${esc(defLabel(d))}</td><td>${d.hours}</td>
        <td><span class="def-badge ${cls}">${badge}</span></td>
        <td>${d.room?`<span class="room-chip">${esc(d.room)}</span>`:""}</td>
      </tr>`);
    }
  }
  if(!rows.length){
    container.innerHTML='<div style="font-size:12px;color:var(--text3);padding:8px 0">Bu '+ (mode==="class"?"sınıfa":"öğretmene") +' tanımlı ders yok.</div>';
    return;
  }
  container.innerHTML='<div class="ed-head">Tanımlı Dersler'+(mode==="teacher"?(schoolFilter?` (${schoolFilter})`:" (tüm okullar)"):"")+' <span style="opacity:.6;font-weight:500;text-transform:none">(satıra tıklayın: ayarlar)</span></div>'+
    `<table class="ed-table"><thead><tr>${mode==="teacher"?"<th>Okul</th>":""}<th>Sınıf</th><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th><th>Derslik</th></tr></thead><tbody>${rows.join("")}</tbody></table>`;
}
// Açılır pencere (modal) ile ders ayarlarını göster; tanım başka okuldaysa o okula geç
function toggleDefPanel(id){
  let d=null, sc=null;
  for(const s of S.schools){ const f=(s.defs||[]).find(x=>x.id===id); if(f){ d=f; sc=s; break; } }
  if(!d) return;
  if(sc&&sc.id!==S.currentSchool){ S.currentSchool=sc.id; saveState(); }
  const body=$("defEditModalBody");
  body.innerHTML=`<div class="ed-panel def-modal" id="edp-${id}">${buildDefPanelHTML(id)}</div>`;
  $("defEditModalTitle").textContent=`${d.course} — ${defClasses(d).join(" + ")} (${d.teacher})`;
  $("defEditModal").classList.remove("hidden");
  $("defEditModal").classList.add("open");
}
function closeDefModal(){
  $("defEditModal").classList.remove("open");
  $("defEditModal").classList.add("hidden");
  $("defEditModalBody").innerHTML="";
}
$("defEditModalClose").addEventListener("click",closeDefModal);
$("defEditModal").addEventListener("click",e=>{ if(e.target&&e.target.id==="defEditModal") closeDefModal(); });
document.addEventListener("keydown",e=>{ if(e.key==="Escape"&&!$("defEditModal").classList.contains("hidden")) closeDefModal(); });
function buildDefPanelHTML(id){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return "";
  const sc=curSchool();
  const lessons=sc.lessons.filter(l=>refKey(l.course,lessonTeachers(l),lessonClasses(l))===refKey(d.course,defTeachers(d),defClasses(d)));
  const lessonCells={};
  for(const l of lessons) lessonCells[sk(l.day,l.period)]=l;
  const gridRows=sc.days.map(day=>{
    const cells=[];
    for(let p=1;p<=sc.periods;p++){
      const k=sk(day,p);
      const isLesson=lessonCells[k];
      const isClosed=d.avail&&d.avail[k]===false;
      const cls=isLesson?"av-lesson":isClosed?"av-closed":"av-open";
      const title=isLesson?`Yerleşik (${day} ${p}.s)`:isClosed?`${day} ${p}.s: bu ders için kapalı — tıkla aç`:`${day} ${p}.s: açık — tıkla kapat`;
      cells.push(`<td class="${cls}" title="${title}" data-k="${day}|${p}" onclick="defAvailClick('${id}','${day}',${p})">${isLesson?"X":isClosed?"●":"·"}</td>`);
    }
    return `<tr><td style="font-size:9px;color:var(--text3);font-weight:600;width:16px">${esc(day.slice(0,3))}</td>${cells.join("")}</tr>`;
  }).join("");
  const tOpts=S.teachers.map(t=>`<option value="${esc(t)}" ${t===d.teacher?"selected":""}>${esc(t)}</option>`).join("");
  const extraSel=defTeachers(d).slice(1);
  const tExtraOpts=S.teachers.map(t=>`<option value="${esc(t)}" ${extraSel.includes(t)?"selected":""}>${esc(t)}</option>`).join("");
  const rOpts='<option value="">— (derslik yok)</option>'+(S.rooms||[]).map(r=>`<option value="${esc(r)}" ${r===d.room?"selected":""}>${esc(r)}</option>`).join("");
  const periods=Array.from({length:sc.periods},(_,i)=>`<th>${i+1}</th>`).join("");
  return `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
      <strong style="font-size:12px">Haftalık çizelge</strong>
      <span style="font-size:10px;color:var(--text3)">tıkla: bu ders için açık/kapalı saat</span>
    </div>
    <table class="def-avail-table"><tr><th></th>${periods}</tr>${gridRows}</table>
    <div class="def-fields">
      <label>Ders Adı<input id="df-course-${id}" list="defCourseList" value="${esc(d.course)}" style="width:150px"></label>
      <label>Öğretmen<select id="df-teacher-${id}" style="width:170px">${tOpts}</select></label>
      <label>Ek Öğretmenler<select id="df-extra-${id}" multiple size="6" style="min-width:170px;overflow-y:auto">${tExtraOpts||'<option disabled>Önce öğretmen ekleyin</option>'}</select></label>
      <label>Saat<input id="df-hours-${id}" type="number" min="1" max="40" value="${d.hours}" style="width:56px"></label>
      <label>Blok<select id="df-block-${id}"><option value="1" ${d.block==1?"selected":""}>1</option><option value="2" ${d.block==2?"selected":""}>2</option><option value="3" ${d.block==3?"selected":""}>3</option><option value="4" ${d.block==4?"selected":""}>4</option></select></label>
      <label style="font-size:10px;text-transform:none">Tek blok<input id="df-fixed-${id}" type="checkbox" ${d.blockFixed?"checked":""} style="width:auto;height:auto"></label>
      <label>Derslik<select id="df-room-${id}" style="width:150px">${rOpts}</select></label>
    </div>
    <div class="def-actions">
      <button class="def-save" onclick="saveDefPanel('${id}')">Kaydet</button>
      <button class="def-del" onclick="deleteDefPanel('${id}')">Tanımı Sil</button>
    </div>`;
}
// Bu ders için açık/kapalı saati değiştir (çözücü bu saatleri tanımlı ders için dikkate alır)
function defAvailClick(id,day,p){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return;
  if(!d.avail) d.avail={};
  const k=sk(day,p);
  if(d.avail[k]===false) delete d.avail[k];
  else d.avail[k]=false;
  const cell=document.querySelector(`#edp-${id} td[data-k="${day}|${p}"]`);
  if(cell){
    const isClosed=d.avail[k]===false;
    cell.className=isClosed?"av-closed":"av-open";
    cell.textContent=isClosed?"●":"·";
    cell.title=isClosed?`${day} ${p}.s: bu ders için kapalı — tıkla aç`:`${day} ${p}.s: açık — tıkla kapat`;
  }
  saveState();
}
// Açılır panelden ders tanımını güncelle
function saveDefPanel(id){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return;
  const course=($("df-course-"+id).value||"").trim();
  const teacher=$("df-teacher-"+id).value;
  const extras=extraChecks($("df-extra-"+id));
  const teachers=[teacher,...extras.filter(t=>t&&t!==teacher)];
  const className=defClasses(d); // birleşik tanımda tüm sınıflar (refKey eşleşmesi için)
  const hours=Math.max(1,Number($("df-hours-"+id).value)||1);
  const block=Math.max(1,Number($("df-block-"+id).value)||1);
  const blockFixed=$("df-fixed-"+id).checked;
  const room=$("df-room-"+id).value||null;
  if(!course||!teacher){ toast("Ders adı ve öğretmen gerekli.","err"); return; }
  for(const t of teachers) if(!S.teachers.includes(t)) S.teachers.push(t);
  for(const t of teachers) addTeacherCourse(t,course);
  if(!curSchool().courses.includes(course)) curSchool().courses.push(course);
  // Ders adı/öğretmen değiştiyse bu tanıma ait yerleşmiş dersleri de güncelle (tutarlılık)
  const oldRef=refKey(d.course,defTeachers(d),className);
  for(const l of curSchool().lessons){
    if(refKey(l.course,lessonTeachers(l),lessonClasses(l))===oldRef){ l.course=course; setTeachers(l,teachers); l.room=room; }
  }
  d.course=course; setTeachers(d,teachers); d.hours=hours; d.block=block; d.blockFixed=blockFixed; d.room=room;
  saveState(); renderDefs(); refresh();
  closeDefModal();
  toast(`"${course}" güncellendi. Yeniden dağıtım gerekebilir.`);
}
function deleteDefPanel(id){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return;
  showConfirm("Ders Tanımını Sil",`"${d.course}" (${defClasses(d).join(" + ")}) tanımı ve yerleşmiş dersleri silinsin mi?`,ok=>{
    if(!ok) return;
    curSchool().defs=curSchool().defs.filter(x=>x.id!==id);
curSchool().lessons=curSchool().lessons.filter(l=>refKey(l.course,lessonTeachers(l),lessonClasses(l))!==refKey(d.course,defTeachers(d),defClasses(d)));
    saveState(); refresh();
    closeDefModal();
    toast("Tanım silindi.");
  });
}

/* ============================================================
   DAĞITIM İLERLEME/RAPOR
   ============================================================ */
let lastScheduleOptions={flexibleBlocks:false};
let solveCancelled=false;
let liveBest = null; // çalışma sırasında en iyi (maksimum yerleşim) anlık kopyası
let _isSolving = false;
let teacherViewMode="birlikte";
let roomViewMode="birlikte";
let statusMode="school";

function waitFrame(){ return new Promise(resolve=>setTimeout(resolve,0)); }
// ── Performans Modu ──
let perfMode = 'balanced';
// Uzun sürecek dağıtımlar başlamadan ÖNCE performans modu seçilebilsin diye onay kutusuna
// gömülen seçici. (Tek okullu "Dağıt" bunu ön kontrol ekranında zaten sunuyor; "Tümünü Dağıt"
// ve "Eksikleri Tamamla" ön kontrolü atladığı için ancak çalışırken değiştirilebiliyordu.)
function perfModeChooserHtml(){
  const opts=[["balanced","Dengeli — sık yenileme (önerilen)"],
              ["fast","Hızlı — biraz seyrek yenileme"],
              ["turbo","Turbo — en seyrek yenileme, en çok deneme"]];
  return '<label style="display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600">Performans Modu'
    +'<select id="modalPerfSelect" style="height:30px;border-radius:6px;border:1px solid var(--border);background:var(--bg);color:var(--text);padding:0 8px">'
    +opts.map(function(o){ return '<option value="'+o[0]+'"'+(perfMode===o[0]?' selected':'')+'>'+esc(o[1])+'</option>'; }).join("")
    +'</select></label>'
    +'<div style="font-size:11px;color:var(--text3);margin-top:6px">Turbo: arayüz daha seyrek yenilenir, saniyede daha çok deneme yapılır.</div>';
}
function applyModalPerfMode(){
  const sel=$("modalPerfSelect");
  if(sel && sel.value){
    perfMode=sel.value;
    try{ localStorage.setItem("planlaPerfMode", perfMode); }catch(e){}
    const main=$("perfModeSelect"); if(main) main.value=perfMode;
  }
}
function perfInterval(){ return perfMode==='turbo'?100 : perfMode==='fast'?50 : 25; }
// İlerleme METNİNİN yenilenme aralığı (ms). Deneme SAYISINA bağlamak yanlıştı: büyük
// okullarda bir deneme ~1,5 sn sürüyor, Turbo'da 100 denemede bir yazınca ekran
// ~2,5 dakika boyunca donmuş görünüyordu. Zamana bağlayınca her modda canlı kalıyor.
function perfTextMs(){ return perfMode==='turbo'?2000 : perfMode==='fast'?800 : 250; }
function perfLargeInterval(){ return perfMode==='turbo'?1000 : perfMode==='fast'?600 : 500; }
document.addEventListener('DOMContentLoaded',()=>{
  const sel=$('perfModeSelect');
  if(sel){
    try{ const saved=localStorage.getItem('planlaPerfMode'); if(saved) { perfMode=saved; sel.value=saved; } }catch{}
    sel.addEventListener('change',()=>{
      perfMode=sel.value;
      try{ localStorage.setItem('planlaPerfMode', perfMode); }catch{}
      toast(perfMode==='balanced'?'Dengeli mod: UI akıcı, deneme hızı normal':perfMode==='fast'?'Hızlı mod: 3-5× deneme hızı':'Turbo mod: maksimum deneme, UI seyrek güncellenir');
    });
  }
});

function validateScheduleData(school){
  const errors=[],warnings=[];
  const classSet=new Set(school.classes||[]);
  const courseSet=new Set(school.courses||[]);
  const teacherSet=new Set(S.teachers||[]);
  const seen={};

  (school.defs||[]).forEach((d,i)=>{
    const row=i+1;
    if(!d.course||!String(d.course).trim()) errors.push({title:`${row}. ders: ders adı boş`,body:"Ders tanımında ders adı eksik."});
if(!d.teacher||!String(defLabel(d)).trim()) errors.push({title:`${row}. ders: öğretmen boş`,body:`${d.course||"Ders"} için öğretmen seçilmemiş.`});
    if(!d.className||!String(d.className).trim()) errors.push({title:`${row}. ders: sınıf boş`,body:`${d.course||"Ders"} için sınıf seçilmemiş.`});
    for(const t of defTeachers(d)) if(!teacherSet.has(t)) errors.push({title:`${t}: öğretmen listede yok`,body:`${d.course} / ${d.className} tanımı, öğretmenler listesinde bulunmayan bir öğretmene bağlı.`});
    if(d.className&&!classSet.has(d.className)) errors.push({title:`${d.className}: sınıf listede yok`,body:`${d.course} / ${d.teacher} tanımı, sınıflar listesinde bulunmayan bir sınıfa bağlı.`});
    if(d.course&&courseSet.size&&!courseSet.has(d.course)) warnings.push({title:`${d.course}: ders listede yok`,body:`Bu ders tanımı var ama ders adları listesinde görünmüyor.`});

    const hours=Number(d.hours), block=Number(d.block);
    if(!Number.isFinite(hours)||hours<=0) errors.push({title:`${d.course||row}: saat hatası`,body:"Ders saati 1 veya daha büyük olmalı."});
    if(!Number.isFinite(block)||block<=0) errors.push({title:`${d.course||row}: blok hatası`,body:"Blok değeri 1 veya daha büyük olmalı."});
    if(Number.isFinite(hours)&&Number.isFinite(block)&&block>hours) warnings.push({title:`${d.course}: blok saatten büyük`,body:`${hours} saatlik ders için ${block}'lik blok tanımlı; dağıtım bunu ${hours} saat olarak sınırlar.`});

for(const t of defTeachers(d)){
      if(d.course&&S.teacherCourses&&S.teacherCourses[t]&&S.teacherCourses[t].length&&!S.teacherCourses[t].includes(d.course)){
        warnings.push({title:`${t}: ders eşleşmesi yok`,body:`${t} için ${d.course} dersi öğretmen-ders eşleşmelerinde tanımlı değil.`});
      }
    }

const key=refKey(d.course,defTeachers(d),defClasses(d));
    seen[key]=(seen[key]||0)+1;
  });

  for(const [key,count] of Object.entries(seen)){
    if(count>1){
      const [course,teachers,className]=key.split("|");
      warnings.push({title:`Tekrarlı tanım: ${className} ${course}`,body:`${teachers} için aynı sınıf/ders ${count} kez tanımlanmış. Toplam saatler ayrı ayrı dağıtılır.`});
    }
  }
  return {errors,warnings};
}

// Dağıtım öncesi kapasite/yerleştirilebilirlik kontrolü (sıfır ders yerleştirmeden çalışır).
// Dönen issues: bu koşullarda FİZİKSEL olarak yerleştirilemeyecek dersler (kırmızı, dağıtımı engeller).
function precheckSchedule(school){
  const validation=validateScheduleData(school);
  const days=school.days||SCHOOL_DFLT.days;
  const periods=school.periods||10;
  const sk=(d,p)=>`${d}|${p}`;
  const schoolOpen=(d,p)=>!school.schoolClosed[sk(d,p)];
  const classOpen=(cl,d,p)=>schoolOpen(d,p)&&!((school.classClosed[cl]||{})[sk(d,p)]);
  const teacherOpen=(t,d,p)=>{
    if(!schoolOpen(d,p)) return false;
    if(S.teacherClosed[t]&&S.teacherClosed[t][school.id]&&S.teacherClosed[t][school.id][sk(d,p)]) return false;
    // Diğer okullarda duvar saati olarak çakışan ders var mı
    const ptC=school.periodTimes&&school.periodTimes[p-1];
    if(!ptC) return true;
    const cS=toMin(ptC.start), cE=toMin(ptC.end);
    for(const other of S.schools){
      if(other.id===school.id) continue;
      for(const l of other.lessons||[]){
        if(l.day!==d||!lessonTeachers(l).includes(t)) continue;
        const pt=other.periodTimes&&other.periodTimes[l.period-1];
        if(!pt) continue;
        const oS=toMin(pt.start), oE=toMin(pt.end);
        if(cS<oE&&oS<cE) return false;
      }
    }
    return true;
  };
  const defs=school.defs||[];
  const issues=[];
  if(!defs.length){
    issues.push({type:"Veri",name:"Ders yok",need:0,open:0,extra:0,reason:"Henüz hiç ders tanımlanmamış. Dersler sekmesinden ders ekleyin."});
    return {validation,issues,blocking:true};
  }
  const classNeed={},teacherNeed={},teacherClasses={},pairHours={};
  for(const def of defs){
    const h=Math.max(1,Number(def.hours)||1);
    classNeed[def.className]=(classNeed[def.className]||0)+h;
    for(const t of defTeachers(def)){
      teacherNeed[t]=(teacherNeed[t]||0)+h;
      (teacherClasses[t]=teacherClasses[t]||new Set()).add(def.className);
      const pk=`${t}|${def.className}`;
      pairHours[pk]=(pairHours[pk]||0)+h;
    }
  }
  for(const [name,need] of Object.entries(classNeed)){
    let open=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(classOpen(name,day,p)) open++;
    if(need>open) issues.push({type:"Sınıf",name,need,open,extra:need-open,
      reason:`${name} sınıfının haftalık açık saati ${open}, tanımlı ders saati ${need}. ${need-open} saat bu kapalı saatlerle yerleştirilemez.`});
  }
  for(const [name,need] of Object.entries(teacherNeed)){
    let cap=0;
    for(const day of days){
      let tOpen=0,anyOpen=0;
      for(let p=1;p<=periods;p++){
        if(!teacherOpen(name,day,p)) continue;
        tOpen++;
        for(const cl of teacherClasses[name]){ if(classOpen(cl,day,p)){ anyOpen++; break; } }
      }
      cap+=Math.min(tOpen,anyOpen);
    }
    if(need>cap) issues.push({type:"Öğretmen",name,need,open:cap,extra:need-cap,
      reason:`${name} öğretmeni, kapalı saatler nedeniyle haftada en fazla ${cap} saat ders verebilir; tanımlı ders saati ${need}. ${need-cap} saat yerleştirilemez.`});
  }
  for(const [pk,h] of Object.entries(pairHours)){
    const [t,cl]=pk.split("|");
    let overlap=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(teacherOpen(t,day,p)&&classOpen(cl,day,p)) overlap++;
    if(overlap<h) issues.push({type:"Eşleşme",name:`${t} ↔ ${cl}`,need:h,open:overlap,extra:h-overlap,
      reason:`${t} ile ${cl} arasında ortak açık saat ${overlap}, tanımlı ders ${h} saat. ${h-overlap} saat yerleştirilemez.`});
  }
  // Tek blok (blockFixed) dersler: en az bir gün o kadar ardışık açık saat var mı?
  for(const def of defs){
    if(!def.blockFixed) continue;
    const h=Math.max(1,Number(def.hours)||1);
    let ok=false;
    for(const day of days){
      for(let start=1;start<=periods-h+1;start++){
        let good=true;
        for(let o=0;o<h;o++){ if(!classOpen(def.className,day,start+o)){ good=false; break; } for(const t of defTeachers(def)) if(!teacherOpen(t,day,start+o)){ good=false; break; } }
        if(good){ ok=true; break; }
      }
      if(ok) break;
    }
    if(!ok) issues.push({type:"Blok",name:`${def.className} ${def.course}`,need:h,open:0,extra:h,
      reason:`${def.className} ${def.course} dersi tek blok olarak yerleştirilemiyor (${h} ardışık açık saat bulunmuyor). Bu ders için "Tek blok" işaretini kaldırın veya saatini azaltın.`});
  }
  // Derse özel kapatılan saatler: hiç uygun açık saat kalmadı mı?
  for(const def of defs){
    if(!def.avail) continue;
    const size=def.blockFixed?Math.max(1,Number(def.hours)||1):1;
    let ok=false;
    for(const day of days) for(let start=1;start<=periods-size+1;start++){
      let good=true;
      for(let o=0;o<size;o++){ const p=start+o; if(!classOpen(def.className,day,p)||(def.avail[sk(day,p)]===false)){ good=false; break; } for(const t of defTeachers(def)) if(!teacherOpen(t,day,p)){ good=false; break; } }
      if(good){ ok=true; break; }
    }
    if(!ok) issues.push({type:"Ders",name:`${def.className} ${def.course}`,need:size,open:0,extra:size,
      reason:`${def.className} ${def.course} dersi için bu derse özel kapatılan saatler yüzünden uygun açık saat kalmadı. Açılır panelden kapatılan saatleri açın.`});
  }
  return {validation,issues,blocking:validation.errors.length>0||issues.length>0};
}

// ─── ÇAPRAZ-OKUL ÖĞRETMEN KAPASİTESİ ───
// precheckSchedule öğretmen kapasitesini yalnızca tek okul içinde hesaplar; oysa gerçek
// tavan iki okulun birlikte dayattığı sınırdır: okulların ders saatleri duvar saatinde
// iç içe geçebilir, teneffüs ve öğle arası kuralları öğretmenin tüm gününü etkiler.
// Bu fonksiyon dağıtım başlamadan hesaplanabilir hakiki tavanı bulur ve talebi aşan
// öğretmenler için uyarı üretir (engelleyici değildir, turuncu uyarı olarak gösterilir).
function crossSchoolTeacherIssues(){
  const activeSchools=S.schools.filter(s=>(s.defs||[]).length);
  if(!activeSchools.length) return [];
  // 1) Talep: her öğretmenin tüm okullardaki defs içindeki saat toplamı (ortak yardımcı)
  const {load:need,bySchool:teaSchools}=teacherLoadMap(activeSchools);
  const minBreakBySc={}, lunchReqBySc={};
  for(const sc of activeSchools){
    const C=normConstraints(sc.constraints);
    minBreakBySc[sc.id]=Math.max(0,Math.floor(Number(C.minBreak)||0));
    lunchReqBySc[sc.id]=!!C.requireLunch;
  }
  const allDays=[...new Set(activeSchools.flatMap(s=>s.days))];
  // 2) Bir gün için zamanı çakışmayan en büyük slot alt kümesi (dinamik programlama).
  //    Teneffüs şartı yalnızca FARKLI okullar arası geçişlerde aranır (breaksBreak ile aynı).
  function maxSlotsDay(slots){
    const n=slots.length; if(!n) return 0;
    const dp=new Array(n).fill(1);
    let best=1;
    for(let j=1;j<n;j++){
      for(let i=0;i<j;i++){
        if(slots[i].end>slots[j].start) continue; // zaman çakışması
        if(slots[i].schoolId!==slots[j].schoolId){
          const mb=Math.max(minBreakBySc[slots[i].schoolId]||0,minBreakBySc[slots[j].schoolId]||0);
          if(mb>0 && slots[j].start-slots[i].end<mb) continue; // okullar arası geçişte teneffüs yetersiz
        }
        if(dp[i]+1>dp[j]) dp[j]=dp[i]+1;
      }
      if(dp[j]>best) best=dp[j];
    }
    return best;
  }
  const issues=[];
  for(const t of Object.keys(need)){
    let cap=0;
    for(const day of allDays){
      // Aday slotlar: öğretmenin dersi olan okulların her saati; okul veya öğretmen kapalıysa atla
      const slots=[];
      for(const sc of activeSchools){
        if(!(teaSchools[t]&&teaSchools[t].has(sc.id))) continue;
        for(let p=1;p<=sc.periods;p++){
          if(!schoolOpenIn(sc,day,p)) continue;
          if(S.teacherClosed[t]&&S.teacherClosed[t][sc.id]&&S.teacherClosed[t][sc.id][sk(day,p)]) continue;
          const pt=sc.periodTimes&&sc.periodTimes[p-1]; if(!pt) continue;
          slots.push({start:toMin(pt.start),end:toMin(pt.end),schoolId:sc.id});
        }
      }
      if(!slots.length) continue;
      slots.sort((a,b)=>a.start-b.start||a.end-b.end);
      // Öğle şartı: her öğle penceresi adayı sırayla "yasak" kabul edilip hesap tekrarlanır
      const win=lunchWindowsForDay(day);
      const reqLunch=win.length>0 && [...(teaSchools[t]||[])].some(id=>lunchReqBySc[id]);
      let dayCap;
      if(reqLunch){
        dayCap=0;
        for(const lw of win) dayCap=Math.max(dayCap,maxSlotsDay(slots.filter(s=>!(s.start<lw.end&&lw.start<s.end))));
      }else{
        dayCap=maxSlotsDay(slots);
      }
      cap+=dayCap; // haftalık tavan = günlerin toplamı
    }
    // 3) Talep > tavan olan her öğretmen için uyarı
    if(need[t]>cap){
      issues.push({teacher:t,need:need[t],cap,reason:
        `${t} için tüm okullarda tanımlı ${need[t]} saat, ancak ${activeSchools.length} okulun ders saatleri, teneffüs ve öğle arası kuralları birlikte haftada en fazla ${cap} saate izin veriyor. ${need[t]-cap} saat yerleşemez.`});
    }
  }
  return issues;
}

function showPrecheck(){
  const school=curSchool();
  const pre=precheckSchedule(school);
  const crossIssues=crossSchoolTeacherIssues();
  showScheduleOverlay();
  $("scheduleTitle").textContent="Ön Kontrol";
  $("scheduleProgress").style.display="none";
  $("scheduleProgressBar").style.width="100%";
  $("scheduleReport").innerHTML="";
  $("scheduleSaveBtn").style.display="none";
  $("scheduleCloseBtn").textContent="Kapat";
  const pr2=$('perfModeRow'); if(pr2){ pr2.style.display='flex'; pr2.querySelector('select').disabled=!!pre.blocking; }
  const startBtn=$("scheduleStartBtn");
  startBtn.style.display="";
  startBtn.disabled=pre.blocking;
  startBtn.title=pre.blocking?"Önce kapasite sorunlarını giderin":"Dağıtımı başlat";

  const defCount=(school.defs||[]).length;
  const parts=[`<div class="schedule-summary">
    <div class="schedule-stat"><strong>${defCount}</strong><span>Ders tanımı</span></div>
    <div class="schedule-stat"><strong>${school.classes.length}</strong><span>Sınıf</span></div>
    <div class="schedule-stat"><strong>${school.days.length}</strong><span>Gün</span></div>
    <div class="schedule-stat"><strong>${school.periods}</strong><span>Saat</span></div>
  </div>`];

  if(pre.validation.errors.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">Düzeltilmesi gereken veri hataları</div>
      <ul class="schedule-list">${pre.validation.errors.map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul></div>`);
  }
  if(pre.issues.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">Yerleştirilemeyecek dersler (${pre.issues.length})</div>
      <ul class="schedule-list">${pre.issues.map(x=>`<li><strong>${esc(x.type)}:</strong> ${esc(x.reason)}</li>`).join("")}</ul></div>`);
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-body">Bu sorunlar giderilmeden dağıtım yapılamaz. Kapalı saatleri açın veya ders/öğretmen saatlerini azaltın, sonra yeniden Dağıt'a basın.</div></div>`);
  }
  // Çapraz-okul öğretmen kapasitesi: engelleyici değil, turuncu uyarı — kullanıcı yine de deneyebilir
  if(crossIssues.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Okullar arası öğretmen kapasitesi</div>
      <ul class="schedule-list">${crossIssues.map(x=>`<li>${esc(x.reason)}</li>`).join("")}</ul>
      <div class="schedule-alert-body">Bu uyarı dağıtımı engellemez. Yerleşmeyen saat çıkarsa ilgili öğretmenin toplam saatini azaltın veya okul/öğretmen kapalı saatlerini gevşetin.</div></div>`);
  }
  if(pre.validation.warnings.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Veri uyarıları</div>
      <ul class="schedule-list">${pre.validation.warnings.slice(0,12).map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul>
      ${pre.validation.warnings.length>12?`<div class="schedule-alert-body">+${pre.validation.warnings.length-12} uyarı daha var.</div>`:""}</div>`);
  }
  if(!pre.blocking&&!crossIssues.length){
    parts.push(`<div class="schedule-alert ok"><div class="schedule-alert-title">Ön kontrol geçti</div>
      <div class="schedule-alert-body">Tüm dersler kapasite sınırları içinde görünüyor. Dağıtımı başlatabilirsiniz.</div></div>`);
  }
  $("scheduleReport").innerHTML=parts.join("");

  const qf=$("scheduleQf");
  if(pre.issues.length && (school.defs||[]).length){
    qf.classList.remove("hidden");
    renderQfList(pre.issues);
  }else{
    qf.classList.add("hidden");
    $("scheduleQfList").innerHTML="";
  }
}

// Ön kontrol penceresinde düzeltilebilir dersler: soruna karışan dersleri listele
function qfAffectedDefs(issues){
  const out=[],seen=new Set();
  for(const def of curSchool().defs||[]){
    let hit=false;
    for(const is of issues){
      if(is.type==="Öğretmen"&&defTeachers(def).includes(is.name)) hit=true;
      else if(is.type==="Sınıf"&&def.className===is.name) hit=true;
      else if(is.type==="Eşleşme"&&defTeachers(def).some(t=>`${t}|${def.className}`===is.name)) hit=true;
      if(hit) break;
    }
    if(hit&&!seen.has(def.id)){ seen.add(def.id); out.push(def); }
  }
  return out;
}

function renderQfList(issues){
  const defs=qfAffectedDefs(issues);
  const list=$("scheduleQfList");
  if(!defs.length){
    list.innerHTML='<div class="empty" style="padding:8px;font-size:12px">İlgili ders bulunamadı.</div>';
    return;
  }
  list.innerHTML=defs.map(d=>{
    const teacherOpts=[...S.teachers].sort(trSort).map(t=>
      `<option value="${esc(t)}"${t===d.teacher?" selected":""}>${esc(t)}</option>`).join("");
    return `<div class="qf-row">
      <span class="qf-label" title="${esc(d.course)} — ${esc(d.className)}">${esc(d.course)} &mdash; ${esc(d.className)} (${d.hours}s)</span>
      <select class="qf-teacher" data-id="${d.id}">${teacherOpts}</select>
      <input type="number" class="qf-hours" data-id="${d.id}" min="1" max="12" value="${d.hours}" title="Saat">
      <button class="qf-del btn sm danger" data-id="${d.id}" title="Bu dersi sil">&times;</button>
    </div>`;
  }).join("");
}

function showScheduleOverlay(){
  $("scheduleOverlay").classList.remove("hidden");
  $("scheduleOverlay").classList.add("open");
}

function hideScheduleOverlay(){
  $("scheduleOverlay").classList.remove("open");
  $("scheduleOverlay").classList.add("hidden");
}

/* ─── KISITLAR GÖRÜNÜMÜ ─── */
function renderConstraints(){
  const c=curSchool().constraints=normConstraints(curSchool().constraints);
  $("spreadCourseChk").checked=!!c.spreadCourse;
  $("spreadTeacherChk").checked=!!c.spreadTeacher;
  $("courseGapChk").value=c.courseGap||0;
  $("minBreakChk").value=c.minBreak||0;
  $("maxSameRunChk").value=c.maxSameRun||0;
  $("requireLunchChk").checked=!!c.requireLunch;
  const cList=[...curSchool().courses].sort(trSort);
  const optsA=cList.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join("");
  // İkinci liste varsayılan olarak ikinci dersi seçsin (liste 2'den kısaysa aynı kalır)
  const optsB=cList.map((x,i)=>`<option value="${esc(x)}"${i===1?" selected":""}>${esc(x)}</option>`).join("");
  $("pairA").innerHTML=optsA; $("pairB").innerHTML=optsB;
  syncPairAddBtn();
  const list=$("pairList");
  if(!c.coursePairs||!c.coursePairs.length){
    list.innerHTML='<span style="font-size:12px;color:var(--text3)">Henüz çift eklenmedi</span>';
  }else{
    list.innerHTML=c.coursePairs.map((p,i)=>
      `<span class="assign-item">${esc(p.a)} <em style="font-style:normal;opacity:.6">↔</em> ${esc(p.b)}
        <button class="del" data-pair="${i}">&times;</button></span>`).join("");
    list.querySelectorAll(".del").forEach(btn=>{
      btn.addEventListener("click",()=>{
        c.coursePairs.splice(Number(btn.dataset.pair),1);
        saveState();renderConstraints();
      });
    });
  }
}
$("spreadCourseChk").addEventListener("change",e=>{curSchool().constraints.spreadCourse=e.target.checked;saveState();});
$("spreadTeacherChk").addEventListener("change",e=>{curSchool().constraints.spreadTeacher=e.target.checked;saveState();});
$("maxSameRunChk").addEventListener("change",e=>{
  curSchool().constraints.maxSameRun=Math.max(0,Math.floor(Number(e.target.value)||0));
  $("maxSameRunChk").value=curSchool().constraints.maxSameRun;
  saveState();
});
$("courseGapChk").addEventListener("change",e=>{
  curSchool().constraints.courseGap=Math.max(0,Math.floor(Number(e.target.value)||0));
  $("courseGapChk").value=curSchool().constraints.courseGap;
  saveState();
  toast(curSchool().constraints.courseGap>0?`Aynı dersin blokları arası en az ${curSchool().constraints.courseGap} saat fark olacak.`:"Aynı ders saat farkı kuralı kapalı.");
});
$("minBreakChk").addEventListener("change",e=>{
  curSchool().constraints.minBreak=Math.max(0,Math.floor(Number(e.target.value)||0));
  $("minBreakChk").value=curSchool().constraints.minBreak;
  saveState();
  toast(curSchool().constraints.minBreak>0?`Dersler arası en az ${curSchool().constraints.minBreak} dk teneffüs şartı açık.`:"Teneffüs şartı kapalı.");
});
$("requireLunchChk").addEventListener("change",e=>{
  curSchool().constraints.requireLunch=e.target.checked;
  saveState();
  toast(e.target.checked?"Her öğretmenin günlük öğle arası şartı açık.":"Öğle arası şartı kapalı.");
});
// İki kutuda aynı ders seçiliyken "Ekle" kapatılır; aynı ders seçilirse toast ile açıklanır
function syncPairAddBtn(){
  const btn=$("addPairBtn");
  if(!btn) return;
  const a=$("pairA").value, b=$("pairB").value;
  btn.disabled=!a||!b||a===b;
}
$("pairA").addEventListener("change",syncPairAddBtn);
$("pairB").addEventListener("change",syncPairAddBtn);
$("addPairBtn").addEventListener("click",()=>{
  const a=$("pairA").value, b=$("pairB").value;
  if(!a||!b){toast("İki ders seçin.","err");return;}
  if(a===b){toast("Aynı dersi kendisiyle eşleştiremezsiniz.","err");return;}
  const c=curSchool().constraints;
  if(!c.coursePairs) c.coursePairs=[];
  if(c.coursePairs.some(p=>(p.a===a&&p.b===b)||(p.a===b&&p.b===a))){toast("Bu çift zaten ekli.","err");return;}
  c.coursePairs.push({a,b});
  saveState();renderConstraints();
  toast(`"${a}" ile "${b}" aynı gün olmayacak.`);
});


function liveBestHTML(){
  if(!liveBest) return "";
  const placed = liveBest.placedHours ?? liveBest.placedBlocks ?? 0;
  const total = liveBest.totalHours ?? liveBest.totalBlocks ?? 0;
  const failedBlocks = (liveBest.failed||[]).length;
  const forced = (liveBest.forcedFailed||[]).length;
  const allFailed = (liveBest.allFailed||[]).length || failedBlocks+forced;
  const unplacedHours = liveBest.totalHours!=null ? Math.max(0, liveBest.totalHours - placed) : "-";
  const unplacedBlocks = failedBlocks;
  const unplacedLessons = allFailed; // blok bazında yerleşmeyen ders sayısı
  // Maksimum yerleşimde yerleşmeyen ders sayısını vurgula
  return `<div class="schedule-alert ok" style="margin-top:10px"><div class="schedule-alert-title">🔹 Anlık Maksimum Yerleşim</div><div class="schedule-alert-body">Yerleşen: <strong>${placed}/${total} saat</strong> • Yerleşmeyen: <strong>${unplacedHours} saat</strong> • Yerleşmeyen ders (blok): <strong>${unplacedBlocks}</strong> • Toplam yerleşmeyen blok (imkansız dahil): <strong>${unplacedLessons}</strong><br><span style="opacity:.75">En iyi kombinasyon bulundu; "Maksimum Yerleşimi Kaydet" ile bu hali çalışırken kaydedebilirsin — çalışma tamamı yerleşene kadar devam eder.</span></div></div>`;
}
function showScheduleProgress(text,percent){
  showScheduleOverlay();
  $("scheduleTitle").textContent="Dağıtım yapılıyor";
  $("scheduleProgress").style.display="";
  // Ana metin + anlık en iyi bilgisi aynı paragrafta gösterilirse kullanıcı her güncellemede görür
  let extra = "";
  if(liveBest){
    const ph = liveBest.allFailed? liveBest.allFailed.length : (liveBest.failed||[]).length;
    extra = ` | Maksimum yerleşim: ${liveBest.placedHours??liveBest.placedBlocks??"?"} yerleşti, ${ph} blok yerleşmedi`;
  }
  $("scheduleProgressText").textContent=text + extra;
  $("scheduleProgressBar").style.width=Math.max(0,Math.min(100,percent||0))+"%";
  // Çalışma sırasında maksimum yerleşimin detayını rapor alanında sürekli göster
  $("scheduleReport").innerHTML = liveBest ? liveBestHTML() : "";
  // Maksimum yerleşimi kaydet butonu çalışma devam ederken görünsün ve o anki en iyi kombinasyonu kaydetsin
  if(liveBest && _isSolving){
    $("scheduleSaveBtn").style.display="";
    $("scheduleSaveBtn").textContent="Maksimum Yerleşimi Kaydet (devam eder)";
    $("scheduleSaveBtn").title="Çalışma devam ederken anlık en iyi kombinasyonu kaydet";
  } else {
    $("scheduleSaveBtn").style.display="none";
  }
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");
  $("scheduleCloseBtn").textContent=_isSolving?"Bitir ve en iyiyi kaydet":"Kapat";
  $("scheduleCloseBtn").title=_isSolving?"Çalışmayı durdur ve en iyi yerleşimi kaydet":"Kapat";
  // Performans modu çalışma sırasında da görünür ve değiştirilebilir (perfMode anında okunur)
  const pr=$('perfModeRow'); if(pr) pr.style.display='flex';
}

/* Bir tanımın NEDEN yerleşmediğini mevcut çizelge üzerinden çıkarır.
   "Yerleşmedi" demek kullanıcıya bir şey söylemiyor; neyi gevşeteceğini bilmesi gerekiyor.
   Ölçümde görülen tipik durum: dersin gidebileceği saatlerden birkaçı sınıf/öğretmen/derslik
   olarak tamamen boş, ama oraya konunca öğretmenin o günkü tek boş öğle penceresi kapanıyor. */
function yerlesmemeNedeni(f){
  const aktif=S.schools.filter(s=>(s.defs||[]).length);
  const sc=aktif.find(s=>s.id===f.schoolId)||aktif[0];
  if(!sc) return "";
  const def=(sc.defs||[]).find(d=>d.id===(f.id||f.defId))||f;
  const ts=defTeachers(def), cls=defClasses(def), oda=def.room||null;
  let aday=0, bos=0;
  const say={sinifKapali:0,ogretmenKapali:0,derseOzel:0,sinifDolu:0,ogretmenDolu:0,derslikDolu:0};
  for(const day of sc.days) for(let p=1;p<=sc.periods;p++){
    const pt=sc.periodTimes&&sc.periodTimes[p-1]; if(!pt) continue;
    if(!schoolOpenIn(sc,day,p)) continue;
    aday++;
    let engel=0;
    if(cls.some(c=>!classOpenIn(sc,c,day,p))){ say.sinifKapali++; engel++; }
    if(ts.some(t=>S.teacherClosed[t]&&S.teacherClosed[t][sc.id]&&S.teacherClosed[t][sc.id][sk(day,p)])){ say.ogretmenKapali++; engel++; }
    if((def.avail||{})[sk(day,p)]===false){ say.derseOzel++; engel++; }
    const t0=toMin(pt.start), t1=toMin(pt.end);
    let sd=false,od=false,dd=false;
    for(const s2 of aktif) for(const l of s2.lessons||[]){
      if(l.day!==day) continue;
      const q=s2.periodTimes&&s2.periodTimes[l.period-1]; if(!q) continue;
      if(!(toMin(q.start)<t1 && t0<toMin(q.end))) continue;
      if(s2.id===sc.id && lessonClasses(l).some(c=>cls.includes(c))) sd=true;
      if(lessonTeachers(l).some(t=>ts.includes(t))) od=true;
      if(oda && l.room===oda) dd=true;
    }
    if(sd){ say.sinifDolu++; engel++; }
    if(od){ say.ogretmenDolu++; engel++; }
    if(dd){ say.derslikDolu++; engel++; }
    if(!engel) bos++;
  }
  // Öğretmenin haftalık yükü (tüm okullar) — asıl darboğaz çoğu zaman burası
  let yuk=0;
  for(const s2 of aktif) for(const d of s2.defs||[]) if(defTeachers(d).some(t=>ts.includes(t))) yuk+=Math.max(1,Number(d.hours)||1);
  const yukMetni=ts.length?` ${ts.join(" / ")} haftada <strong>${yuk} saat</strong> ders veriyor.`:"";
  if(bos>0){
    const C=normConstraints(sc.constraints);
    const kural=[];
    if(C.requireLunch) kural.push("öğle arası");
    if(Number(C.courseGap)>0) kural.push(`aynı dersin gün içi ${C.courseGap} saat arası`);
    if(Number(C.minBreak)>0) kural.push(`okullar arası ${C.minBreak} dk teneffüs`);
    if(C.spreadCourse) kural.push("aynı ders aynı güne gelmesin");
    return `${bos} saat sınıf/öğretmen/derslik olarak <strong>tamamen boş</strong>, ama oraya konursa `+
      `${kural.length?kural.join(" veya "):"bir kısıt"} kuralı bozuluyor.${yukMetni} `+
      `Kısıtlar sekmesinden bu kuralı gevşetmek ya da bu öğretmenin başka bir dersini elle taşımak sonucu açar.`;
  }
  const sirali=Object.entries(say).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]);
  const ad={sinifKapali:"sınıf kapalı",ogretmenKapali:"öğretmen kapalı",derseOzel:"derse özel kapalı",
            sinifDolu:"sınıf dolu",ogretmenDolu:"öğretmen dolu",derslikDolu:"derslik dolu"};
  const ilk=sirali.slice(0,3).map(([k,v])=>`${ad[k]}: ${v} saat`).join(", ");
  return `Uygun ${aday} saatin tamamı kapalı ya da dolu (${ilk}).${yukMetni} `+
    (say.derslikDolu>=aday*0.5&&oda?`<strong>${esc(oda)}</strong> dersliği bu ders için asıl darboğaz.`:
     say.ogretmenDolu>=aday*0.5?"Öğretmenin programı dolu; kapalı saatlerini açmak veya dersi başka öğretmene vermek gerekir.":
     "Sınıfın programı dolu; okul saatlerini artırmak gerekebilir.");
}
function groupBlocks(blocks){
  const map={};
for(const b of blocks){
    const tLabel=tLabelArr(b.teachers||[b.teacher]);
    const key=`${b.className}|${b.course}|${tLabel}|${b.reason||""}`;
    if(!map[key]) map[key]={className:b.className,course:b.course,teacher:tLabel,hours:0,count:0,reason:b.reason||""};
    map[key].hours+=b.size||1;
    map[key].count++;
  }
  return Object.values(map).sort((a,b)=>trSort(a.className,b.className)||trSort(a.course,b.course)||trSort(a.teacher,b.teacher));
}

function showScheduleResult(result){
  showScheduleOverlay();
  const failed=result.allFailed||[...(result.forcedFailed||[]),...(result.failed||[])];
  const impossible=result.capacityIssues||[];
  const validationErrors=result.validationErrors||[];
  const validationWarnings=result.validationWarnings||[];
  const softFailed=(result.failed||[]).filter(b=>!(result.forcedFailed||[]).some(f=>f.bid===b.bid));
  const placedHours=result.placedHours||0;
  const totalHours=result.totalHours||0;

  $("scheduleTitle").textContent=validationErrors.length?"Dağıtım başlamadı":failed.length?"Dağıtım raporu":"Dağıtım tamamlandı";
  $("scheduleProgress").style.display="none";
  $("scheduleProgressBar").style.width="100%";

  const summary=`<div class="schedule-summary">
    <div class="schedule-stat"><strong>${placedHours}</strong><span>Yerleşen saat</span></div>
    <div class="schedule-stat"><strong>${Math.max(0,totalHours-placedHours)}</strong><span>Eksik saat</span></div>
    <div class="schedule-stat"><strong>${result.placedBlocks||0}</strong><span>Yerleşen blok</span></div>
    <div class="schedule-stat"><strong>${failed.length+validationErrors.length+validationWarnings.length}</strong><span>Uyarı</span></div>
  </div>`;

  const parts=[summary];
  if(result.completed){
    parts.push(`<div class="schedule-alert ok"><div class="schedule-alert-title">Eksikleri Tamamla sonucu</div><div class="schedule-alert-body">Yeni yerleşen: <strong>+${result.completed.eklenenSaat} saat</strong> • Yer değiştiren mevcut ders: <strong>${result.completed.oynatilanDers}</strong></div></div>`);
  }
  if(result.chained){
    parts.push(`<div class="schedule-alert ok"><div class="schedule-alert-title">Otomatik onarım</div><div class="schedule-alert-body">Sıfırdan dağıtımdan sonra otomatik onarım turu uygulandı.</div></div>`);
  }
  if(validationErrors.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">Dağıtımdan önce düzeltilmesi gereken hatalar</div>
      <ul class="schedule-list">${validationErrors.map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul></div>`);
  }
  if(validationWarnings.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Veri uyarıları</div>
      <ul class="schedule-list">${validationWarnings.slice(0,12).map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul>
      ${validationWarnings.length>12?`<div class="schedule-alert-body">+${validationWarnings.length-12} uyarı daha var.</div>`:""}</div>`);
  }
  if(!failed.length&&!validationErrors.length){
    parts.push(`<div class="schedule-alert ok"><div class="schedule-alert-title">Tüm dersler yerleşti</div><div class="schedule-alert-body">Belirlenen kapalı saatler ve öğretmen/sınıf çakışmaları korunarak program oluşturuldu.</div></div>`);
  }

  // Yumuşak eşik geçildiyse kullanıcıya aramanın neden bittiğini ve en iyinin korunduğunu bildir
  if(result.timedOut && softFailed.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-body">⏳ Arama yumuşak eşiği geçtikten sonra da tamamlanana kadar devam etti; kaydedilen sonuç o ana kadarki en iyisi. Kalan dersler bu kısıtlarla yerleşemedi — aşağıdaki kapasite uyarılarına bakın veya öğretmen/sınıf kapalı saatlerini gevşetin.</div></div>`);
  }

  if(impossible.length){
    parts.push(impossible.map(i=>`<div class="schedule-alert danger">
      <div class="schedule-alert-title">${esc(i.name)}: kapasite aşılıyor</div>
      <div class="schedule-alert-body">${i.type} açık saati <strong>${i.open}</strong>, tanımlı ders saati <strong>${i.need}</strong>. En az <strong>${i.extra}</strong> saat bu şartlarda imkansız.</div>
    </div>`).join(""));
  }

  const forced=groupBlocks(result.forcedFailed||[]);
  if(forced.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">İmkansız olduğu için ayrılan dersler</div>
      <ul class="schedule-list">${forced.map(x=>`<li>${esc(x.className)} ${esc(x.course)} - ${esc(x.teacher)}: ${x.hours} saat (${esc(x.reason)})</li>`).join("")}</ul></div>`);
  }

  const soft=groupBlocks(softFailed);
  if(soft.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Yerleşmeyen ama farklı düzenle denenebilecek dersler</div>
      <div class="schedule-alert-body">Bu dersler kapasite hesabında imkansız görünmüyor; blok düzeni veya yerleşim sırası nedeniyle sıkışmış olabilir.${curSchool().constraints&&curSchool().constraints.spreadCourse?" <strong>Aynı dersin parçaları aynı güne denk gelmesin</strong> kuralı bu veriyle tam yerleşimi engelliyor olabilir — Kısıtlar sekmesinden bu kuralı kapatıp <strong>ders saat farkı</strong> kuralını (örn. 2) deneyin.":""}</div>
      <ul class="schedule-list">${soft.map(x=>{
        const kaynak=softFailed.find(f=>(f.className===x.className||defClasses(f).includes(x.className))&&f.course===x.course);
        let neden=""; try{ neden=kaynak?yerlesmemeNedeni(kaynak):""; }catch(e){}
        return `<li>${esc(x.className)} ${esc(x.course)} - ${esc(x.teacher)}: ${x.hours} saat${neden?`<div class="schedule-why">${neden}</div>`:""}</li>`;
      }).join("")}</ul></div>`);
  }

  const cv=result.constraintViolations;
  if(cv && cv.total>0){
    const items=[];
    if(cv.maxSameRunV>0) items.push(`Aynı ders veya aynı öğretmen üst üste sınırı aşıldı: ${cv.maxSameRunV} yer`);
    if(cv.spreadCourseV>0) items.push(`Aynı dersin aynı güne denk geldiği: ${cv.spreadCourseV} saat`);
    if(cv.spreadTeacherV>0) items.push(`Aynı öğretmenin farklı dersi aynı gün: ${cv.spreadTeacherV} saat`);
    if(cv.coursePairV>0) items.push(`Ders çifti aynı gün çakıştı: ${cv.coursePairV} saat`);
    if(cv.courseGapV>0) items.push(`Aynı dersin blokları arasında istenen saat farkı korunamadı: ${cv.courseGapV} saat`);
    if(cv.breakV>0) items.push(`Öğretmen dersleri arasında istenen teneffüs sağlanamadı: ${cv.breakV} dk`);
    if(cv.lunchV>0) items.push(`Öğretmenin günlük öğle arası sağlanamadı: ${cv.lunchV} öğretmen-gün`);
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Kısıt ihlalleri (${cv.total})</div>
      <div class="schedule-alert-body">Belirtilen derslerin tamamı yerleşti; aşağıdaki kısıtlar kısmen sağlanamadı (gün/slot sayısı yetersiz olabilir).</div>
      <ul class="schedule-list">${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`);
  }

  $("scheduleSaveBtn").style.display=validationErrors.length?"none":"";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");

  if(softFailed.length && result.attempts){
    const rounds=result.rounds?`${result.rounds} tam dağıtım turunda `:"";
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Maksimum arama sonucu</div><div class="schedule-alert-body">${rounds}${result.attempts} farklı kombinasyon denendi; son uzun aralıkta daha iyi yerleşim bulunamadı. Kalan dersler için kapasiteyi gevşetmek, öğretmen kapalı saatlerini açmak veya blok şartlarını değiştirmek gerekir.</div></div>`);
  }

  // Güvenlik doğrulaması: çizelge kısıtlara uygun mu?
  const verify=verifySchedule();
  if(verify.length){
    parts.push(`<div class="schedule-alert ${failed.length?'danger':'warn'}"><div class="schedule-alert-title">Çizelge doğrulaması — ${verify.length} sorun</div>
      <ul class="schedule-list">${verify.slice(0,20).map(x=>`<li>${esc(x)}</li>`).join("")}${verify.length>20?`<li>+${verify.length-20} sorun daha...</li>`:""}</ul></div>`);
  }

  const pr3=$('perfModeRow'); if(pr3) pr3.style.display='none';
  // Ortak dağıtım tam yerleşim bulamadıysa ve birden fazla okulda tanımlı ders varsa
  // "Sıralı dene" yedeği sunulur: distributeAll() okulları sırayla (iki okul sırası deneyerek) dağıtır.
  const multiSch = S.schools.filter(s=>(s.defs||[]).length).length>1;
  if(result.isJoint && failed.length && multiSch){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Ortak dağıtım yerleşmeyen derslerle bitti</div>
      <div class="schedule-alert-body">Okulları tek tek (iki farklı okul sırası deneyerek) dağıtmak bu durumda bazen daha iyi sonuç verir; bu yol mevcut yerleşimi siler ve onay ister.</div>
      <button class="btn primary" style="margin-top:8px" onclick="seqFallbackRun()">Sıralı dene (okul sırasını değiştirerek)</button></div>`);
  }
  $("scheduleReport").innerHTML=parts.join("");
  $("scheduleCloseBtn").textContent="Kapat";
}

async function autoSolve(){
  solveCancelled=false;
  _isSolving=true; liveBest=null;
  const startedAt=Date.now();
  const softAt=startedAt+SOLVE_SOFT_MS;
  const hardStop=startedAt+HARD_STOP_MS;
  showScheduleProgress(`Maksimum yerleşim aranıyor... (tamamı yerleşene kadar devam eder — istediğin an "Bitir" ile kaydedebilirsin)`,0);
  let best=null,bestScore=-Infinity,totalAttempts=0;
  let roundsRun=0; let timedOut=false;
  // ── LİMİTSİZ TURLAR: tamamı yerleşene, kullanıcı Bitir diyene veya 1 saatlik güvenlik ağı (HARD_STOP_MS) dolana kadar devam eder ──
  let round=0;
  while(true){
    round++; roundsRun=round;
    if(solveCancelled) break;
    if(!timedOut && Date.now()>softAt) timedOut=true; // yumuşak eşik: ⏳ uyarısı (arama durmaz)
    if(Date.now()>hardStop) break;                    // güvenlik ağı (1 saat)
    // Canlı progress: tur sayısı ve en iyi bilgisi
    const bestInfo = best ? ` • en iyi ${best.placedHours}/${best.totalHours} saat (${best.allFailed.length} eksik)` : "";
    showScheduleProgress(`${timedOut?"⏳ ":""}Tur ${round}: farklı blok ve saat kombinasyonu deneniyor${bestInfo} • ${Math.round((Date.now()-startedAt)/1000)} sn — tamamı yerleşene kadar devam ediyor, istediğin an "Bitir" ile kaydedebilirsin`, Math.min(96, 20 + (round % 20)*4));
    await waitFrame();
    if(solveCancelled) break;
    let result;
    try{
      result=await solve({flexibleBlocks:true,silentResult:true});
    }catch(err){
      console.error(err);
      showScheduleProgress("Dağıtım sırasında hata oluştu: "+err.message,0);
      toast("Dağıtım hatası: "+err.message,"err");
      return null;
    }
    if(!result) {
      if(solveCancelled && best) break;
      return null;
    }
    if(result.validationErrors&&result.validationErrors.length){
      showScheduleResult(result);
      return result;
    }
    // solve içinde iptal edildiyse ama en iyi varsa onu sakla
    if(solveCancelled && !result.placedHours && best) break;
    totalAttempts+=result.attempts||0;
    const score=(result.placedHours||0)*1000-(result.allFailed||[]).length;
    if(!best||score>bestScore){
      best=result; bestScore=score;
      liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed:best.forcedFailed, allFailed:best.allFailed, placedBlocks:best.placedBlocks, totalBlocks:best.totalBlocks, placedHours:best.placedHours, totalHours:best.totalHours};
    }
    if((result.failed||[]).length===0) break;
    // İç çözücü arama bütçesini doldurduysa yeniden tur açmanın anlamı yok; en iyiyi kullan
    if(result.timedOut){ timedOut=true; break; }
    if(solveCancelled) break;
    await waitFrame();
  }
  _isSolving=false;
  if(timedOut && best) best.timedOut=true;
  if(best&&best.lessons){
    curSchool().lessons=best.lessons.map(l=>({...l}));
    saveState(); renderDefs(); refresh();
    // J3: dağıtım bitti — yerleşemeyen tanımları kalıcı hatırla; tam yerleşimde temizle
    saveHardDefs((best.allFailed||[]).length?(best.allFailed).map(b=>b.defId||b.id).filter(Boolean):[]);
    best.attempts=totalAttempts;
    best.rounds=roundsRun;
    liveBest = {state:best.state, placed:best.placed, failed:best.failed, forcedFailed:best.forcedFailed, allFailed:best.allFailed, placedBlocks:best.placedBlocks, totalBlocks:best.totalBlocks, placedHours:best.placedHours, totalHours:best.totalHours};
    showScheduleResult(best);
    if((best.failed||[]).length===0) toast(`✓ İmkansızlar hariç tüm dersler yerleşti (${best.placedHours} saat).`,"ok");
    else toast(`⚠ Maksimum yerleşim bulundu: ${best.placedHours}/${best.totalHours} saat.`,"err");
  } else if(solveCancelled && liveBest){
    // iptal edildiyse son en iyi zaten applyLiveBest ile kaydedildi
  }
  return best;
}

// Tüm okulları sıralı dağıtır — bu sistem tam yerleşimi daha hızlı buluyor.
// Her okul kendi içinde limitsiz arar, iki sıra (düz/ters) denenip en az eksikli anlık görüntü saklanır.
async function distributeAll(){
  const schools=S.schools.filter(s=>(s.defs||[]).length);
  if(!schools.length){toast("Dağıtılacak okul yok.","err");return;}
  for(const sc of schools){
    const pre=precheckSchedule(sc);
    if(pre.blocking){ toast(`${sc.name}: ön kontrol sorunu. ${pre.issues[0]?.reason||""}`,"err"); return; }
  }
  solveCancelled=false;
  showScheduleOverlay();
  const hoursOf=sc=>sc.defs.reduce((s,x)=>s+Math.max(1,Number(x.hours)||1),0);
  // Zorluk sırası: kolay okul önce yerleşirse zor okula yer kalmıyor. Zorluk =
  // tanımlı saat / açık slot + paylaşılan öğretmen yükü (normalize edilip eklenir).
  const tLoad=teacherLoadMap(schools).load;
  const zorluk=new Map();
  for(const sc of schools){
    let open=0;
    for(const cl of sc.classes||[]) for(const d of (sc.days||SCHOOL_DFLT.days)) for(let p=1;p<=(sc.periods||10);p++) if(classOpenIn(sc,cl,d,p)) open++;
    const ts=[...new Set((sc.defs||[]).flatMap(d=>defTeachers(d)))];
    const avg=ts.length?ts.reduce((s,t)=>s+(tLoad[t]||0),0)/ts.length:0;
    zorluk.set(sc.id,{ratio:hoursOf(sc)/Math.max(1,open),load:avg});
  }
  const maxLoad=Math.max(1,...schools.map(sc=>zorluk.get(sc.id).load));
  const zorlukSirasi=[...schools].sort((a,b)=>{
    const za=zorluk.get(a.id), zb=zorluk.get(b.id);
    return (zb.ratio+zb.load/maxLoad)-(za.ratio+za.load/maxLoad);
  });
  const ords=[]; const seenOrd=new Set();
  for(const o of [zorlukSirasi,[...zorlukSirasi].reverse(),schools,[...schools].reverse()]){
    const k=o.map(sc=>sc.id).join(">"); if(seenOrd.has(k)) continue; seenOrd.add(k); ords.push(o);
  }
  const snapshot=()=>JSON.parse(JSON.stringify(schools.map(sc=>sc.lessons)));
  const restore=(sn)=>{ schools.forEach((sc,i)=>sc.lessons=sn[i]); };
  let best=null, bestSnap=null;
  const startT=Date.now();
  const maxRounds=5, budget=240000;
  outer:
  for(let round=0; round<maxRounds && !solveCancelled; round++){
    if(Date.now()-startT>budget) break;
    for(const ord of ords){
      if(solveCancelled) break;
      for(const sc of schools) sc.lessons=[];
      let total=0, failed=0; const ordFailedDefs=[];
      for(const sc of ord){
        if(solveCancelled) break;
        S.currentSchool=sc.id;
        showScheduleProgress(`${sc.name} dağıtılıyor... (tur ${round+1})`,12);
        await waitFrame();
        const r=await solve({flexibleBlocks:true,silentResult:true});
        total+=r.placedHours||0; failed+=(r.allFailed||[]).length;
        for(const b of (r.allFailed||[])) if(b&&(b.defId||b.id)) ordFailedDefs.push(b.defId||b.id);
      }
      if(!best||total-failed*100000>best.total-best.failed*100000){ best={ord,total,failed,failedDefs:ordFailedDefs}; bestSnap=snapshot(); }
      if(failed===0){ break outer; }
    }
  }
  if(!best){ showScheduleOverlay(); $("scheduleTitle").textContent="Dağıtım"; $("scheduleReport").innerHTML='<div class="schedule-alert danger">Dağıtım tamamlanamadı.</div>'; return; }
  if(bestSnap) restore(bestSnap);
  saveState(); renderDefs(); refresh();
  // J3: sıralı dağıtım bitti — yerleşemeyen tanımları kalıcı hatırla; tam yerleşimde temizle
  saveHardDefs(best.failed===0?[]:(best.failedDefs||[]).filter(Boolean));
  const v=verifySchedule();
  showScheduleOverlay();
  $("scheduleProgress").style.display="none";
  $("scheduleSaveBtn").style.display="";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");
  $("scheduleCloseBtn").textContent="Kapat";
  $("scheduleTitle").textContent=v.length?`Dağıtım — ${v.length} sorun`:"Dağıtım tamamlandı";
  const summary=schools.map(sc=>{
    const placed=(sc.lessons||[]).length, need=hoursOf(sc);
    return `<div class="schedule-stat"><strong>${placed}/${need}</strong><span>${esc(sc.name)}</span></div>`;
  }).join("");
  $("scheduleReport").innerHTML=`<div class="schedule-summary">${summary}</div>`+(v.length
    ? `<div class="schedule-alert danger"><div class="schedule-alert-title">Çizelge doğrulaması — ${v.length} sorun</div><ul class="schedule-list">${v.slice(0,20).map(x=>`<li>${esc(x)}</li>`).join("")}${v.length>20?`<li>+${v.length-20} sorun daha...</li>`:""}</ul></div>`
    : `<div class="schedule-alert ok"><div class="schedule-alert-title">Sorun yok</div><div class="schedule-alert-body">Tüm okullar eksiksiz ve kısıtlara uygun dağıtıldı.</div></div>`);
  toast(v.length?`⚠ ${v.length} sorun — yeniden dağıtın veya raporu inceleyin.`:"✓ Tüm okullar dağıtıldı, doğrulama temiz.","ok");
}

// Sonuç ekranındaki "Sıralı dene" düğmesi: ortak çözüm tam yerleşim bulamazsa okulları
// sırayla, iki farklı okul sırası deneyerek dağıtmayı dener. distributeAll mevcut yerleşimi
// sildiği için showConfirm ile onay alınır.
function seqFallbackRun(){
  showConfirm("Sıralı Dağıtım","Okullar tek tek sırayla dağıtılacak (iki farklı okul sırası denenir) ve mevcut yerleşim silinecek. Devam edilsin mi?",ok=>{
    if(!ok) return;
    hideScheduleOverlay();
    distributeAll();
  });
}

/* ─── LİSTE ÖĞESİ DÜZENLEME ─── */
function setupInlineEdit(containerId, getList, saveFn){
  const container=$(containerId);
  if(!container) return;
  container.addEventListener("dblclick",e=>{
    const btn=e.target.closest(".side-item,.pill-item");
    if(!btn||btn.querySelector("input")||btn.classList.contains("empty")) return;
    // Önce normal click'in refresh'ini bekle
    setTimeout(()=>{
      // Buton hala DOM'da mı?
      if(!document.contains(btn)) return;
      const oldVal=btn.dataset.cl||btn.dataset.tc||btn.dataset.course||(btn.childNodes[0]&&btn.childNodes[0].textContent.trim())||"";
      btn.innerHTML="";
      const input=document.createElement("input");
      input.value=oldVal;
      input.style.cssText="width:100%;border:1px solid var(--blue);border-radius:3px;padding:2px 4px;font:inherit;outline:none";
      btn.appendChild(input);
      input.focus();input.select();
      function done(){
        const newVal=input.value.trim();
        if(newVal&&newVal!==oldVal) saveFn(oldVal,newVal);
        saveState();refresh();
      }
      input.addEventListener("keydown",ev=>{
        if(ev.key==="Enter"){ev.preventDefault();done();}
        if(ev.key==="Escape"){refresh();}
      });
      input.addEventListener("blur",done);
    },50);
    e.stopPropagation();
  });
}

function renderSideLists(){
  const cl=$("classList");
  // Sayaç: yerleşen ders sayısı / açık ders saati kapasitesi (okul seçimine göre)
  const cntCls=(sc,c)=>`${(sc.lessons||[]).filter(l=>lessonClasses(l).includes(c)).length}/${classOpenSlots(sc,c)}`;
  if(S.viewAll){
    const items=[];
    for(const sc of S.schools){ if(!(sc.defs||[]).length) continue; for(const c of [...sc.classes].sort(trSort)){
      const active=(sc.id===S.currentSchool&&sc.selectedClass===c);
      items.push(`<div class="side-item${active?" active":""}" data-cl="${esc(c)}" data-school="${esc(sc.id)}">
        <input type="checkbox" class="si-cb" value="${esc(sc.name)} / ${esc(c)}">
        <span class="si-name">${esc(sc.name)} — ${esc(c)}</span>
        <span class="count" title="Yerleşen / açık saat">${cntCls(sc,c)}</span>
        <span class="si-del" data-del="class:${esc(c)}" data-del-school="${esc(sc.id)}">&times;</span>
      </div>`);
    }}
    cl.innerHTML=items.length?items.join(""):'<div class="empty" style="padding:10px">Henüz sınıf yok</div>';
  }else{
    const sc=curSchool();
    const sortedClasses=[...sc.classes].sort(trSort);
    cl.innerHTML=sc.classes.length
      ? sortedClasses.map(c=>
          `<div class="side-item${sc.selectedClass===c?" active":""}" data-cl="${esc(c)}">
            <input type="checkbox" class="si-cb" value="${esc(c)}">
            <span class="si-name">${esc(c)}</span>
            <span class="count" title="Yerleşen / açık saat">${cntCls(sc,c)}</span>
            <span class="si-del" data-del="class:${esc(c)}">&times;</span>
          </div>`).join("")
      : '<div class="empty" style="padding:10px">Henüz sınıf yok</div>';
  }

  const tl=$("teacherList");
  const sortedTeachers=[...S.teachers].sort(trSort);
  tl.innerHTML=S.teachers.length
    ? sortedTeachers.map(t=>{
        const tSchools=S.viewAll?schoolsWithDefs():[curSchool()];
        let placed=0,cap=0;
        for(const sc of tSchools){
          const cls=new Set();
          for(const d of sc.defs||[]){ if(defTeachers(d).includes(t)) cls.add(d.className); }
          placed+=(sc.lessons||[]).filter(l=>lessonTeachers(l).includes(t)).length;
          if(cls.size) cap+=teacherCap(sc,t,cls);
        }
        const cnt=cap?`${placed}/${cap}`:placed;
        return `<div class="side-item${S.selectedTeacher===t?" active":""}" data-tc="${esc(t)}">
          <input type="checkbox" class="si-cb" value="${esc(t)}">
          <span class="si-name">${esc(t)}</span>
          <span class="count" title="Yerleşen / kapasite">${cnt}</span>
          <span class="si-del" data-del="teacher:${esc(t)}">&times;</span>
        </div>`;
      }).join("")
    : '<div class="empty" style="padding:10px">Henüz öğretmen yok</div>';
}

function renderRoomList(){
  const rl=$("roomList");
  if(!rl) return;
  const sortedRooms=[...(S.rooms||[])].sort(trSort);
  const ref=curSchool();
  const cap=(ref?(ref.days||SCHOOL_DFLT.days).length*(ref.periods||10):50);
  rl.innerHTML=sortedRooms.length
    ? sortedRooms.map(r=>{
        const cnt=S.schools.reduce((s,sc)=>s+(sc.lessons||[]).filter(l=>l.room===r).length,0);
        return `<div class="side-item${S.selectedRoom===r?" active":""}" data-rm="${esc(r)}">
          <input type="checkbox" class="si-cb" value="${esc(r)}">
          <span class="si-name">${esc(r)}</span>
          <span class="count" title="Yerleşen / haftalık kapasite">${cnt}/${cap}</span>
          <span class="si-del" data-del="room:${esc(r)}">&times;</span>
        </div>`;
      }).join("")
    : '<div class="empty" style="padding:10px">Henüz derslik yok</div>';
}

function renderRoomDefs(room, schoolFilter){
  const el=$("roomDefsList");
  if(!el) return;
  // Okul bazlı sekmede o okulun; "Birlikte"de TÜM okulların dersleri tek listede
  const schools=schoolFilter?S.schools.filter(s=>s.name===schoolFilter):S.schools.filter(s=>(s.defs||[]).length);
  el.innerHTML='<div class="ed-head">Bu derslikte tanımlı dersler'+(schoolFilter?` (${schoolFilter})`:" (tüm okullar)")+'</div>';
  const allDefs=[];
  for(const sc of schools){
    for(const d of sc.defs||[]){ if(d.room===room){ const placed=(sc.lessons||[]).filter(l=>l.room===room&&l.course===d.course&&defClasses(d).some(c=>lessonClasses(l).includes(c))).length; allDefs.push({d,placed,sc}); } }
  }
  if(!allDefs.length){ el.innerHTML+='<div style="font-size:12px;color:var(--text3);padding:8px 0">Bu derslikte tanımlı ders yok.</div>'; return; }
  el.innerHTML+='<table class="ed-table"><thead><tr><th>Okul</th><th>Sınıf</th><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th></tr></thead><tbody>'+
    allDefs.map(({d,placed,sc})=>{
      const cls=placed>=d.hours?"ok":placed>0?"warn":"err";
      const badge=placed>=d.hours?"Tam":placed>0?`${placed}/${d.hours}`:"Bekliyor";
      return `<tr><td>${esc(sc.name)}</td><td>${esc(d.className)}</td><td><strong>${esc(d.course)}</strong></td><td>${esc(defLabel(d))}</td><td>${d.hours}</td><td><span class="def-badge ${cls}">${badge}</span></td></tr>`;
    }).join("")+'</tbody></table>';
}

// Silme işlemleri (delegasyon)
document.querySelectorAll(".side-list").forEach(list=>{
  list.addEventListener("click",e=>{
    const del=e.target.closest(".si-del");
    if(!del) return;
    e.stopPropagation();
    const [kind, name] = del.dataset.del.split(":");
    if(!kind||!name) return;
    const delFn=()=>{
      if(kind==="class"){
        // TÜMÜ modunda derslik silme: sınıfın ait olduğu okulda işlem yap
        const sc=del.dataset.delSchool?S.schools.find(x=>x.id===del.dataset.delSchool):curSchool();
        if(sc){
          sc.classes=(sc.classes||[]).filter(c=>c!==name);
          sc.defs=(sc.defs||[]).filter(d=>!defClasses(d).includes(name));
          sc.lessons=(sc.lessons||[]).filter(l=>!lessonClasses(l).includes(name));
          if(sc.classClosed&&sc.classClosed[name]) delete sc.classClosed[name];
          if(sc.selectedClass===name) sc.selectedClass=(sc.classes[0]||null);
        }
      }else if(kind==="teacher"){
        S.teachers=S.teachers.filter(t=>t!==name);
        for(const school of S.schools){
          school.defs=school.defs.filter(d=>!defTeachers(d).includes(name));
          school.lessons=school.lessons.filter(l=>!lessonTeachers(l).includes(name));
        }
        delete S.teacherClosed[name];
        delete S.teacherCourses[name];
        if(S.selectedTeacher===name) S.selectedTeacher=S.teachers[0]||null;
      }else if(kind==="room"){
        S.rooms=S.rooms.filter(r=>r!==name);
        for(const school of S.schools){
          for(const d of school.defs||[]) if(d.room===name) d.room=null;
          for(const l of school.lessons||[]) if(l.room===name) l.room=null;
        }
        if(S.selectedRoom===name) S.selectedRoom=S.rooms[0]||null;
      }
      saveState();refresh();
      toast(`"${name}" silindi.`);
    };
    const msg=kind==="class"?"Bu sınıfı ve tüm ders tanımlarını silsin mi?":kind==="teacher"?"Bu öğretmeni tüm okullardaki dersleriyle birlikte silsin mi?":"Bu dersliği silsin mi? (Bu derslikteki dersler dersliksiz kalır)";
    showConfirm("Sil",msg,ok=>{if(ok)delFn();});
  });
});

// Toplu silme
const bulkMap={delClassesBtn:"classList",delTeachersBtn:"teacherList"};
for(const [btnId,listId] of Object.entries(bulkMap)){
  $(btnId)?.addEventListener("click",()=>{
    const checked=[...$(listId).querySelectorAll(".si-cb:checked")].map(cb=>cb.value);
    if(!checked.length){toast("Seçili öğe yok.","err");return;}
    showConfirm("Toplu Sil",`${checked.length} öğe silinecek.`,ok=>{
      if(!ok) return;
      for(const name of checked){
        if(btnId==="delClassesBtn"){
          // TÜMÜ modunda checkbox değeri "OKUL / SINIF" biçimindedir
          const slash=name.indexOf(" / ");
          const sc=slash>0?S.schools.find(x=>x.name===name.slice(0,slash)):curSchool();
          const cls=slash>0?name.slice(slash+3):name;
          if(sc&&cls){
            sc.classes=(sc.classes||[]).filter(c=>c!==cls);
            sc.defs=(sc.defs||[]).filter(d=>!defClasses(d).includes(cls));
            sc.lessons=(sc.lessons||[]).filter(l=>!lessonClasses(l).includes(cls));
            if(sc.classClosed&&sc.classClosed[cls]) delete sc.classClosed[cls];
            if(sc.selectedClass===cls) sc.selectedClass=(sc.classes[0]||null);
          }
        }else if(btnId==="delTeachersBtn"){
          S.teachers=S.teachers.filter(t=>t!==name);
          for(const school of S.schools){
            school.defs=school.defs.filter(d=>!defTeachers(d).includes(name));
            school.lessons=school.lessons.filter(l=>!lessonTeachers(l).includes(name));
          }
          delete S.teacherClosed[name];
          delete S.teacherCourses[name];
          if(S.selectedTeacher===name) S.selectedTeacher=S.teachers[0]||null;
        }else if(btnId==="delCoursesBtn"){
          curSchool().courses=curSchool().courses.filter(c=>c!==name);
          curSchool().defs=curSchool().defs.filter(d=>d.course!==name);
          curSchool().lessons=curSchool().lessons.filter(l=>l.course!==name);
          for(const t of Object.keys(S.teacherCourses)) S.teacherCourses[t]=S.teacherCourses[t].filter(c=>c!==name);
        }
      }
      saveState();refresh();
      toast(`${checked.length} öğe silindi.`);
    });
  });
}

// Liste düzenleme kurulumu
setupInlineEdit("classList",()=>curSchool().classes,(oldVal,newVal)=>{
  const idx=curSchool().classes.indexOf(oldVal);
  if(idx>-1){curSchool().classes[idx]=newVal.toUpperCase();curSchool().classes.sort(trSort);}
  // defs ve lessons'daki referansları güncelle (birleşik tanımlarda classNames dizisi de)
  const nv=newVal.toUpperCase();
  for(const d of curSchool().defs){
    if(d.className===oldVal) d.className=nv;
    if(Array.isArray(d.classNames)) d.classNames=d.classNames.map(c=>c===oldVal?nv:c);
  }
  for(const l of curSchool().lessons){
    if(l.className===oldVal) l.className=nv;
    if(Array.isArray(l.classNames)) l.classNames=l.classNames.map(c=>c===oldVal?nv:c);
  }
  if(curSchool().selectedClass===oldVal) curSchool().selectedClass=newVal.toUpperCase();
  // classClosed'daki anahtarı güncelle
  if(curSchool().classClosed[oldVal]){curSchool().classClosed[newVal.toUpperCase()]=curSchool().classClosed[oldVal];delete curSchool().classClosed[oldVal];}
});
setupInlineEdit("teacherList",()=>S.teachers,(oldVal,newVal)=>{
  const idx=S.teachers.indexOf(oldVal);
  if(idx>-1){S.teachers[idx]=newVal;S.teachers.sort(trSort);}
  for(const school of S.schools){
    for(const d of school.defs){ const i=defTeachers(d).indexOf(oldVal); if(i>-1){ d.teachers[i]=newVal; setTeachers(d,d.teachers); } }
    for(const l of school.lessons){ const i=lessonTeachers(l).indexOf(oldVal); if(i>-1){ l.teachers[i]=newVal; setTeachers(l,l.teachers); } }
  }
  if(S.selectedTeacher===oldVal) S.selectedTeacher=newVal;
  // teacherClosed ve teacherCourses
  if(S.teacherClosed[oldVal]){S.teacherClosed[newVal]=S.teacherClosed[oldVal];delete S.teacherClosed[oldVal];}
  if(S.teacherCourses[oldVal]){S.teacherCourses[newVal]=S.teacherCourses[oldVal];delete S.teacherCourses[oldVal];}
});

/* ============================================================
   DERS ADLARI (branş listesi)
   ============================================================ */
function addCourse(name){
  const n=name.trim();
  if(!n) return false;
  if(!curSchool().courses) curSchool().courses=[];
  if(curSchool().courses.includes(n)) return false;
  curSchool().courses.push(n);
  return true;
}



// Hızlı ders adı ekle
$("addCourseQuickBtn").addEventListener("click",()=>{
  const n=$("addCourseQuick").value.trim();
  if(!n) return;
  if(addCourse(n)){saveState();renderDefs();$("addCourseQuick").value="";toast(`"${n}" eklendi.`);}
  else toast("Zaten var.","err");
});
$("addCourseQuick").addEventListener("keydown",e=>{
  if(e.key==="Enter") $("addCourseQuickBtn").click();
});
// Toplu ders ekle
$("bulkCourseToggleBtn").addEventListener("click",()=>{
  const area=$("bulkCourseArea2");
  area.style.display=area.style.display==="none"?"":"none";
  if(area.style.display!=="none"){$("bulkCourseText2").value="";$("bulkCourseText2").focus();}
});
$("bulkCourseDo2").addEventListener("click",()=>{
  const lines=$("bulkCourseText2").value.split("\n").map(s=>s.trim()).filter(Boolean);
  if(!lines.length)return;
  let added=0;
  for(const l of lines){if(addCourse(l))added++;}
  $("bulkCourseArea2").style.display="none";
  if(added){saveState();renderDefs();toast(`${added} ders eklendi.`);}
  else toast("Hiçbiri eklenemedi.","err");
});

// Ders adı silme (chiplerden)
$("courseChips").addEventListener("click",e=>{
  const del=e.target.closest("[data-del-course]");
  if(!del)return;
  const name=del.dataset.delCourse;
  showConfirm("Sil",`"${name}" dersini ve tüm tanımlarını silsin mi?`,ok=>{
    if(!ok)return;
    curSchool().courses=curSchool().courses.filter(c=>c!==name);
    curSchool().defs=curSchool().defs.filter(d=>d.course!==name);
    curSchool().lessons=curSchool().lessons.filter(l=>l.course!==name);
    for(const t of Object.keys(S.teacherCourses)) S.teacherCourses[t]=S.teacherCourses[t].filter(c=>c!==name);
    saveState();renderDefs();
    toast(`"${name}" silindi.`);
  });
});

/* ============================================================
   ÖĞRETMEN-DERS EŞLEŞTİRME
   ============================================================ */
function getTeacherCourses(t){return S.teacherCourses[t]||[]}
function addTeacherCourse(t,c){
  if(!t||!c)return;
  if(!S.teacherCourses[t])S.teacherCourses[t]=[];
  if(!S.teacherCourses[t].includes(c))S.teacherCourses[t].push(c);
  saveState();
}
function removeTeacherCourse(t,c){
  if(!S.teacherCourses[t])return;
  S.teacherCourses[t]=S.teacherCourses[t].filter(x=>x!==c);
  if(!S.teacherCourses[t].length)delete S.teacherCourses[t];
  saveState();
}

function renderAssignments(){
  const tDl=$("assignTeacherList"),aDl=$("assignCourseList");
  if(tDl) tDl.innerHTML=[...S.teachers].sort(trSort).map(t=>`<option value="${esc(t)}">`).join("");
  if(aDl) aDl.innerHTML=[...curSchool().courses].sort(trSort).map(c=>`<option value="${esc(c)}">`).join("");

  const aL=$("assignList");
  const chips=[];
  for(const t of Object.keys(S.teacherCourses||{}).sort(trSort)){
    for(const c of [...S.teacherCourses[t]].sort(trSort)) chips.push({teacher:t,course:c});
  }
  aL.innerHTML=chips.length
    ? chips.map(({teacher,course})=>
        `<div class="assign-item">
          <span class="ai-t">${esc(teacher)}</span>
          <span class="ai-arrow">&rarr;</span>
          <span class="ai-c">${esc(course)}</span>
          <button class="del" data-atc="${esc(teacher)}" data-acc="${esc(course)}" title="Eşleşmeyi kaldır">&times;</button>
        </div>`
      ).join("")
    : '<div style="font-size:12px;color:var(--text3);padding:8px 0">Henüz eşleştirme yok.</div>';

  aL.querySelectorAll(".del").forEach(btn=>{
    btn.addEventListener("click",()=>{
      removeTeacherCourse(btn.dataset.atc,btn.dataset.acc);
      renderAssignments();
      buildCourseOpts();
    });
  });
}

function getBlockDist(hours, block){
  const max=block||2;
  const dist=[];
  let rem=hours;
  while(rem>0){const sz=Math.min(max,rem);dist.push(sz);rem-=sz;}
  return dist;
}

function updateDefPreview(){
  const courses=[...$("defCourse").selectedOptions].map(o=>o.value);
  const teachers=[...$("defTeacher").selectedOptions].map(o=>o.value);
  const classes=[...$("defClass").selectedOptions].map(o=>o.value);
  const hours=Math.max(1,Number($("defHours").value)||2);
  const block=Number($("defBlock").value)||2;
  const el=$("defPreview");
  if(!courses.length||!teachers.length||!classes.length){
    el.classList.remove("show");
    el.innerHTML="";
    return;
  }
  const fixed=!!$("defBlockFixed").checked;
  const dist=fixed?[hours]:getBlockDist(hours,block);
  const room=$("defRoom")&&$("defRoom").value?$("defRoom").value:null;
  const extras=extraChecks($("defExtra"));
  const extraClasses=$("defExtraClass")?[...$("defExtraClass").selectedOptions].map(o=>o.value):[];
  const parts=[];
  for(const course of courses){
    for(const t of teachers){
      const all=[t,...extras.filter(x=>x!==t)];
      for(const c of classes){
        const cLabel=extraClasses.length?`${c} + ${extraClasses.join(" + ")}`:c;
        parts.push(`<span>${esc(course)} <em>&rarr;</em> ${esc(tLabelArr(all))} <em>&rarr;</em> ${esc(cLabel)}${room?` <strong class="room-chip">${esc(room)}</strong>`:""}</span>`);
      }
    }
  }
  el.innerHTML=`<div style="width:100%;font-size:11px;color:var(--text2);margin-bottom:2px">${hours} saat = ${dist.join("+")} blok${fixed?' <strong style="color:var(--blue)">(tek blok, parçalanmaz)</strong>':''} — ${parts.length} kayıt</div>`+parts.join("");
  el.classList.add("show");
}

function filterTeachersByCourse(){
  const course=$("defCourse").value;
  const sel=$("defTeacher");
  // H2.3: liste yeniden çizilse bile hâlâ geçerli olan öğretmen seçimini koru
  const prev=[...(sel.selectedOptions||[])].map(o=>o.value);
  if(!course){
    sel.innerHTML=[...S.teachers].sort(trSort).map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join("");
    sel.size=Math.max(6,Math.min(Math.max(S.teachers.length,2),15));
    for(const o of sel.options) if(prev.includes(o.value)) o.selected=true;
    return;
  }
  // Bu dersi veren öğretmenleri bul
  const tSet=new Set();
  for(const [t,courses] of Object.entries(S.teacherCourses||{})){
    if(courses.includes(course)) tSet.add(t);
  }
  const list=tSet.size?[...tSet]:[...S.teachers];
  list.sort(trSort);
  sel.innerHTML=list.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join("");
  const cnt=Math.max(6,Math.max(list.length,2));
  sel.size=cnt;
  sel.style.height=Math.min(cnt*20+10,150)+"px";
  sel.style.overflowY="auto";
  for(const o of sel.options) if(prev.includes(o.value)) o.selected=true;
}

/* ============================================================
   DERS TANIMLAMA
   ============================================================ */
// Tanimli Dersler tablosunun siralama durumu (sutun basligina tiklanarak degisir)
let defSort={key:"course",dir:1};
function renderDefs(){
  // Ders adları: düzenli liste (× ile silme)
  const chips=$("courseChips");
  const courses=[...curSchool().courses].sort(trSort);
  chips.innerHTML=courses.length
    ? courses.map(c=>`<div class="course-item"><span>${esc(c)}</span><button class="del" data-del-course="${esc(c)}" title="Bu dersi kaldır">&times;</button></div>`).join("")
    : '<div style="font-size:12px;color:var(--text3);padding:6px 0">Henüz ders eklenmedi.</div>';
  chips.querySelectorAll(".del").forEach(btn=>{
    btn.addEventListener("click",()=>{
      const name=btn.dataset.delCourse;
      curSchool().courses=curSchool().courses.filter(c=>c!==name);
      curSchool().defs=curSchool().defs.filter(d=>d.course!==name);
      curSchool().lessons=curSchool().lessons.filter(l=>l.course!==name);
      for(const t of Object.keys(S.teacherCourses)) S.teacherCourses[t]=S.teacherCourses[t].filter(c=>c!==name);
      saveState();renderDefs();
      toast(`"${name}" dersi kaldırıldı.`);
    });
  });

  // Ders alanı: çoklu seçim listesi
  const cSel=$("defCourse");
  cSel.innerHTML=[...curSchool().courses].sort(trSort).map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
  const cCount=Math.max(curSchool().courses.length,2);
  cSel.size=Math.max(6,Math.min(cCount,8));
  cSel.style.height=Math.min(cSel.size*20+10,150)+"px";
  if(!curSchool().courses.length) cSel.innerHTML='<option value="">Önce ders ekleyin</option>';

  // Öğretmen (multi-select)
  const tSel=$("defTeacher");
  filterTeachersByCourse();
  if(!S.teachers.length) tSel.innerHTML='<option value="">Önce öğretmen ekleyin</option>';

  // Ek öğretmenler (multi-select — Ctrl ile çoklu seçim; mevcut seçim korunur)
  const tExtra=$("defExtra");
  if(tExtra){
    const prev=extraChecks(tExtra);
    renderExtraTeachers(tExtra, prev);
  }

  // Sınıf (multi-select)
  const clSel=$("defClass");
  clSel.innerHTML=[...curSchool().classes].sort(trSort).map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
  const clsCount=Math.max(curSchool().classes.length,2);
  clSel.size=Math.max(6,clsCount);
  clSel.style.height=Math.min(clSel.size*20+10,150)+"px";
  clSel.style.overflowY="auto";
  if(!curSchool().classes.length) clSel.innerHTML='<option value="">Önce sınıf ekleyin</option>';

  // Ek sınıflar (birleşik sınıf): Sınıf'ta seçili olmayanlar; defClass değişiminde de çağrılır
  renderDefExtraClasses();

  // Derslik (opsiyonel)
  const rSel=$("defRoom");
  if(rSel){
    const prev=rSel.value;
    rSel.innerHTML='<option value="">— (derslik yok)</option>'+(S.rooms||[]).sort(trSort).map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join("");
    if(prev) rSel.value=prev;
  }

  renderAssignments();

  // Tanımlı Dersler tablosu (Okul-Sınıf-Ders-Öğretmen-Saat-Durum)
  const listSchools=S.viewAll?schoolsWithDefs():[curSchool()];
  const placed={};
  for(const sc of listSchools){ for(const l of sc.lessons||[]){ const k=`${sc.id}|${refKey(l.course,lessonTeachers(l),lessonClasses(l))}`; placed[k]=(placed[k]||0)+1; } }

  const total=curSchool().defs.reduce((s,d)=>s+(d.hours||0),0);
  $("defSummary").textContent=curSchool().defs.length?`Toplam ${curSchool().defs.length} ders, ${total} saat`:"";
  $("defSummary").style.marginBottom="10px";

  const list=$("defList");
  const allDefs=[];
  for(const sc of listSchools){ for(const d of sc.defs||[]) allDefs.push({d,sc}); }
  if(!allDefs.length){
    list.innerHTML='<tbody><tr><td colspan="7" style="padding:12px;color:var(--text3)">Henüz ders tanımlanmadı.</td></tr></tbody>';
    return;
  }

  // Sutun basligina tiklanarak siralama; ayni basliga tekrar tiklamak yonu cevirir
  const sirala=({d,sc})=>{
    const ph=placed[`${sc.id}|${refKey(d.course,defTeachers(d),defClasses(d))}`]||0;
    switch(defSort.key){
      case "school":  return sc.name;
      case "class":   return defClasses(d).join(" + ");
      case "teacher": return defLabel(d);
      case "hours":   return d.hours||0;
      case "status":  return (ph>=d.hours?2:(ph>0?1:0))*1000 + ph;
      default:        return d.course;
    }
  };
  const rows=[...allDefs].sort((a,b)=>{
    const va=sirala(a), vb=sirala(b);
    const c = (typeof va==="number"&&typeof vb==="number") ? va-vb : trSort(String(va),String(vb));
    return (c*defSort.dir) || trSort(a.d.course,b.d.course);
  }).map(({d,sc})=>{
    const ph=placed[`${sc.id}|${refKey(d.course,defTeachers(d),defClasses(d))}`]||0;
    let badge,bc;
    if(ph>=d.hours){badge="Tam";bc="ok";}
    else if(ph>0){badge=`${ph}/${d.hours}`;bc="warn";}
    else{badge="Bekliyor";bc="err";}
    return `<tr onclick="toggleDefPanel('${d.id}')" title="Ayarları açılır pencerede düzenle">
      <td><input type="checkbox" class="si-cb" value="${d.id}" onclick="event.stopPropagation()"></td>
      <td>${esc(sc.name)}</td>
      <td>${esc(defClasses(d).join(" + "))}</td>
      <td><strong>${esc(d.course)}</strong></td>
      <td>${esc(defLabel(d))}</td>
      <td>${d.hours}${d.blockFixed?' <span style="font-size:10px;color:var(--blue)">tek blok</span>':''}</td>
      <td><span class="def-badge ${bc}">${badge}</span></td>
    </tr>`;
  }).join("");
  const ok=k=>defSort.key===k?(defSort.dir>0?" ▲":" ▼"):"";
  const bas=(k,ad)=>`<th class="sortable${defSort.key===k?" sorted":""}" data-sort="${k}" title="${esc(ad)} sütununa göre sırala">${esc(ad)}${ok(k)}</th>`;
  list.innerHTML=`<thead><tr><th style="width:24px"></th>${bas("school","Okul")}${bas("class","Sınıf")}${bas("course","Ders")}${bas("teacher","Öğretmen")}${bas("hours","Saat")}${bas("status","Durum")}</tr></thead><tbody>${rows}</tbody>`;
  list.querySelectorAll("th.sortable").forEach(th=>{
    th.addEventListener("click",()=>{
      const k=th.dataset.sort;
      if(defSort.key===k) defSort.dir=-defSort.dir; else { defSort.key=k; defSort.dir=1; }
      renderDefs();
    });
  });
}

/* ============================================================
   BAĞLAM MENÜSÜ
   ============================================================ */
let ctxData=null;
// Ders tanımı düzenleme modu: seçili def'in özellikleri (saat, blok, derslik vb.) güncellenir
let editingDefId=null;
function setEditMode(def){
  editingDefId=def?def.id:null;
  const banner=$("defEditBanner");
  if(banner){
    banner.style.display=editingDefId?"flex":"none";
    if(editingDefId) $("defEditLabel").textContent=`Düzenleniyor: ${def.course} — ${def.className} (${def.teacher})`;
  }
  const btn=$("defSubmitBtn");
  if(btn) btn.textContent=editingDefId?"Değişiklikleri Kaydet":"Ders Ekle";
}
function clearDefForm(){
  $("defCourse").value="";
  $("defHours").value="1";$("defBlock").value="1";$("defBlockFixed").checked=false;
  if($("defRoom")) $("defRoom").value="";
  if($("defExtra")) renderExtraTeachers($("defExtra"), []);
  for(const o of $("defTeacher").options) o.selected=false;
  for(const o of $("defClass").options) o.selected=false;
  if($("defExtraClass")){ for(const o of $("defExtraClass").options) o.selected=false; renderDefExtraClasses(); }
  setOptField("extraTeacher", false); setOptField("extraClass", false);
  $("defPreview").classList.remove("show");$("defPreview").innerHTML="";
  setEditMode(null);
}
// Düzenleme modunda öğretmen/sınıf çoklu seçimini tek seçime indir (değişeni tut)
function singleSelectIfEditing(sel){
  if(!editingDefId) return;
  const opts=[...sel.selectedOptions];
  if(opts.length>1){
    for(const o of sel.options) o.selected=false;
    opts[opts.length-1].selected=true;
  }
}

// Dersler sekmesi: 3 büyük butonla panel değiştir
document.querySelectorAll(".ltab").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".ltab").forEach(b=>b.classList.toggle("active",b===btn));
    document.querySelectorAll(".ltab-panel").forEach(p=>p.classList.toggle("active",p.id==="ltab-"+btn.dataset.ltab));
    if(btn.dataset.ltab==="classes") renderClassDefsOverview();
  });
});
// Sınıflara tanımlanan dersler genel görünümü (kart başına sınıf)
function renderClassDefsOverview(){
  const el=$("classDefsOverview");
  if(!el) return;
  const listSchools=S.viewAll?schoolsWithDefs():[curSchool()];
  if(!listSchools.length){ el.innerHTML='<div class="empty">Henüz okul yok.</div>'; return; }
  el.innerHTML='<div class="class-defs-overview">'+listSchools.map(sc=>{
    const placed={};
    for(const l of sc.lessons){ const k=refKey(l.course,lessonTeachers(l),lessonClasses(l)); placed[k]=(placed[k]||0)+1; }
    if(!(sc.classes||[]).length) return '';
    return sc.classes.map(cl=>{
      const defs=(sc.defs||[]).filter(d=>defClasses(d).includes(cl));
      const rows=defs.length?defs.map(d=>{
        const ph=placed[refKey(d.course,defTeachers(d),defClasses(d))]||0;
        const cls=ph>=d.hours?"ok":ph>0?"warn":"err";
        const badge=ph>=d.hours?"Tam":ph>0?`${ph}/${d.hours}`:"Bekliyor";
        return `<tr onclick="toggleDefPanel('${d.id}')" title="Ayarları açılır pencerede düzenle">
          <td><strong>${esc(d.course)}</strong></td>
          <td>${esc(defLabel(d))}</td>
          <td>${d.hours}</td>
          <td><span class="def-badge ${cls}">${badge}</span></td>
          <td>${d.room?`<span class="room-chip">${esc(d.room)}</span>`:""}</td>
        </tr>`;
      }).join(""):'<tr><td colspan="5" style="color:var(--text3);padding:6px 8px">Bu sınıfa tanımlı ders yok</td></tr>';
      return `<div class="cdo-card">
        <div class="cdo-head">${esc(sc.name)} — ${esc(cl)} <span class="count">${defs.length} ders</span></div>
        <table class="ed-table sortable"><thead><tr><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th><th>Derslik</th></tr></thead><tbody>${rows}</tbody></table>
      </div>`;
    }).join("");
  }).join("")+'</div>';
  el.querySelectorAll(".ed-table.sortable").forEach(t=>makeSortable(t));
}

function showCtx(e,mode,entity,day,period){
  e.preventDefault();
  ctxData={mode,entity,day,period};

  $("ctxTitle").textContent=`${day} ${period}. saat - ${entity}`;

  const pf=$("ctxPartnerField");
  const ps=$("ctxPartner");ps.innerHTML="";

  if(mode==="class"){
    $("ctxPartnerLabel").textContent="Öğretmen";
    pf.style.display="";
    S.teachers.forEach(t=>{const o=document.createElement("option");o.value=t;o.textContent=t;ps.appendChild(o);});
  }else if(mode==="teacher"){
    $("ctxPartnerLabel").textContent="Sınıf";
    pf.style.display="";
    curSchool().classes.forEach(c=>{const o=document.createElement("option");o.value=c;o.textContent=c;ps.appendChild(o);});
  }

  $("ctxCourseList").innerHTML=curSchool().courses.map(c=>`<option value="${esc(c)}">`).join("");
  $("ctxCourse").value="";

  const m=$("ctxMenu");
  m.style.left=Math.min(e.clientX,window.innerWidth-270)+"px";
  m.style.top=Math.min(e.clientY,window.innerHeight-250)+"px";
  m.classList.remove("hidden");
  $("ctxCourse").focus();
}

function hideCtx(){ $("ctxMenu").classList.add("hidden"); ctxData=null; }

/* ============================================================
   OLAYLAR
   ============================================================ */

// Karanlık mod
function applyBrandIcon(){
  const src=S.darkMode?"icon-dark.svg":"icon.svg";
  const bi=document.querySelector(".brand-icon");
  if(bi) bi.src=src;
  let link=document.querySelector('link[rel="icon"]');
  if(!link){ link=document.createElement("link"); link.rel="icon"; link.type="image/svg+xml"; (document.head||document.documentElement).appendChild(link); }
  link.href=src;
}
if(S.darkMode){document.getElementById("app").classList.add("dark");$("darkModeBtn").innerHTML=`<span class="ms material-symbols-outlined">light_mode</span><span id="darkModeLabel">Aydınlık</span>`;}
applyBrandIcon();
$("darkModeBtn").addEventListener("click",()=>{
  S.darkMode=!S.darkMode;
  document.getElementById("app").classList.toggle("dark",S.darkMode);
  saveState();
  $("darkModeBtn").innerHTML=`<span class="ms material-symbols-outlined">${S.darkMode?"light_mode":"dark_mode"}</span><span id="darkModeLabel">${S.darkMode?"Aydınlık":"Koyu"}</span>`;
  applyBrandIcon();
});

// Okul yönetimi
function populateSchoolSelect(){
  const sel=$("schoolSelect");
  sel.innerHTML=S.schools.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("")+'<option value="__ALL__">TÜMÜ</option>';
  sel.value=S.viewAll?"__ALL__":S.currentSchool;
}
$("schoolSelect").addEventListener("change",()=>{
  const v=$("schoolSelect").value;
  if(v==="__ALL__"){
    S.viewAll=true;
    // TÜMÜ: sınıf/öğretmen/derslik listeleri tüm okulları gösterir; düzenleme son seçilen okulda yapılır
  }else{
    S.viewAll=false;
    S.currentSchool=v;
  }
  saveState();refresh();
});
$("addSchoolBtn").addEventListener("click",()=>{
  showPrompt("Okul Adı","Okul adı",ok=>{
    if(!ok) return;
    const name=$("modalInput").value.trim();
    if(!name) return;
    const id="s"+Date.now().toString(36);
    const school=newSchool(id);
    school.name=name;
    S.schools.push(school);
    S.currentSchool=id;
    saveState();refresh();
    toast(`"${name}" okulu eklendi.`);
  });
});
// Sağ tık menüsünde okul silme yok, basit tutalım

// Navigasyon
document.querySelectorAll(".nav-btn").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".nav-btn").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
    const t=$(`view-${btn.dataset.view}`);
    if(t) t.classList.add("active");
    refresh();
  });
});
// İlk yüklemede okul seçiciyi doldur
populateSchoolSelect();

// Öğretmen görünümü sekmeleri: ORTAOKUL | LİSE | Birlikte
$("teacherTabs").addEventListener("click",e=>{
  const btn=e.target.closest(".tab");
  if(!btn) return;
  teacherViewMode=btn.dataset.tmode;
  document.querySelectorAll("#teacherTabs .tab").forEach(b=>b.classList.toggle("active",b===btn));
  refresh();
});
$("roomTabs")?.addEventListener("click",e=>{
  const btn=e.target.closest(".tab");
  if(!btn) return;
  roomViewMode=btn.dataset.tmode;
  document.querySelectorAll("#roomTabs .tab").forEach(b=>b.classList.toggle("active",b===btn));
  refresh();
});
// Çizelgeyi Doğrula: tüm okulların çizelgesini kısıtlara göre kontrol eder
$("teacherVerifyBtn").addEventListener("click",()=>{
  const v=verifySchedule();
  showScheduleOverlay();
  $("scheduleTitle").textContent=v.length?`Çizelge Doğrulaması — ${v.length} sorun`:"Çizelge Doğrulaması";
  $("scheduleProgress").style.display="none";
  $("scheduleSaveBtn").style.display="none";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");
  $("scheduleCloseBtn").textContent="Kapat";
  $("scheduleReport").innerHTML=v.length
    ? `<div class="schedule-alert danger"><div class="schedule-alert-title">${v.length} sorun bulundu</div>
        <ul class="schedule-list">${v.slice(0,30).map(x=>`<li>${esc(x)}</li>`).join("")}${v.length>30?`<li>+${v.length-30} sorun daha...</li>`:""}</ul>
        <div class="schedule-alert-body">Sorunlu çizelge kullanılmamalı; yeniden dağıtım önerilir.</div></div>`
    : `<div class="schedule-alert ok"><div class="schedule-alert-title">Sorun yok</div>
        <div class="schedule-alert-body">Çizelge tüm kısıtlara uygun: çakışma, teneffüs ve öğle arası kontrolleri temiz.</div></div>`;
});

// Okul ayarları
function autoFillTimes(){
  const start=$("startTimeInput")&&$("startTimeInput").value;
  const lessonMin=Math.max(1,Number(($("lessonMinInput")&&$("lessonMinInput").value)||40));
  const breakMin=Math.max(0,Number(($("breakMinInput")&&$("breakMinInput").value)||10));
  const periods=curSchool().periods||10;
  if(!start||!start.includes(":")){ toast("Başlangıç saati girin (örn. 09:00).","err"); return false; }
  const pad=n=>String(n).padStart(2,"0");
  let [h,m]=start.split(":").map(Number);
  if(!Number.isFinite(h)||!Number.isFinite(m)){ toast("Başlangıç saati geçersiz.","err"); return false; }
  const times=[];
  for(let i=0;i<periods;i++){
    const s=`${pad(h)}:${pad(m)}`;
    m+=lessonMin; h+=Math.floor(m/60); m%=60;
    const e=`${pad(h)}:${pad(m)}`;
    times.push({start:s,end:e});
    m+=breakMin; h+=Math.floor(m/60); m%=60;
  }
  curSchool().periodTimes=times;
  return true;
}
$("autoFillTimesBtn").addEventListener("click",()=>{
  if(autoFillTimes()){ saveState(); renderSchoolTimes(); refresh(); toast("Ders saatleri otomatik dolduruldu."); }
});
$("applySchoolBtn").addEventListener("click",()=>{
  const days=$("daysInput").value.split(",").map(s=>s.trim()).filter(Boolean);
  const periods=Math.max(1,Math.min(16,Number($("periodsInput").value)||10));
  curSchool().days=days;curSchool().periods=periods;
  // Ders saatlerini sıfırla (Otomatik Doldur alanları doluysa onları kullan)
  if(!autoFillTimes()) curSchool().periodTimes=defaultPeriodTimes(periods);
  saveState();refresh();
  toast("Okul saatleri güncellendi.");
});

// Sidebar seçim
$("classList").addEventListener("click",e=>{
  if(e.target.closest(".si-cb")||e.target.closest(".si-del")) return;
  const btn=e.target.closest(".side-item");if(!btn)return;
  if(btn.dataset.school) S.currentSchool=btn.dataset.school;
  curSchool().selectedClass=btn.dataset.cl;S.selectedTeacher=null;
  document.querySelectorAll("#teacherList .side-item").forEach(el=>el.classList.remove("active"));
  saveState();refresh();
});
$("teacherList").addEventListener("click",e=>{
  if(e.target.closest(".si-cb")||e.target.closest(".si-del")) return;
  const btn=e.target.closest(".side-item");if(!btn)return;
  S.selectedTeacher=btn.dataset.tc;curSchool().selectedClass=null;
  document.querySelectorAll("#classList .side-item").forEach(el=>el.classList.remove("active"));
  saveState();refresh();
});
$("roomList")?.addEventListener("click",e=>{
  if(e.target.closest(".si-cb")||e.target.closest(".si-del")) return;
  const btn=e.target.closest(".side-item");if(!btn)return;
  S.selectedRoom=btn.dataset.rm;
  saveState();refresh();
});

// Ekleme
function addSingleClass(name){
  const c=name.toUpperCase();
  if(!c) return false;
  if(!curSchool().classes) curSchool().classes=[];
  if(curSchool().classes.includes(c)) return false;
  curSchool().classes.push(c);return true;
}
function addSingleTeacher(name){
  if(!name) return false;
  if(!S.teachers) S.teachers=[];
  if(S.teachers.includes(name)) return false;
  S.teachers.push(name);return true;
}
function addSingleRoom(name){
  const r=name.trim().toUpperCase();
  if(!r) return false;
  if(!S.rooms) S.rooms=[];
  if(S.rooms.includes(r)) return false;
  S.rooms.push(r);return true;
}

$("addClassBtn").addEventListener("click",()=>{
  showPrompt("Sınıf Ekle","Sınıf adı", ok=>{
    if(!ok) return;
    const c=$("modalInput").value.trim();
    if(!c) return;
    if(addSingleClass(c)){curSchool().selectedClass=c.toUpperCase();saveState();refresh();toast("Sınıf eklendi.");}
    else toast("Zaten var veya geçersiz.","err");
  });
});
function setupBulkAdd(btnId, areaId, textId, doId, addFn, mode){
  const btn=$(btnId), area=$(areaId), text=$(textId), doBtn=$(doId);
  if(!btn||!area||!text||!doBtn)return;
  btn.addEventListener("click",()=>{
    const h=area.style.display;
    area.style.display=h==="none"?"":"none";
    if(area.style.display!=="none"){text.value="";text.focus();}
  });
  doBtn.addEventListener("click",()=>{
    const lines=text.value.split("\n").map(s=>s.trim()).filter(Boolean);
    if(!lines.length)return;
    let added=0;
    for(const l of lines){if(addFn(l))added++;}
    area.style.display="none";
    if(added){
      if(mode==="class") curSchool().selectedClass=lines[0].toUpperCase();
      if(mode==="teacher") S.selectedTeacher=lines[0];
      saveState();refresh();toast(`${added} eklendi.`);
    }else toast("Hiçbiri eklenemedi.","err");
  });
}
setupBulkAdd("bulkClassBtn","bulkClassArea","bulkClassText","bulkClassDo",n=>addSingleClass(n),"class");
setupBulkAdd("bulkTeacherBtn","bulkTeacherArea","bulkTeacherText","bulkTeacherDo",n=>addSingleTeacher(n),"teacher");
setupBulkAdd("bulkRoomBtn","bulkRoomArea","bulkRoomText","bulkRoomDo",n=>addSingleRoom(n),"room");

$("addRoomBtn")?.addEventListener("click",()=>{
  showPrompt("Derslik Ekle","Derslik adı (örn. Bilgisayar Laboratuvarı)", ok=>{
    if(!ok) return;
    const r=$("modalInput").value.trim();
    if(!r) return;
    if(addSingleRoom(r)){S.selectedRoom=r.trim().toUpperCase();saveState();refresh();toast("Derslik eklendi.");}
    else toast("Zaten var veya geçersiz.","err");
  });
});
$("delRoomsBtn")?.addEventListener("click",()=>{
  const checked=[...($("roomList")?.querySelectorAll(".si-cb:checked")||[])].map(cb=>cb.value);
  if(!checked.length){toast("Seçili derslik yok.","err");return;}
  showConfirm("Derslikleri Sil",`${checked.length} derslik silinecek.`,ok=>{
    if(!ok) return;
    for(const name of checked){
      S.rooms=S.rooms.filter(r=>r!==name);
      for(const school of S.schools){
        for(const d of school.defs||[]) if(d.room===name) d.room=null;
        for(const l of school.lessons||[]) if(l.room===name) l.room=null;
      }
    }
    if(S.selectedRoom&&!S.rooms.includes(S.selectedRoom)) S.selectedRoom=S.rooms[0]||null;
    saveState();refresh();
    toast(`${checked.length} derslik silindi.`);
  });
});

$("addTeacherBtn").addEventListener("click",()=>{
  showPrompt("Öğretmen Ekle","Öğretmen adı", ok=>{
    if(!ok) return;
    const t=$("modalInput").value.trim();
    if(!t) return;
    if(addSingleTeacher(t)){S.selectedTeacher=t;saveState();refresh();toast("Öğretmen eklendi.");}
    else toast("Zaten var veya geçersiz.","err");
  });
});


// Öğretmen-Ders eşleştirme
$("assignBtn").addEventListener("click",()=>{
  const t=($("assignTeacher").value||"").trim();
  const c=($("assignCourse").value||"").trim();
  if(!t||!c){toast("Öğretmen ve ders seçin (veya yazın).","err");return;}
  if(!S.teachers.includes(t)) S.teachers.push(t);
  addTeacherCourse(t,c);
  if(!curSchool().courses.includes(c)) curSchool().courses.push(c);
  renderAssignments();
  $("assignCourse").value="";
  $("assignTeacher").value="";
  toast(`"${t}" → "${c}" eşleştirildi.`);
});
$("defCourse").addEventListener("change",()=>{filterTeachersByCourse();updateDefPreview();});
$("defCourse").addEventListener("input",updateDefPreview);
$("defHours").addEventListener("input",updateDefPreview);
$("defBlock").addEventListener("change",updateDefPreview);
// Multi-select değişikliklerinde önizleme güncelle (change + click ile)
$("defTeacher").addEventListener("change",()=>{singleSelectIfEditing($("defTeacher"));updateDefPreview();});
$("defTeacher").addEventListener("click",()=>setTimeout(updateDefPreview,30));
$("defExtra")?.addEventListener("change",updateDefPreview);
$("defExtraClass")?.addEventListener("change",updateDefPreview);
$("extraTeacherToggle")?.addEventListener("click",()=>toggleOptField("extraTeacher"));
$("extraClassToggle")?.addEventListener("click",()=>toggleOptField("extraClass"));
$("defClass").addEventListener("change",()=>{singleSelectIfEditing($("defClass"));renderDefExtraClasses();updateDefPreview();});
$("defClass").addEventListener("click",()=>setTimeout(updateDefPreview,30));

// Ders tanımlama / düzenleme
function submitDefForm(){
  try{
    const courses=[...$("defCourse").selectedOptions].map(o=>o.value).filter(Boolean);
    const teachers=[...$("defTeacher").selectedOptions].map(o=>o.value);
    const classes=[...$("defClass").selectedOptions].map(o=>o.value);
    const extras=extraChecks($("defExtra"));
    const extraClasses=$("defExtraClass")?[...$("defExtraClass").selectedOptions].map(o=>o.value):[];
    const hours=Math.max(1,Number($("defHours").value)||2);
    const block=Number($("defBlock").value);
    const blockFixed=!!$("defBlockFixed").checked;
    const room=$("defRoom")&&$("defRoom").value?$("defRoom").value:null;

    if(!courses.length||!teachers.length||!classes.length){toast("Lütfen en az bir ders, öğretmen ve sınıf seçin.","err");return;}

    // Düzenleme modu: seçili def'in özelliklerini güncelle (yeni def EKLEME)
    if(editingDefId){
      const d=curSchool().defs.find(x=>x.id===editingDefId);
      if(d){
        const course=courses[0], t=teachers[0], c=classes[0];
        const tList=[t,...extras.filter(x=>x&&x!==t)];
        const cList=extraClasses.length?[c,...extraClasses]:[c];
        const dup=curSchool().defs.find(x=>x.id!==d.id&&refKey(x.course,defTeachers(x),defClasses(x))===refKey(course,tList,cList));
        if(dup){ toast("Bu ders/öğretmenler/sınıf için zaten bir tanım var.","err"); return; }
        const oldRef=refKey(d.course,defTeachers(d),defClasses(d));
        d.course=course; setTeachers(d,tList); setClasses(d,cList); d.hours=hours; d.block=block; d.blockFixed=blockFixed; d.room=room;
        // Ders adı/öğretmen değiştiyse bu tanıma ait yerleşmiş dersleri de güncelle (tutarlılık)
        for(const l of curSchool().lessons){
          if(refKey(l.course,lessonTeachers(l),lessonClasses(l))===oldRef){ l.course=course; setTeachers(l,tList); l.room=room; }
        }
        if(!curSchool().courses.includes(course)) curSchool().courses.push(course);
        for(const t2 of tList){
          if(!S.teachers.includes(t2)) S.teachers.push(t2);
          addTeacherCourse(t2,course);
        }
        saveState();renderDefs();refresh();
        toast(`"${course}" güncellendi. Yeniden dağıtım gerekebilir.`);
        clearDefForm();
        return;
      }
    }

    // Yeni ders oluşturma (ders × öğretmen × sınıf matrisi; her tanıma ek öğretmenler eklenir)
    for(const course of courses){ if(!curSchool().courses.includes(course)) curSchool().courses.push(course); }
    const allT=[...new Set([...teachers,...extras])];
    for(const t2 of allT) if(!S.teachers.includes(t2)) S.teachers.push(t2);
    let count=0;
    for(const course of courses){
      for(const t of teachers){
        for(const c of classes){
          if(!curSchool().defs) curSchool().defs=[];
          const base={id:uid(),course,className:c,hours,block,blockFixed,room};
          // Ek sınıf doluysa: tek tanım, classNames=[c,...ekSiniflar] (birleşik sınıf)
          if(extraClasses.length) setClasses(base,[c,...extraClasses]);
          curSchool().defs.push(setTeachers(base,[t,...extras.filter(x=>x&&x!==t)]));
          for(const t2 of [t,...extras.filter(x=>x&&x!==t)]) addTeacherCourse(t2,course);
          count++;
        }
      }
    }
    clearDefForm();
    saveState();renderDefs();
    toast(`${count} ders tanımlandı.`);
  }catch(err){
    toast("Hata: "+err.message,"err");
  }
}
$("defSubmitBtn").addEventListener("click",submitDefForm);
$("defEditCancel").addEventListener("click",()=>{clearDefForm();renderDefs();toast("Düzenleme iptal edildi.");});
$("delDefsBtn").addEventListener("click",()=>{
  const sel=[...document.querySelectorAll("#defList input:checked")].map(i=>i.value);
  if(!sel.length){toast("Seçili ders yok.","err");return;}
  curSchool().defs=curSchool().defs.filter(d=>!sel.includes(d.id));
  curSchool().lessons=curSchool().lessons.filter(l=>curSchool().defs.some(d=>refKey(d.course,defTeachers(d),defClasses(d))===refKey(l.course,lessonTeachers(l),lessonClasses(l))));
  saveState();renderDefs();refresh();
  toast(`${sel.length} ders silindi.`);
});
$("defList").addEventListener("dblclick",e=>{
  const item=e.target.closest("tr");
  if(!item)return;
  const cb=item.querySelector(".si-cb");
  const id=cb?cb.value:null;
  if(!id)return;
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d)return;
  // Formu düzenleme modunda doldur (def silinmez; "Değişiklikleri Kaydet" ile güncellenir)
  const dcs=defClasses(d);
  for(const o of $("defCourse").options) o.selected=(o.value===d.course);
  for(const o of $("defTeacher").options) o.selected=(o.value===d.teacher);
  for(const o of $("defClass").options) o.selected=(o.value===(dcs[0]||d.className));
  const ev=new Event("change",{bubbles:true});
  $("defCourse").dispatchEvent(ev);
  $("defTeacher").dispatchEvent(ev);
  $("defClass").dispatchEvent(ev);
  $("defHours").value=d.hours;$("defBlock").value=d.block;
  $("defBlockFixed").checked=!!d.blockFixed;
  if($("defRoom")) $("defRoom").value=d.room||"";
  const exSel=defTeachers(d).slice(1);
  if($("defExtra")) renderExtraTeachers($("defExtra"), exSel);
  if($("defExtra")) $("defExtra").dispatchEvent(new Event("change",{bubbles:true}));
  // Ek sınıflar: birincil sınıf dışındaki sınıflar seçili getirilir
  if($("defExtraClass")){
    const rest=dcs.slice(1);
    for(const o of $("defExtraClass").options) o.selected=rest.includes(o.value);
    $("defExtraClass").dispatchEvent(ev);
  }
  // Duzenlenen tanimda ek secim varsa ilgili panel acik gelsin, yoksa kullanici gormez
  setOptField("extraTeacher", exSel.length>0);
  setOptField("extraClass", dcs.length>1);
  setEditMode(d);
  updateDefPreview();
  $("defForm").scrollIntoView({behavior:"smooth",block:"nearest"});
});

/* ─── DERS SAAT AYARLARI ─── */
function defaultPeriodTimes(n){
  const times=[];
  let h=9,m=0;
  for(let i=0;i<n;i++){
    const start=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
    m+=40;
    if(m>=60){h+=Math.floor(m/60);m=m%60;}
    const end=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
    times.push({start,end});
    m+=10; // teneffüs
    if(m>=60){h+=Math.floor(m/60);m=m%60;}
  }
  return times;
}

// Okul ayarları alanlarını aktif okuldan doldurur.
// (Daha önce bu alanlar index.html'deki sabit değerlerde kalıyordu: okul değiştirince
//  güncellenmiyor, LİSE 9 saatlik olduğu halde kutuda 10 yazıyordu. "Uygula"ya basınca
//  okula olmayan bir saat eklenip çizelge bozuluyordu.)
function syncSchoolInputs(){
  const sc=curSchool(); if(!sc) return;
  const d=$("daysInput"), p=$("periodsInput");
  if(d){ d.value=(sc.days||[]).join(","); d.title=d.value; }
  if(p) p.value=sc.periods;
  const pt=sc.periodTimes||[];
  const st=$("startTimeInput"), lm=$("lessonMinInput"), bm=$("breakMinInput");
  if(st) st.value=(pt[0]&&pt[0].start)||"09:00";
  if(lm) lm.value=(pt[0]&&pt[0].start&&pt[0].end)?Math.max(1,toMin(pt[0].end)-toMin(pt[0].start)):40;
  if(bm) bm.value=(pt[0]&&pt[1]&&pt[0].end&&pt[1].start)?Math.max(0,toMin(pt[1].start)-toMin(pt[0].end)):10;
}

function renderSchoolTimes(){
  syncSchoolInputs();
  const grid=$("timeGrid");
  // periodTimes'i güncelle
  if(!curSchool().periodTimes||curSchool().periodTimes.length!==curSchool().periods){
    curSchool().periodTimes=defaultPeriodTimes(curSchool().periods);
    saveState();
  }
  let html='';
  for(let i=0;i<curSchool().periods;i++){
    const t=curSchool().periodTimes[i]||{start:"",end:""};
    html+=`<div class="pt-row">
      <label>${i+1}.</label>
      <div class="pt-times">
        <input type="time" class="pt-start" data-idx="${i}" value="${t.start}">
        <span class="pt-sep">—</span>
        <input type="time" class="pt-end" data-idx="${i}" value="${t.end}">
      </div>
    </div>`;
  }
  grid.innerHTML=html;
}

$("saveTimesBtn").addEventListener("click",()=>{
  const times=[];
  const starts=document.querySelectorAll(".pt-start");
  const ends=document.querySelectorAll(".pt-end");
  for(let i=0;i<curSchool().periods;i++){
    times.push({start:starts[i].value,end:ends[i].value});
  }
  curSchool().periodTimes=times;
  saveState();
  // Grid başlıklarını güncelle (tüm görünümler)
  if(document.querySelector(".nav-btn.active")?.dataset.view==="school") refresh();
  toast("Ders saatleri kaydedildi.");
});

// Grid tıklama (okul: kapat → öğle arası → aç döngüsü)
$("schoolGrid").addEventListener("click",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c)return;
  cycleSchoolCell(c.dataset.day,Number(c.dataset.period));refresh();
});
$("classGrid").addEventListener("click",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!curSchool().selectedClass)return;
  toggleClass(curSchool().selectedClass,c.dataset.day,Number(c.dataset.period));refresh();
});
$("teacherGrid").addEventListener("click",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!S.selectedTeacher)return;
  if(typeof teacherViewMode!=="undefined" && teacherViewMode==="birlikte"){ toast("Birlikte görünümde saat kapatma yok — LİSE veya ORTAOKUL sekmesine geçin.","err"); return; }
  let sid=S.currentSchool;
  if(typeof teacherViewMode!=="undefined"){ const sc=tabOkulu(teacherViewMode); if(sc) sid=sc.id; }
  if(!c.dataset.day || !c.dataset.period) return;
  toggleTeacher(S.selectedTeacher,c.dataset.day,Number(c.dataset.period),sid);refresh();
});

// Grid sağ tık — sadece sınıf/öğretmen görünümünde ders eklenir
$("schoolGrid").addEventListener("contextmenu",e=>{
  const c=e.target.closest(".grid-cell");if(!c)return;
  if(c.classList.contains("lesson")){toast("Burada zaten ders var. Silmek için × butonunu kullanın.","err");return;}
  toast("Ders eklemek için Sınıflar veya Öğretmenler görünümüne geçin.","");
  e.preventDefault();
});
$("classGrid").addEventListener("contextmenu",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!curSchool().selectedClass)return;
  const d=c.dataset.day,p=Number(c.dataset.period);
  if(!classOpen(curSchool().selectedClass,d,p)){toast("Sınıf saati kapalı.","err");return;}
  showCtx(e,"class",curSchool().selectedClass,d,p);
});
$("teacherGrid").addEventListener("contextmenu",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!S.selectedTeacher)return;
  if(typeof teacherViewMode!=="undefined" && teacherViewMode==="birlikte"){ toast("Birlikte görünümde ders ekleme yok — LİSE veya ORTAOKUL sekmesine geçin.","err"); return; }
  const d=c.dataset.day,p=Number(c.dataset.period);
  let sid=S.currentSchool;
  if(typeof teacherViewMode!=="undefined"){ const sc=tabOkulu(teacherViewMode); if(sc) sid=sc.id; }
  const sc=S.schools.find(s=>s.id===sid)||curSchool();
  if(!teacherOpenIn(sc,S.selectedTeacher,d,p)){toast("Öğretmen saati kapalı.","err");return;}
  showCtx(e,"teacher",S.selectedTeacher,d,p);
});

// Bağlam menüsü
$("ctxCancel").addEventListener("click",hideCtx);
$("ctxSave").addEventListener("click",()=>{
  if(!ctxData) return;
  const course=$("ctxCourse").value.trim();if(!course){toast("Ders adı girin.","err");return;}
  const block=Number($("ctxBlock").value);
  const partner=$("ctxPartner").value;
  if(!partner){toast("Lütfen seçim yapın.","err");return;}

  let teacher,className;
  if(ctxData.mode==="class"){className=ctxData.entity;teacher=partner;}
  else {teacher=ctxData.entity;className=partner;}

  if(!teacher||!className){toast("Eksik bilgi.","err");return;}
  const ok=addLesson(course,teacher,className,ctxData.day,ctxData.period,block);
  if(!ok){toast("Bu saatte çakışma var veya slot kapalı.","err");return;}
  // Aynı ders defs'te yoksa ekle
  if(!curSchool().defs.some(d=>refKey(d.course,defTeachers(d),defClasses(d))===refKey(course,[teacher],className))){
    curSchool().defs.push({id:uid(),course,teacher,className,hours:block,block});
    saveState();
  }
  hideCtx();refresh();
  toast(`"${course}" eklendi.`);
});

document.addEventListener("click",e=>{if(!e.target.closest("#ctxMenu"))hideCtx();});

// Örnek veri
$("sampleBtn").addEventListener("click",()=>{
  curSchool().classes=["9A","9B","10A","11SAY","12EA"];
  S.teachers=["Ali Yılmaz","Ayşe Demir","Mehmet Kaya","Fatma Şahin","Mustafa Çelik","Zeynep Aydın","Ahmet Koç","Elif Arslan"];
  curSchool().schoolClosed={};curSchool().classClosed={};S.teacherClosed={};curSchool().lessons=[];curSchool().defs=[];S.teacherCourses={};
  curSchool().courses=["Matematik","Türk Dili","Fizik","Kimya","Biyoloji","Edebiyat","Coğrafya"];
  S.rooms=["FEN LABORATUVARI","BİLGİSAYAR LABORATUVARI"];
  curSchool().selectedClass="9A";S.selectedTeacher=null;S.selectedRoom=null;

  // Örnek öğretmen-ders eşleştirmeleri
  const tcMap={
    "Ali Yılmaz":["Matematik"],
    "Ayşe Demir":["Türk Dili","Edebiyat"],
    "Mehmet Kaya":["Fizik"],
    "Fatma Şahin":["Kimya"],
    "Mustafa Çelik":["Matematik"],
    "Zeynep Aydın":["Edebiyat"],
    "Ahmet Koç":["Coğrafya"],
    "Elif Arslan":["Biyoloji"]
  };
  for(const [t,cs] of Object.entries(tcMap)) S.teacherCourses[t]=cs;

  // Örnek ders tanımları
  const sampleDefs=[
    ["Matematik","Ali Yılmaz","9A",6,2],
    ["Türk Dili","Ayşe Demir","9A",5,2],
    ["Fizik","Mehmet Kaya","9A",4,2,null,"FEN LABORATUVARI"],
    ["Kimya","Fatma Şahin","9A",4,2,null,"FEN LABORATUVARI"],
    ["Matematik","Ali Yılmaz","10A",6,2],
    ["Türk Dili","Ayşe Demir","10A",5,2],
    ["Biyoloji","Elif Arslan","10A",4,2,null,"FEN LABORATUVARI"],
    ["Matematik","Mustafa Çelik","11SAY",6,2],
    ["Fizik","Mehmet Kaya","11SAY",4,2,null,"FEN LABORATUVARI"],
    ["Kimya","Fatma Şahin","11SAY",4,2,null,"FEN LABORATUVARI"],
    ["Matematik","Mustafa Çelik","12SAY",6,2],
    ["Fizik","Mehmet Kaya","12SAY",4,2,null,"FEN LABORATUVARI"],
    ["Türk Dili","Ayşe Demir","12EA",5,2],
    ["Edebiyat","Zeynep Aydın","11EA",5,2],
    ["Coğrafya","Ahmet Koç","11EA",4,2]
  ];
  for(const [c,t,cl,h,b,unused,room] of sampleDefs){
    const def={id:uid(),course:c,teacher:t,className:cl,hours:h,block:b};
    if(room) def.room=room;
    curSchool().defs.push(def);
  }
  saveState();refresh();
  toast("Örnek veri yüklendi. Dersler sekmesini inceleyin, sonra Dağıt'a basın.");
});

function downloadState(){
  const b=new Blob([JSON.stringify(S,null,2)],{type:"application/json"});
  const a=document.createElement("a");
  const url=URL.createObjectURL(b);
  const d=new Date();
  a.href=url;
  a.download="planla-"+d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")+".json";
  a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast("Kaydedildi.");
}

// Kaydet/Aç
$("saveBtn").addEventListener("click",downloadState);
$("openFile").addEventListener("change",async e=>{
  const f=e.target.files[0];
  if(!f){ e.target.value=""; return; }
  let veri=null;
  try{ veri=JSON.parse(await f.text()); }
  catch{ toast("Geçersiz dosya.","err"); e.target.value=""; return; }
  showConfirm("Dosyayı Aç","Mevcut tüm veriler bu dosyadaki verilerle değiştirilecek. Devam edilsin mi?",ok=>{
    e.target.value="";
    if(!ok) return;
    try{
      // normalizeState eski formatlı yedekleri de dönüştürür (loadState ile aynı yol)
      const norm=normalizeState(veri);
      for(const k of Object.keys(S)) delete S[k];
      Object.assign(S,norm);
      if(!S.teacherClosed) S.teacherClosed={};
      if(!S.teacherCourses) S.teacherCourses={};
      if(!S.currentSchool && S.schools?.[0]) S.currentSchool=S.schools[0].id;
      saveState(); refresh(); toast("Açıldı.");
    }catch{ toast("Geçersiz dosya.","err"); }
    try{
      const v=verifySchedule();
      if(v.length) toast(`⚠ Çizelgede ${v.length} sorun bulundu (ör. ${v.slice(0,2).join("; ")}). Yeniden dağıtın.`,"err");
      else toast("Çizelge doğrulaması: sorun yok.");
    }catch{}
  });
});

// Dağıt (önce ön kontrol)
$("scheduleBtn").addEventListener("click",()=>{
  lastScheduleOptions={flexibleBlocks:true};
  showPrecheck();
});
/* ─── PARALEL DAĞITIM (Web Worker) ───────────────────────────────────────────
 * Tarayıcı tek iş parçacıklıdır: uygulama şimdiye kadar aynı anda TEK arama yapıyordu.
 * Ölçüm: aynı veride 6 bağımsız arama denendiğinde 6'dan 2'si TAM yerleşim buldu,
 * tek arama bulamıyordu — fark tamamen aramanın rastgele başlangıcından geliyor.
 * Burada birkaç işçi aynı anda ayrı çekirdekte arar; İLK TAM sonucu bulan kazanır,
 * kimse tam bulamazsa en iyisi alınır. Diğerleri hemen sonlandırılır.
 */
function paralelDestekVar(){
  try{ return typeof Worker==="function" && location.protocol!=="file:"; }catch(e){ return false; }
}
/* Tarayıcılar file:// ile açılan sayfada Web Worker'a izin vermez; o durumda çok çekirdekli
   arama kapalı kalır ve zor programlarda tam yerleşim bulma şansı belirgin düşer.
   Kullanıcı bunu sessizce yaşamasın: bir kez açıkça söylüyoruz. */
function paralelYokUyar(){
  if(paralelDestekVar()) return;
  const k="planlaParalelUyari";
  try{ if(localStorage.getItem(k)) return; localStorage.setItem(k,"1"); }catch(e){}
  toast("Çok çekirdekli arama kapalı: sayfa dosyadan açıldı. Klasördeki baslat.vbs ile açarsanız dağıtım tüm çekirdekleri kullanır ve zor programları tamamlama şansı artar.","err");
}
function isciSayisi(){
  const c=Number(navigator.hardwareConcurrency)||4;
  return Math.max(2, Math.min(6, c-1));   // bir çekirdeği arayüze bırak
}
let _isciler=[];
function isciDurdur(){
  for(const w of _isciler){ try{ w.terminate(); }catch(e){} }
  _isciler=[];
}
async function dagitParalel(opts){
  const completeOnly=!!(opts&&opts.completeOnly);
  const n=isciSayisi();
  const durum={ ad:S.currentSchool, tam:null, eniyi:null, biten:0, hata:0 };
  _isSolving=true; solveCancelled=false; liveBest=null;
  showScheduleOverlay();
  showScheduleProgress(`Paralel ${completeOnly?"tamamlama":"arama"}: ${n} bağımsız çözücü aynı anda başlatılıyor...`,3);
  const gonder=JSON.parse(JSON.stringify({
    schools:S.schools, teachers:S.teachers, teacherClosed:S.teacherClosed,
    teacherCourses:S.teacherCourses, currentSchool:S.currentSchool,
    selectedTeacher:S.selectedTeacher, rooms:S.rooms, selectedRoom:S.selectedRoom,
    darkMode:!!S.darkMode, viewAll:!!S.viewAll
  }));
  return new Promise(resolve=>{
    const bitir=()=>{
      isciDurdur();
      const kazanan=durum.tam||durum.eniyi;
      _isSolving=false;
      if(!kazanan){
        showScheduleProgress("Paralel arama sonuç veremedi.",100);
        toast("Paralel arama sonuç vermedi; tekil dağıtımı deneyin.","err");
        resolve(null); return;
      }
      for(const sc of S.schools){
        if(kazanan.lessons && kazanan.lessons[sc.id]) sc.lessons=kazanan.lessons[sc.id];
      }
      saveState(); renderDefs(); refresh();
      const res={
        totalHours:kazanan.toplam, placedHours:kazanan.yerlesen,
        totalBlocks:0, placedBlocks:0, forcedFailed:[], failed:[], allFailed:[],
        capacityIssues:[], validationWarnings:[], flexible:true, isJoint:true,
        paralel:{ isci:n, tam:!!durum.tam }
      };
      showScheduleResult(res);
      toast(durum.tam
        ? `✓ Paralel arama: tüm dersler yerleşti (${n} çözücüden biri buldu).`
        : `⚠ Paralel arama: en iyi sonuç ${kazanan.yerlesen}/${kazanan.toplam} saat.`,
        durum.tam?"ok":"err");
      resolve(res);
    };
    for(let i=0;i<n;i++){
      let w;
      try{ w=new Worker("solver-worker.js?v="+APP_SURUM); }catch(e){ durum.hata++; continue; }
      _isciler.push(w);
      w.onmessage=ev=>{
        const m=ev.data||{};
        if(m.tip==="ilerleme"){
          if(!durum.tam) showScheduleProgress(`Paralel (${n} çözücü) • #${m.seed+1}: ${m.metin}`, Math.max(5,Math.min(92,m.pct||0)));
          return;
        }
        if(m.tip==="hata"){ durum.hata++; durum.biten++; if(durum.biten>=n) bitir(); return; }
        if(m.tip==="bitti"){
          durum.biten++;
          if(m.tam && !durum.tam){ durum.tam=m; bitir(); return; }
          if(!durum.eniyi || (m.yerlesen||0)>(durum.eniyi.yerlesen||0)) durum.eniyi=m;
          if(durum.biten>=n) bitir();
        }
      };
      w.onerror=()=>{ durum.hata++; durum.biten++; if(durum.biten>=n) bitir(); };
      w.postMessage({tip:"basla", seed:i, state:gonder, completeOnly});
    }
    if(!_isciler.length){ _isSolving=false; hideScheduleOverlay(); toast("Paralel arama başlatılamadı.","err"); resolve(null); }
  });
}

$("distributeAllBtn").addEventListener("click",()=>{
  // Gerçek çok-okullu ortak çözücü: tüm okulların bloklarını tek havuzda, ortak öğretmen
  // çakışmalarını birlikte çözerek dağıtır. distributeAll (sıralı yol) sonuç ekranındaki
  // "Sıralı dene" düğmesiyle erişilebilir yedektir.
  // Mevcut yerleşimi tamamen siler; hâlihazırda iyi bir program varsa sonucu kötüleştirebilir,
  // bu yüzden önce onay alınır ve "Eksikleri Tamamla" alternatifi hatırlatılır.
  const yerlesik=S.schools.reduce((n,sc)=>n+((sc.lessons||[]).length),0);
  const uyari=yerlesik
    ? `Tüm okullardaki ${yerlesik} ders satırı silinip program sıfırdan oluşturulacak. Mevcut programınız iyiyse sonuç daha kötü olabilir — yalnız eksikleri kapatmak için "Eksikleri Tamamla" düğmesini kullanın. Devam edilsin mi?`
    : "Tüm okullar birlikte dağıtılacak. Devam edilsin mi?";
  showConfirm("Tümünü Dağıt",uyari,ok=>{
    if(!ok) return;
    applyModalPerfMode();
    lastScheduleOptions={flexibleBlocks:true};
    // Paralel arama tek aramadan belirgin biçimde daha çok TAM sonuç buluyor;
    // desteklenmiyorsa (ör. dosyadan açıldıysa) tekil aramaya düşülür.
    paralelYokUyar();
    if(paralelDestekVar()) dagitParalel();
    else solveAllJoint({flexibleBlocks:true});
  }, perfModeChooserHtml());
});
$("completeBtn").addEventListener("click",()=>{
  // Mevcut programı silmez, bu yüzden bir "onay" değil bir "başlatma seçenekleri" kutusudur:
  // 10 dakikaya kadar sürebildiği için performans modu önceden seçilebilmeli.
  showConfirm("Eksikleri Tamamla",
    "Mevcut program korunur; yalnız yerleşmemiş dersler yerleştirilir. Gerekirse birkaç mevcut ders yer değiştirir. Boşluklar kapatılana kadar devam eder (10. dakikadan sonra ⏳ uyarısı gösterilir) — istediğiniz an “Bitir” ile durdurup o ana kadarki en iyi sonucu kaydedebilirsiniz.",
    ok=>{
      if(!ok) return;
      applyModalPerfMode();
      lastScheduleOptions={flexibleBlocks:true,completeOnly:true};
      // Ölçüm: tam yerleşimi bulan yol, mevcut programdan devam eden artımlı onarım.
      // Paralel çalıştırınca bulma şansı belirgin artıyor.
      paralelYokUyar();
      if(paralelDestekVar()) dagitParalel({completeOnly:true});
      else solveAllJoint({flexibleBlocks:true,completeOnly:true});
    }, perfModeChooserHtml());
});
// Mevcut dağıtımı sil (tüm okulların yerleşmiş derslerini temizler)
$("clearDistBtn").addEventListener("click",()=>{
  showConfirm("Dağıtımı Sil","Tüm okullardaki yerleştirilmiş dersler silinecek. Devam edilsin mi?",ok=>{
    if(!ok) return;
    for(const sc of S.schools) sc.lessons=[];
    saveState(); renderDefs(); refresh();
    toast("Mevcut dağıtım silindi. Yeniden dağıtabilirsiniz.");
  });
});

// Aktif görünüm bağlamı (PDF/Excel başlığı için)
function exportContextLabel(){
  const mode=document.querySelector(".nav-btn.active")?.dataset.view||"school";
  if(mode==="class") return curSchool().selectedClass?`Sınıf: ${curSchool().selectedClass}`:"";
  if(mode==="teacher") return S.selectedTeacher?`Öğretmen: ${S.selectedTeacher}`:"";
  if(mode==="rooms") return S.selectedRoom?`Derslik: ${S.selectedRoom}`:"";
  return "Okul Saatleri";
}
function scopeLabel(scope){
  return {single:"Çizelge",classes:"Tüm Sınıflar",teachers:"Tüm Öğretmenler",rooms:"Tüm Derslikler",classTeacher:"Sınıflar+Öğretmenler",all:"Tüm Okullar"}[scope]||"Çizelge";
}
// Bir sınıfın çizelge tablosunu döndürür
// Bir tablo DOM'undan satırları (colspan açılarak) dizi olarak çıkarır
function cellToText(td){
  let s=td.innerHTML||"";
  if(!s) return "";
  s=s.replace(/<br\s*\/?>/gi,"\n").replace(/<\/(?:div|p|tr|h[1-6])>/gi,"\n").replace(/<[^>]+>/g,"")
    .replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&lt;/gi,"<").replace(/&gt;/gi,">").replace(/&quot;/gi,'"').replace(/&#39;/gi,"'");
  return s.replace(/[ \t]+/g," ").replace(/ *\n */g,"\n").replace(/\n{2,}/g,"\n").trim();
}
function tableToRows(tbl){
  const rows=[];
  for(const tr of tbl.querySelectorAll("tr")){
    const cells=[];
    for(const td of tr.querySelectorAll("th,td")){
      const span=td.colSpan||1;
      cells.push({v:cellToText(td), cls:td.className||"", span});
      for(let i=1;i<span;i++) cells.push({v:"",cls:"",span:0});
    }
    rows.push(cells);
  }
  return rows;
}
function xmlEsc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function buildClassSheet(sc,cl){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderGrid(tmp,"class",cl,sc);
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  // Alt tablo: Ders-Öğretmen-Saat + toplam
  const subRows=[["Ders","Öğretmen","Saat"]];
  let total=0;
  for(const d of sc.defs||[]){ if(d.className!==cl) continue; const h=Math.max(1,Number(d.hours)||1); subRows.push([String(d.course),String(defLabel(d)),String(h)]); total+=h; }
  subRows.push(["TOPLAM","",String(total)]);
  return {title:`${sc.name} — ${cl}`, tableHTML:html, rows, subRows};
}
// Bir öğretmenin birleşik (tüm okullar) çizelgesini döndürür
function buildTeacherSheet(t){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderTeacherCombined(tmp,t,"teacher");
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  // Alt tablo: Ders-Sınıf-Saat + toplam
  const subRows=[["Ders","Sınıf","Saat"]];
  let total=0;
  for(const sc of schoolsWithDefs()){ for(const d of sc.defs||[]){ if(!defTeachers(d).includes(t)) continue; const h=Math.max(1,Number(d.hours)||1); subRows.push([String(d.course),String(d.className),String(h)]); total+=h; } }
  subRows.push(["TOPLAM","",String(total)]);
  return {title:t, tableHTML:html, rows, subRows, wide:true};
}
function buildRoomSheet(r){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderTeacherCombined(tmp,r,"room");
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  return {title:`Derslik: ${r}`, tableHTML:html, rows, wide:true};
}
// Bir okulun ders listesi (Ders Adı + Öğretmen + Sınıf + Saat + Derslik) — çıktıların altına eklenir
function buildLessonListSheet(sc){
  const head=["Ders Adı","Öğretmen","Sınıf","Saat","Derslik"];
  const rows=[head.map(h=>({v:h,cls:""}))];
  for(const d of sc.defs||[]){
    rows.push([
      {v:String(d.course||""),cls:""},
      {v:String(defLabel(d)),cls:""},
      {v:String(d.className||""),cls:""},
      {v:String(Math.max(1,Number(d.hours)||1)),cls:""},
      {v:d.room?String(d.room):"",cls:""}
    ]);
  }
  const thead=rows[0].map(c=>`<th>${esc(c.v)}</th>`).join("");
  const tbody=rows.slice(1).map(r=>`<tr>${r.map(c=>`<td>${esc(c.v)}</td>`).join("")}</tr>`).join("");
  return {title:`${sc.name} — Ders Listesi`, tableHTML:`<table class="pa-list"><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table>`, rows};
}
function schoolsWithDefs(){ return S.schools.filter(s=>(s.defs||[]).length); }
// Aktif görünümün tek çizelgesini döndürür
function buildSingleSheet(){
  const mode=document.querySelector(".nav-btn.active")?.dataset.view||"school";
  let gridId="",title="";
  if(mode==="school"){ gridId="schoolGrid"; title=`${curSchool().name} — Okul Saatleri`; }
  else if(mode==="class"){ gridId="classGrid"; title=`${curSchool().name} — ${curSchool().selectedClass||"Sınıf"}`; }
  else if(mode==="teacher"){ gridId="teacherGrid"; title=`${curSchool().name} — ${S.selectedTeacher||"Öğretmen"}`; }
  else if(mode==="rooms"){ gridId="roomGrid"; title=`Derslik: ${S.selectedRoom||"Derslik"}`; }
  else return null;
  const tbl=$(gridId)&&$(gridId).querySelector("table");
  return tbl?{title, tableHTML:tbl.outerHTML, rows:tableToRows(tbl)}:null;
}
// Kapsama göre tüm çizelgeleri toplar; çoklu kapsamlarda her okulun DERS LİSTESİ de eklenir
function buildExportSheets(scope){
  const sheets=[];
  if(scope==="single"){
    const s=buildSingleSheet(); if(s) sheets.push(s);
  }else if(scope==="classes"){
    const sc=curSchool(); for(const cl of sc.classes) sheets.push(buildClassSheet(sc,cl));
  }else if(scope==="teachers"){
    for(const t of [...S.teachers]) sheets.push(buildTeacherSheet(t));
  }else if(scope==="rooms"){
    for(const r of [...(S.rooms||[])]) sheets.push(buildRoomSheet(r));
  }else if(scope==="classTeacher"){
    const sc=curSchool(); for(const cl of sc.classes) sheets.push(buildClassSheet(sc,cl));
    for(const t of [...S.teachers]) sheets.push(buildTeacherSheet(t));
  }else if(scope==="all"){
    for(const sc of S.schools){ if(!(sc.defs||[]).length) continue; for(const cl of sc.classes) sheets.push(buildClassSheet(sc,cl)); }
    // Öğretmenler: okul bazlı + birlikte programları
    for(const t of [...S.teachers]){
      for(const sc of schoolsWithDefs()) sheets.push(buildTeacherSchoolSheet(t,sc));
      sheets.push(buildTeacherSheet(t));
    }
    for(const r of [...(S.rooms||[])]) sheets.push(buildRoomSheet(r));
  }
  return sheets;
}
// Bir öğretmenin TEK OKUL çizelgesi (okul bazlı raporlar için)
function buildTeacherSchoolSheet(t, sc){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderGrid(tmp,"teacher",t,sc);
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  const subRows=[["Ders","Sınıf","Saat"]];
  let total=0;
  for(const d of sc.defs||[]){ if(!defTeachers(d).includes(t)) continue; const h=Math.max(1,Number(d.hours)||1); subRows.push([String(d.course),String(d.className),String(h)]); total+=h; }
  subRows.push(["TOPLAM","",String(total)]);
  return {title:`${t} — ${sc.name}`, tableHTML:html, rows, subRows};
}
// PDF: tüm çizelgeler gizli yazdırma alanına yerleştirilir, tarayıcı yazdırmasıyla çıktı alınır
function exportPdf(scope){
  const sheets=buildExportSheets(scope);
  if(!sheets.length){toast("Aktarılacak çizelge yok.","err");return;}
  const prev=document.title;
  const area=$("printArea");
  // Her çizelge + en sonda ilgili okulların ders listeleri
  let html=sheets.map(s=>{
    let h=`<div class="pa-sheet${s.wide?" pa-wide":""}"><div class="pa-title">${esc(s.title)}</div>${s.tableHTML}`;
    if(s.subRows&&s.subRows.length>1){
      h+=`<div class="pa-sub-title">Ders Listesi</div><table class="pa-list">${s.subRows.map((r,i)=>`<tr>${r.map(c=>`<${i===0?"th":"td"}>${esc(c)}</${i===0?"th":"td"}>`).join("")}</tr>`).join("")}</table>`;
    }
    return h+`</div>`;
  }).join("");
  area.innerHTML=html;
  document.body.classList.add("export-print");
  document.title=`${curSchool().name} — ${scopeLabel(scope)} — Planla!`;
  toast("Yazdırma penceresinde hedef olarak 'PDF olarak kaydet'i seçin.");
  setTimeout(()=>{ window.print(); document.body.classList.remove("export-print"); area.innerHTML=""; document.title=prev; },80);
}
// Dosyayı indir (anchor'u DOM'a ekleyerek — daha güvenilir)
function downloadBlob(content, filename, mime){
  const blob=new Blob([content],{type:mime||"application/octet-stream"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url; a.download=filename; a.style.display="none";
  document.body.appendChild(a);
  a.click();
  setTimeout(()=>{ document.body.removeChild(a); URL.revokeObjectURL(url); },1000);
}
// Excel: çizelgeleri Excel 2003 XML (çok sayfalı) biçiminde .xls olarak dışa aktarır — uyarısız açılır
function exportExcel(scope){
  const sheets=buildExportSheets(scope);
  if(!sheets.length){toast("Aktarılacak çizelge yok.","err");return;}
  const fname=`${curSchool().name.replace(/\s+/g,"_")}_${scopeLabel(scope).replace(/\s+/g,"_")}`;
  // Excel çalışma sayfası biçimlendirme: başlık + grid başlığı kalın, gün sütunu kalın,
  // ders hücreleri ders rengine göre pastel dolgu + kalın yazı, kenarlıklar, çizgili satırlar, satır kaydırma
  const EXCEL_PALETTE={c0:{fill:"FFF3E0",font:"E65100"},c1:{fill:"E3F2FD",font:"0D47A1"},c2:{fill:"E8F5E9",font:"1B5E20"},c3:{fill:"FCE4EC",font:"880E4F"},c4:{fill:"F3E5F5",font:"4A148C"},c5:{fill:"FFF8E1",font:"F57F17"},c6:{fill:"E0F7FA",font:"006064"},c7:{fill:"FBE9E7",font:"BF360C"},c8:{fill:"F1F8E9",font:"33691E"},c9:{fill:"EDE7F6",font:"311B92"}};
  const thinBorder={top:{style:"thin",color:{rgb:"9AA0A6"}},bottom:{style:"thin",color:{rgb:"9AA0A6"}},left:{style:"thin",color:{rgb:"9AA0A6"}},right:{style:"thin",color:{rgb:"9AA0A6"}}};
  function styleExcelSheet(ws, gridRows, colCount, metaRows){
    const enc=(r,c)=>XLSX.utils.encode_cell({r,c});
    if(ws[enc(0,0)]) ws[enc(0,0)].s={font:{bold:true,sz:14},alignment:{vertical:"center"}};
    for(let c=0;c<colCount;c++){
      const a=enc(1,c);
      if(ws[a]) ws[a].s={font:{bold:true},fill:{fgColor:{rgb:"DDDDDD"}},border:thinBorder,alignment:{vertical:"middle",horizontal:"center",wrapText:true}};
    }
    for(let r=0;r<gridRows;r++){
      const metaRow=metaRows[r+1]||[];
      const dayFill=(r%2===1)?{fgColor:{rgb:"F2F2F2"}}:undefined;
      for(let c=0;c<colCount;c++){
        const a=enc(r+2,c);
        if(!ws[a]) continue;
        const cls=(typeof metaRow[c]==="object"&&metaRow[c].cls)?metaRow[c].cls:"";
        const cm=cls.match(/\bc(\d)\b/);
        let s={alignment:{wrapText:true,vertical:"center",horizontal:"center"},border:thinBorder};
        if(c===0){ s.font={bold:true}; if(dayFill) s.fill=dayFill; }
        else if(cm){ const p=EXCEL_PALETTE["c"+cm[1]]||EXCEL_PALETTE.c0; s.fill={fgColor:{rgb:p.fill}}; s.font={bold:true,color:{rgb:p.font}}; }
        else if(dayFill){ s.fill=dayFill; }
        ws[a].s=s;
      }
    }
    ws["!cols"]=Array.from({length:colCount},(_,i)=>({wch:i===0?(colCount>20?8:14):(colCount>20?5:13)}));
    ws["!rows"]=Array.from({length:gridRows+2},(_,r)=>({hpt:r===0?22:r===1?20:30}));
    ws["!freeze"]={xSplit:1,ySplit:2};
  }
  // Birincil: SheetJS ile gerçek .xlsx
  if(typeof XLSX!=="undefined"){
    try{
      const wb=XLSX.utils.book_new();
      sheets.forEach((s,i)=>{
        const metaRows=s.rows||[];
        const gridRows=metaRows.map(r=>r.map(c=>(typeof c==="object"?c.v:String(c))));
        const colCount=Math.max(1,...gridRows.map(r=>r.length));
        const extraSub=s.subRows||[];
        const aoa=[[String(s.title||"")],...gridRows];
        let subStart=aoa.length;
        if(extraSub.length){ aoa.push([""]); subStart=aoa.length; for(const r of extraSub) aoa.push(r.map(x=>String(x))); }
        const ws=XLSX.utils.aoa_to_sheet(aoa);
        // Birleştirmeler: başlık + 10 dk blok hücreleri (colspan)
        const merges=[];
        if(colCount>1) merges.push({s:{r:0,c:0},e:{r:0,c:colCount-1}});
        for(let r=0;r<metaRows.length;r++){
          let c=0;
          for(const cell of metaRows[r]){
            // Devam hücreleri (span:0) birleşik bloğun parçasıdır; sütun sayacı yalnızca
            // başlangıç hücresinin span'i kadar ilerler. Aksi halde yanlış birleşmeler oluşur.
            const span=(typeof cell==="object"&&cell.span!==undefined)?cell.span:1;
            if(span>1) merges.push({s:{r:r+1,c},e:{r:r+1,c:c+span-1}});
            c+=span;
          }
        }
        if(merges.length) ws["!merges"]=merges;
        styleExcelSheet(ws,gridRows.length,colCount,metaRows);
        if(s.wide){ ws["!rows"]=Array.from({length:aoa.length},(_,r)=>({hpt:r===0?18:r===1?14:15})); }
        // Alt ders listesi stili (kenarlık + başlık/toplam kalın)
        if(extraSub.length){
          for(let r=subStart;r<aoa.length;r++){ for(let c=0;c<3;c++){ const a=XLSX.utils.encode_cell({r,c}); if(ws[a]) ws[a].s=Object.assign({},ws[a].s||{},{border:thinBorder,alignment:{vertical:"top",wrapText:true}}); } }
          for(let c=0;c<3;c++){
            const h=XLSX.utils.encode_cell({r:subStart,c}); if(ws[h]) ws[h].s=Object.assign({},ws[h].s||{},{font:{bold:true}});
            const t=XLSX.utils.encode_cell({r:aoa.length-1,c}); if(ws[t]) ws[t].s=Object.assign({},ws[t].s||{},{font:{bold:true}});
          }
        }
        const name=String(s.title||("Sayfa"+(i+1))).replace(/[\[\]:*?/\\]/g," ").trim().slice(0,31)||("Sayfa"+(i+1));
        XLSX.utils.book_append_sheet(wb,ws,name);
      });
      XLSX.writeFile(wb, fname+".xlsx", {cellStyles:true});
      toast(`${sheets.length} çizelge Excel (.xlsx) olarak indiriliyor.`);
      return;
    }catch(err){
      toast("Excel oluşturulurken hata: "+err.message,"err");
    }
  }
  // Yedek: Excel 2003 XML (.xml uzantısı — uyarısız açılır)
  const clean=n=>String(n||"").replace(/[\[\]:*?/\\]/g," ").trim().slice(0,31);
  const toXmlRow=r=>`<Row>${r.map(c=>`<Cell><Data ss:Type="String">${xmlEsc(typeof c==="object"?c.v:String(c))}</Data></Cell>`).join("")}</Row>`;
  const ws=sheets.map((s,i)=>{
    const name=xmlEsc(clean(s.title||("Sayfa"+(i+1))));
    const rows=(s.rows||[]).map(toXmlRow).join("");
    return `<Worksheet ss:Name="${name}"><Table>${rows}</Table></Worksheet>`;
  }).join("");
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">${ws}</Workbook>`;
  downloadBlob(xml, fname+".xml", "application/vnd.ms-excel");
  toast(`${sheets.length} çizelge Excel olarak indiriliyor.`);
}
// Açılır menü bağları
let exportFormat="pdf";
function toggleExportMenu(e){
  const m=$("exportMenu");
  if(m.classList.contains("hidden")){
    const r=e.currentTarget.getBoundingClientRect();
    m.style.minWidth="240px";
    m.style.visibility="hidden";
    m.style.display="flex";
    const mh=m.offsetHeight;
    m.style.visibility="";
    m.style.display="";
    const spaceBelow=window.innerHeight-r.bottom;
    if(spaceBelow<mh && r.top>mh+8){
      m.style.top=(r.top-mh-6)+"px";
    }else{
      m.style.top=Math.max(4,Math.min(r.bottom+4,window.innerHeight-mh-4))+"px";
    }
    m.style.left=Math.max(6,Math.min(r.left,window.innerWidth-246))+"px";
    m.classList.remove("hidden");
  }else m.classList.add("hidden");
}
$("pdfBtn").addEventListener("click",e=>{ exportFormat="pdf"; toggleExportMenu(e); });
$("excelBtn").addEventListener("click",e=>{ exportFormat="excel"; toggleExportMenu(e); });
$("exportMenu").addEventListener("click",e=>{
  const item=e.target.closest(".em-item");
  if(!item) return;
  $("exportMenu").classList.add("hidden");
  const scope=item.dataset.scope;
  if(exportFormat==="pdf") exportPdf(scope); else exportExcel(scope);
});
document.addEventListener("click",e=>{
  if(!e.target.closest("#exportMenu")&&!e.target.closest("#pdfBtn")&&!e.target.closest("#excelBtn")) $("exportMenu").classList.add("hidden");
});
$("scheduleStartBtn").addEventListener("click",()=>{
  if($("scheduleStartBtn").disabled) return;
  autoSolve();
});
$("scheduleQfApply").addEventListener("click",()=>{
  let changed=false;
  document.querySelectorAll("#scheduleQfList .qf-teacher").forEach(sel=>{
    const d=curSchool().defs.find(x=>x.id===sel.dataset.id);
    if(!d) return;
    if(sel.value&&sel.value!==d.teacher){ setTeachers(d,[sel.value,...defTeachers(d).slice(1)]); addTeacherCourse(sel.value,d.course); changed=true; }
  });
  document.querySelectorAll("#scheduleQfList .qf-hours").forEach(inp=>{
    const d=curSchool().defs.find(x=>x.id===inp.dataset.id);
    if(!d) return;
    const v=Math.max(1,Math.min(12,Number(inp.value)||1));
    if(v!==d.hours){ d.hours=v; changed=true; }
  });
  if(!changed){ toast("Değişiklik yapılmadı.","err"); return; }
  saveState(); renderDefs(); refresh(); showPrecheck();
});
$("scheduleQfList").addEventListener("click",e=>{
  const btn=e.target.closest(".qf-del");
  if(!btn) return;
  const d=curSchool().defs.find(x=>x.id===btn.dataset.id);
  if(!d) return;
  curSchool().defs=curSchool().defs.filter(x=>x.id!==d.id);
  curSchool().lessons=curSchool().lessons.filter(l=>refKey(l.course,lessonTeachers(l),lessonClasses(l))!==refKey(d.course,defTeachers(d),defClasses(d)));
  saveState(); renderDefs(); refresh(); showPrecheck();
  toast(`"${d.course} — ${d.className}" silindi.`);
});

function applyLiveBestToSchool(){
  if(!liveBest || !liveBest.state) return false;
  if(liveBest.isJoint){
    // Ortak dağıtım (joint): tüm okulların lessons'ını aynı state'ten yaz
    const map={}; for(const sc of S.schools) map[sc.id]=sc;
    for(const sc of S.schools) if((sc.defs||[]).length) sc.lessons=[];
    for(const p of Object.values(liveBest.state.placements)){
      const b=p.block; const sc=map[b.schoolId]; if(!sc) continue;
      for(let o=0;o<b.size;o++){
        const lesson={id:b.bid, course:b.course, className:b.className, day:p.day, period:p.start+o, hours:b.size, part:o+1, room:b.room||null};
        setTeachers(lesson, b.teachers||[b.teacher]);
        setClasses(lesson, blockClasses(b));
        sc.lessons.push(lesson);
      }
    }
    saveState(); renderDefs(); refresh();
    return true;
  }
  const school = curSchool();
  school.lessons = [];
  for(const p of Object.values(liveBest.state.placements)){
    const b=p.block;
    for(let o=0;o<b.size;o++){
      const lesson={id:b.bid, course:b.course, className:b.className, day:p.day, period:p.start+o, hours:b.size, part:o+1, room:b.room||null};
      setTeachers(lesson, b.teachers||[b.teacher]);
      setClasses(lesson, blockClasses(b));
      school.lessons.push(lesson);
    }
  }
  saveState(); renderDefs(); refresh();
  return true;
}
$("scheduleCloseBtn").addEventListener("click",()=>{
  try{ isciDurdur(); }catch(e){}
  if(_isSolving && liveBest){
    // Bitir: en iyi yerleşimi kaydet ve durdur (joint ise tüm okullar)
    applyLiveBestToSchool();
    toast(`Bitirildi — en iyi yerleşim kaydedildi: ${liveBest.placedHours}/${liveBest.totalHours} saat, ${liveBest.failed.length} blok yerleşmedi`,"ok");
    const lessonsAll = liveBest.isJoint ? S.schools.flatMap(sc=> (sc.lessons||[]).map(l=>({...l}))) : curSchool().lessons.map(l=>({...l}));
    const res = {totalBlocks:liveBest.totalBlocks, totalHours:liveBest.totalHours, placedBlocks:liveBest.placedBlocks, placedHours:liveBest.placedHours, forcedFailed:liveBest.forcedFailed, failed:liveBest.failed, allFailed:liveBest.allFailed, capacityIssues:[], validationWarnings:[], isJoint:!!liveBest.isJoint, lessons:lessonsAll};
    // raporu göster ama overlayi kapatma yerine sonuç ekranına geç
    showScheduleResult(res);
    _isSolving=false;
    solveCancelled=true;
    return;
  }
  solveCancelled=true;
  _isSolving=false;
  hideScheduleOverlay();
});
$("scheduleSaveBtn").addEventListener("click",()=>{
  if(_isSolving && liveBest){
    // Çalışma devam ederken maksimum yerleşimi kaydet — durdurmadan
    applyLiveBestToSchool();
    const ex = liveBest.allFailed.length - liveBest.forcedFailed.length;
    toast(`Maksimum yerleşim kaydedildi: ${liveBest.placedHours}/${liveBest.totalHours} saat yerleştirildi, ${ex} blok yerleşmedi — çalışma devam ediyor`,"ok");
    return;
  }
  downloadState();
});
$("scheduleOverlay").addEventListener("click",e=>{
  if(e.target===e.currentTarget) hideScheduleOverlay();
});

/* ============================================================
   MODAL — prompt() ve confirm() yerine
   ============================================================ */
let modalCb = null;

function hideModal(){
  $("modalOverlay").classList.remove("open");
  $("modalMsg").style.display="none";
  $("modalInput").style.display="none";
  $("modalTextarea").style.display="none";
  modalCb = null;
}

// extraHtml: onay kutusunda gösterilecek ek içerik (ör. uzun sürecek dağıtım öncesi
// performans modu seçimi). Boşsa yuva gizlenir.
function showConfirm(title, msg, cb, extraHtml){
  $("modalTitle").textContent = title;
  $("modalMsg").textContent = msg;
  $("modalMsg").style.display="";
  $("modalInput").style.display="none";
  $("modalTextarea").style.display="none";
  const ex=$("modalExtra");
  if(ex){ ex.innerHTML=extraHtml||""; ex.style.display=extraHtml?"":"none"; }
  $("modalOk").textContent = "Evet";
  modalCb = cb;
  $("modalOverlay").classList.add("open");
  $("modalOk").focus();
}

function showPrompt(title, placeholder, cb){
  $("modalTitle").textContent = title;
  $("modalMsg").style.display="none";
  $("modalInput").style.display="";
  $("modalTextarea").style.display="none";
  $("modalInput").value = "";
  $("modalInput").placeholder = placeholder || "";
  $("modalOk").textContent = "Tamam";
  modalCb = cb;
  $("modalOverlay").classList.add("open");
  setTimeout(()=>$("modalInput").focus(), 100);
}

function showBulkPrompt(title, placeholder, cb){
  $("modalTitle").textContent = title;
  $("modalMsg").style.display="none";
  $("modalInput").style.display="none";
  $("modalTextarea").style.display="";
  $("modalTextarea").value = "";
  $("modalTextarea").placeholder = placeholder || "";
  $("modalOk").textContent = "Ekle";
  modalCb = cb;
  $("modalOverlay").classList.add("open");
  setTimeout(()=>$("modalTextarea").focus(), 100);
}

$("modalCancel").addEventListener("click", hideModal);
$("modalOk").addEventListener("click", ()=>{
  const cb = modalCb;
  hideModal();
  if(cb) cb(true);
});
$("modalInput").addEventListener("keydown", e=>{
  if(e.key==="Enter") $("modalOk").click();
  if(e.key==="Escape") hideModal();
});
$("modalTextarea").addEventListener("keydown", e=>{
  if(e.key==="Escape") hideModal();
});
$("modalOverlay").addEventListener("click", e=>{
  if(e.target===e.currentTarget) hideModal();
});

// Toast
function toast(msg,type){
  const c=$("toasts");
  const t=document.createElement("div");
  t.className="toast"+(type==="ok"?" ok":type==="err"?" err":"");
  t.textContent=msg;
  c.appendChild(t);
  setTimeout(()=>{t.style.opacity="0";t.style.transform="translateY(8px)";t.style.transition=".3s"},2500);
  setTimeout(()=>t.remove(),3000);
}

/* ============================================================
   BAŞLAT
   ============================================================ */
refresh();
if(loadWarning) setTimeout(()=>toast(loadWarning,"err"),800);

// İkon fontu hazır olunca göster; 2.5 sn'de gelmezse ikonları gizle (çevrimdışı/bozuk font).
(function(){
  const ok=()=>document.body.classList.add("icons-ready");
  try{
    if(document.fonts&&document.fonts.ready){
      document.fonts.ready.then(()=>{ if(document.fonts.check('24px "Material Symbols Outlined"')) ok(); });
    } else ok();
  }catch(e){ ok(); }
  setTimeout(()=>{ if(!document.body.classList.contains("icons-ready")) document.body.classList.add("icons-noglyph"); },2500);
})();
