# Planla! Kullanım Kılavuzu

Planla!, okul ders programlarını otomatik hazırlayan ücretsiz bir uygulamadır.
Kurulum gerektirmez: `index.html` dosyasına çift tıklayın, tarayıcınızda açılır.

Verileriniz **otomatik olarak tarayıcınızın hafızasında saklanır**. Sayfayı kapatsanız
da açsanız da verileriniz durur (aynı tarayıcıyı kullanmanız yeterli). Bilgisayar
değiştirirseniz "Kaydet" ile JSON dosyası indirip yeni bilgisayarda "Aç" ile geri yükleyin.

Başlangıçta hazır örnek veri ile denemek için soldaki **"Örnek"** butonuna basın.

---

## 1. Okul Ayarları

Sol menüden **Okul** sekmesine girin.

### Günler ve saat sayısı
- **Günler**: virgülle ayrılmış gün adları (örn. `Pazartesi,Salı,Çarşamba,Perşembe,Cuma`)
- **Günlük ders saati**: bir günde kaç ders saati olacağı (1–16)
- **Uygula** butonuna basın.

### Ders saatlerini otomatik doldurma
- **Başlangıç Saati**, **Ders Süresi (dk)** ve **Teneffüs Süresi (dk)** girin.
- **Otomatik Doldur** butonuna basın: tüm ders saatlerinin başlangıç/bitişi hesaplanır.
- İsterseniz **Ders Saatleri** tablosundan her saati elle de değiştirip
  **Saatleri Kaydet**'e basabilirsiniz.

### Okulda ders olmayacak saatler (kapalı saatler)
Alt taraftaki okul çizelgesinde bir hücreye tıklayın. Döngü şöyle işler:

1. **Açık saat** → tıklayınca **kapanır** (o saatte hiçbir sınıfa ders konmaz)
2. **Kapalı saat** → tıklayınca **öğle arası** olur (tüm günlerde uygulanan ayar)
3. **Öğle arası** → tıklayınca **açılır**

### Öğle arası
- Öğle arasını yukarıdaki döngüyle elle belirleyebilirsiniz.
- Eğer belirlemezseniz Planla! otomatik bulur: tüm günlerde kapalı olan ve
  **11:30–14:30** arasındaki saati öğle arası kabul eder.
- Öğle arası hücreleri çizelgede "ÖĞLE ARASI" olarak işaretlenir.
- **Kısıtlar** sekmesinden "her öğretmen her gün en az bir öğle arası saati boş kalsın"
  kuralını açabilirsiniz.

---

## 2. Dersler

Sol menüden **Dersler** → **Ders Ekleme** paneli:

- Ders adını yazıp **Ekle**'ye basın (örn. Matematik).
- Birden fazla dersi aynı anda eklemek için **Toplu Ekle**'ye basın ve her satıra bir ders
  adı yazın (örn. `Matematik` alt alta `Fizik`, `Kimya`), sonra **Toplu Ekle**'ye basın.
- Eklenen dersler listesinde `×` ile tek dersi kaldırabilirsiniz.

---

## 3. Öğretmenler

Sol menüden **Öğretmenler** sekmesine girin.

- **Ekle**: tek öğretmen; **Toplu**: her satıra bir ad (soyadıyla yazın).
- Soldaki listede öğretmeni **çift tıklayarak** adını değiştirebilirsiniz
  (tüm çizelge, tanımlar ve kapalı saatler otomatik güncellenir).
- **Sil**: önce listedeki onay kutularını işaretleyin, sonra **Sil**'e basın.
- Bir öğretmene tıklayınca çizelgesi açılır:
  - **Tıklayın**: o saati kapatır/açar (o öğretmen o saatte ders yapamaz).
  - **Sağ tıklayın**: boş bir saate elle ders ekler.
- Üstteki **ORTAOKUL / LİSE / Birlikte** sekmeleri: öğretmenin tek okuldaki veya tüm
  okullardaki (birleşik duvar saati) çizelgesini gösterir.
- **Çizelgeyi Doğrula** butonu tüm okulları kısıtlara göre kontrol eder (bkz. bölüm 12).

---

## 4. Öğretmen – Ders Eşleştirme

**Dersler** → **Öğretmen Ders Eşleştirme** paneli:

- Öğretmeni ve verebileceği dersi seçin (yazmaya başlayınca öneri çıkar), **Eşleştir**'e basın.
- Eşleşmeler altta listelenir; `×` ile kaldırabilirsiniz.
- Bu eşleşme ders tanımlarken işe yarar: bir ders seçtiğinizde öğretmen listesi yalnızca
  o dersi verebilen öğretmenleri gösterir. Eşleşme yoksa tüm öğretmenler gösterilir.

---

## 5. Sınıflar

Sol menüden **Sınıflar** sekmesine girin.

- **Ekle / Toplu / Sil**: öğretmenlerdeki gibi çalışır.
- Bir sınıfa tıklayınca çizelgesi açılır:
  - **Tıklayın**: o saati sınıf için kapatır/açar.
  - **Sağ tıklayın**: boş saate ders ekler.
- Liste öğesindeki sayaç `yerleşen ders / açık saat` gösterir
  (örn. `12/40` → 12 ders yerleşmiş, 40 açık saat var).

---

## 6. Derslikler

Sol menüden **Derslikler** sekmesine girin.

- **Ekle / Toplu / Sil**: diğerleri gibi. Derslikler tüm okulların ortak listesidir.
- Bir derslik seçince çizelgesi açılır; **Birlikte** sekmesi tüm okulların derslerini
  birleşik gösterir. Aynı derslik aynı saatte iki okulda çakışmaz.

---

## 7. Ders Tanımlama (en önemli bölüm)

**Dersler** → **Ders Tanımlama** paneli. Burada "hangi sınıfa, hangi dersi, hangi
öğretmen(ler), kaç saat" tanımlarsınız; dağıtım bu tanımlara göre yapılır.

### Form alanları
- **Dersler**: bir veya birkaç ders seçin (çoklu seçim — Ctrl+klik veya normal tıklama).
- **Öğretmen**: bu dersi verecek öğretmen(ler)i seçin. Birden fazla seçerseniz her
  öğretmen için ayrı bir ders tanımı oluşturulur.
- **Ek Öğretmenler (istediğin kadar)**: derse birlikte giren diğer öğretmenler.
  Onay kutusuna tıklayarak istediğiniz kadar öğretmen ekleyebilirsiniz
  (örn. bir ders 3 öğretmenle işleniyorsa 1 öğretmen + 2 ek öğretmen).
- **Sınıf**: bir veya birkaç sınıf seçin (her sınıf için ayrı tanım oluşur).
- **Saat**: haftalık toplam ders saati.
- **Blok**: dersin kaç saatlik parçalar halinde işleneceği (2 = ikişer saatlik bloklar).
- **Derslik**: dersin işleneceği derslik (isteğe bağlı).
- **Tek blok (parçalanmasın)**: işaretlenirse tüm saatler tek parça yerleştirilir
  (örn. 6 saatlik ders bir gün 6 saat kesintisiz).

Seçimlerinizi yaparken alttaki **önizleme** hangi kayıtların oluşacağını gösterir.
Bitirince **Ders Ekle**'ye basın.

### Tanımlı Dersler tablosu
- Satırlarda okul, sınıf, ders, öğretmen(ler), saat ve durum (Bekliyor / kısmi / Tam) görünür.
- **Satıra tıklayın**: "Haftalık çizelge" penceresi açılır:
  - Çizelgede hücrelere tıklayarak **bu dersin gelmesini istemediğiniz saatleri** kapatabilirsiniz
    (● kapalı, · açık, X yerleşmiş ders).
  - Ders adı, öğretmen, ek öğretmenler, saat, blok, tek blok ve derslik alanlarını değiştirip
    **Kaydet**'e basın. **Tanımı Sil** ile tanımı ve yerleşmiş derslerini silin.
- **Satıra çift tıklayın**: aynı bilgiler ana formda düzenleme moduna yüklenir;
  üstteki sarı bandı görünce **Değişiklikleri Kaydet**'e basın. **Yeni Ders** ile düzenlemeden çıkın.
- **Seçilileri Sil**: tablodaki onay kutularını işaretleyin, üstteki düğmeye basın.

### Sınıflara Eklenen Dersler (4. panel)
Her sınıfın tanımlı derslerini ve yerleşme durumunu liste halinde gösterir;
bir derse tıklayıp ayarlarını açabilirsiniz.

---

## 8. Dağıtım Kısıtları

**Kısıtlar** sekmesinden kuralları açıp kapatabilirsiniz. Dağıtım sırasında tüm
dersler yerleşir; kurallar mümkün olduğunca korunur.

- **Aynı dersin parçaları aynı güne denk gelmesin**: ders günlere yayılır
  (örn. 4 saatlik matematik 2+2 olarak iki farklı güne).
- **Aynı öğretmenin farklı dersleri aynı güne denk gelmesin**: öğretmenin dersleri yayılır.
- **Bloklar arası saat farkı**: aynı dersin blokları aynı güne gelebilir ama aralarında
  en az belirttiğiniz saat farkı olsun (0 = kapalı).
- **Teneffüs süresi (dakika)**: bir öğretmenin ardışık dersleri arasında en az bu kadar
  dakika teneffüs olsun. Diğer okuldaki dersler de hesaba katılır (0 = kapalı).
- **Öğle arası**: her öğretmenin her gün en az bir öğle arası saati boş kalsın.
- **Ders çifti kısıtı**: iki ders aynı güne denk gelmesin. Örneğin Matematik ile Fizik'i
  seçip **Ekle**'ye basın; artık hiçbir günde ikisi birden olmaz.

---

## 9. Dağıtım

Tüm tanımlar hazır olunca sol alttaki **Dağıt** butonuna basın.

### Adım 1 — Ön Kontrol
- **Kırmızı uyarılar** veri hatalarını (örn. öğretmeni boş tanım) veya yerleştirilemeyecek
  dersleri gösterir (örn. sınıf kapasitesi aşılıyor, açık saat yok). Bunlar varken dağıtım başlamaz.
- **Hızlı Düzeltme** alanı: sorunlu derslerin öğretmenini değiştirebilir, saatini azaltabilir
  veya `×` ile silebilirsiniz. **Uygula ve Yeniden Kontrol Et** ile kontrolü yenileyin.
- Sorun yoksa **Dağıtımı Başlat**'a basın.

### Adım 2 — Dağıtım
Uygulama farklı blok ve saat kombinasyonlarını deneyerek (9 tura kadar) en iyi
yerleşimi arar. Sırada bekleyin.

### Adım 3 — Rapor
- **Yerleşen saat / blok** sayıları ve **eksik saat** özeti görünür.
- **İmkansız olduğu için ayrılan dersler** (kırmızı): bu şartlarda yerleştirilemeyenler —
  öğretmen/sınıf açık saatleri azalınca düzelebilir.
- **Yerleşmeyen ama denenebilecek dersler** (sarı): blok düzeni değişince veya
  "aynı ders aynı güne denk gelmesin" kuralı kapatılınca yerleşebilir.
- Dağıtım sonucu otomatik kaydedilir. İsterseniz **Maksimum Yerleşimi Kaydet** ile
  kısmi sonucu JSON dosyası olarak da indirebilirsiniz.
- **Kapat** ile çizelgeye dönün; sonucu Okul/Sınıf/Öğretmen/Derslik görünümlerinde inceleyin.

### Toplu işlemler
- **Tümünü Dağıt**: tüm okulları sırayla, öğretmen paylaşımlarını dikkate alarak dağıtır.
- **Dağıtımı Sil**: tüm okullardaki yerleşmiş dersleri temizler (tanımlar durur).

---

## 10. Manuel Düzenleme

Otomatik dağıtım sonrası elle düzenleme yapabilirsiniz:

- **Ders silme**: çizelgede dersin ilk hücresindeki `×` butonuna tıklayın.
- **Ders ekleme**: Sınıflar veya Öğretmenler görünümünde boş bir hücreye **sağ tıklayın**:
  ders adı, öğretmen/sınıf ve süre (blok) seçip **Ders Ekle**'ye basın.
  (Okul görünümünde ders eklenmez; okul görünümü yalnızca saat ayarları içindir.)
- Hücrenin üzerine gelince dersin sınıfı, öğretmeni ve dersliği ipucu olarak görünür.

---

## 11. Çizelgeyi Doğrula

Öğretmenler sekmesindeki **Çizelgeyi Doğrula** butonu tüm okulları kontrol eder ve
şu sorunları listeler:

- Tanımsız ders / öğretmen / sınıf (silinmiş ama çizelgede kalmış)
- Sınıf çakışması (bir sınıfta aynı saatte iki ders)
- Öğretmen çakışması (bir öğretmen aynı saatte iki yerde)
- Kapalı (okul/sınıf) saate ders konmuş
- Eksik/Fazla saat (tanım ile yerleşen sayı uyuşmuyor)
- "Tek blok" tanımı parçalanmış
- Derslik çakışması (aynı derslik aynı saatte iki okulda)
- Çapraz okul çakışması (öğretmen iki okulda aynı saatte)
- Teneffüs 10 dakikadan kısa, öğle arası yok

---

## 12. Durum Raporları

**Durum** sekmesinde doluluk ve dağılım tabloları vardır:

- **Okul**: tanım, eklenen/yerleşen saat, kapasite, doluluk %, sorun sayısı
- **Öğretmenler**: her öğretmenin eklenen/yerleşen saati ve doluluğu
- **Sınıf**: sınıf bazında aynı bilgiler
- **Derslik**: derslik doluluğu ve hangi okulda kullanıldığı

Doluluk % arttıkça renk yeşilden kırmızıya döner. Tabloların sütun başlıklarına
tıklayarak sıralama yapabilirsiniz.

---

## 13. Kaydet / Aç (JSON yedek)

- **Kaydet**: tüm verileri (okullar, öğretmenler, tanımlar, çizelgeler, ayarlar)
  bir `.json` dosyası olarak indirir. Yedek almak veya başka bilgisayara taşımak için kullanın.
- **Aç**: indirdiğiniz JSON dosyasını geri yükler.

Not: uygulama zaten her değişikliği tarayıcıya otomatik kaydeder; JSON dosyası taşıma
ve güvenlik yedeği içindir.

---

## 14. Yazdır / PDF ve Excel Çıktısı

Sağ alttaki **Yazdır / PDF** veya **Excel** butonuna basınca kapsam menüsü açılır:

- **Bu çizelge**: şu an açık olan görünüm (sınıf, öğretmen, derslik)
- **Tüm sınıflar (bu okul)**
- **Tüm öğretmenler**
- **Tüm derslikler**
- **Sınıflar + Öğretmenler**
- **Tüm okullar (sınıf + öğretmen + derslik)**

PDF için: yazdırma penceresinde hedef olarak **"PDF olarak kaydet"** seçin.
Excel çıktısı otomatik indirilir.

---

## 15. Birden Fazla Okul

Sol üstteki okul seçiciden okul değiştirebilir, **+** ile yeni okul ekleyebilirsiniz.
Her okulun kendi günleri, saatleri, sınıfları ve tanımları vardır.

**TÜMÜ** seçeneği: sınıf, öğretmen ve derslik listelerini tüm okullarınkiyle birleşik
gösterir (düzenleme son seçilen okulda yapılır). Öğretmenler ve derslikler zaten ortak
listelerdir — bir öğretmen iki okulda da ders verebilir; dağıtım çakışmayı engeller.

---

## 16. Koyu Mod ve Örnek Veri

- **Koyu** butonu: aydınlık/karanlık tema geçişi (tercihiniz hatırlanır).
- **Örnek** butonu: uygulamayı tanımak için örnek okul yükler (mevcut veriyi değiştirir).

---

## Sık Sorulanlar

**Verilerim nerede saklanıyor?**
Tarayıcınızın hafızasında (localStorage). Tarayıcı geçmişini silerken "site verileri"
temizlerseniz verileriniz gider — önemli verileriniz için zaman zaman **Kaydet** ile
JSON yedeği alın.

**Dağıtım "İmkansız ders" veriyor, ne yapayım?**
O dersin öğretmeni veya sınıfı için açık saat kalmamış demektir. Öğretmenin/sınıfın
kapalı saatlerini azaltın, ders saatini düşürün veya öğretmen değiştirin; sonra yeniden Dağıt'ın.

**"Eksik/Fazla saat" uyarısı çıkıyor?**
Tanımlanan saat ile yerleşen saat uyuşmuyor demektir. Yeniden dağıtın; yine olmuyorsa
ön kontroldeki kapasite sorunlarını giderin.

**Bir derse 3–4 öğretmen nasıl tanımlarım?**
Ders Tanımlama'da öğretmeni seçin, **Ek Öğretmenler** kutusundan diğerlerini işaretleyin.

**Öğle arası nasıl ayarlanır?**
Okul sekmesinde çizelgede ilgili saate iki kez tıklayın (kapat → öğle arası). Ya da hiç
karıştırmayın: 11:30–14:30 arası tüm günler kapalı bir saat varsa otomatik algılanır.