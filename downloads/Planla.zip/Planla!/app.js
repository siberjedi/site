/* ============================================================
   Planla! — Grid-tabanlı ders programı üretici
   Ücretsizdir: dilediğiniz gibi kullanabilir ve paylaşabilirsiniz.
   ============================================================ */

/* ─── STATE (çoklu okul) ─── */
const SCHOOL_DFLT = {
  name:"Okul",days:["Pazartesi","Salı","Çarşamba","Perşembe","Cuma"],
  periods:10,classes:[],courses:[],schoolClosed:{},classClosed:{},
  lessons:[],defs:[],periodTimes:[],selectedClass:null,schoolLunch:{},
  constraints:{spreadCourse:false,spreadTeacher:false,coursePairs:[],courseGap:0,minBreak:10,requireLunch:true}
};
// Kısıt nesnesini eksik alanlar sessizce kapanmasın diye doldurur
function normConstraints(c){
  return Object.assign({spreadCourse:false,spreadTeacher:false,coursePairs:[],courseGap:0,minBreak:10,requireLunch:true}, c||{});
}

let S = null;

function newSchool(id){ return {id,...JSON.parse(JSON.stringify(SCHOOL_DFLT))} }

function loadState(){
  try{
    const r=localStorage.getItem("dagitmatik2");
    if(!r) throw "no data";
    const d=JSON.parse(r);
    if(d.schools){
      if(typeof d.darkMode!=="boolean") d.darkMode=false;
      if(!Array.isArray(d.rooms)) d.rooms=[];
      if(typeof d.viewAll!=="boolean") d.viewAll=false;
      migrateTeachers(d);
      return d; // yeni format
    }
    // Migration: eski format
    const s=newSchool("s1");
    s.name="Okul"; s.days=d.days||SCHOOL_DFLT.days; s.periods=d.periods||10;
    s.classes=d.classes||[]; s.courses=d.courses||[];
    s.schoolClosed=d.schoolClosed||{}; s.classClosed=d.classClosed||{};
    s.periodTimes=d.periodTimes||[]; s.selectedClass=d.selectedClass||null;
    s.constraints=d.constraints||{spreadCourse:false,spreadTeacher:false,coursePairs:[]};
    if(d.defs) s.defs=d.defs;
    else if(d.lessons&&d.lessons.length){
      const seen={};
      for(const l of d.lessons){
        const key=`${l.course}|${l.teacher}|${l.className}`;
        if(!seen[key]) seen[key]={course:l.course,teacher:l.teacher,className:l.className,hours:l.hours||2,block:Math.min(l.hours||2,2)};
        else seen[key].hours=Math.max(seen[key].hours,l.hours||2);
      }
      s.defs=Object.values(seen).map(x=>({...x,id:uid()}));
    }
    if(!s.courses.length&&s.defs.length){
      const cs=new Set();
      for(const def of s.defs) cs.add(def.course);
      s.courses=[...cs].sort((a,b)=>a.localeCompare(b,"tr"));
    }
    const out={schools:[s],teachers:d.teachers||[],teacherClosed:d.teacherClosed||{},
      teacherCourses:d.teacherCourses||{},currentSchool:"s1",selectedTeacher:d.selectedTeacher||null,selectedRoom:d.selectedRoom||null,
      rooms:[],viewAll:false,
      darkMode:!!d.darkMode};
    migrateTeachers(out);
    return out;
  }catch{}
  const s=newSchool("s1");
  return {schools:[s],teachers:[],teacherClosed:{},teacherCourses:{},currentSchool:"s1",selectedTeacher:null,selectedRoom:null,rooms:[],darkMode:false};
}

// Eski kayıtlarda teacher/teacher2 alanlarını teachers dizisine dönüştürür
function migrateTeachers(state){
  for(const sc of state.schools||[]){
    for(const d of sc.defs||[]) if(!Array.isArray(d.teachers)) setTeachers(d, defTeachers(d));
    for(const l of sc.lessons||[]) if(!Array.isArray(l.teachers)) setTeachers(l, lessonTeachers(l));
  }
  return state;
}

function saveState(){
  localStorage.setItem("dagitmatik2",JSON.stringify({
    schools:S.schools,teachers:S.teachers,teacherClosed:S.teacherClosed,
    teacherCourses:S.teacherCourses,currentSchool:S.currentSchool,
    selectedTeacher:S.selectedTeacher,darkMode:!!S.darkMode,rooms:S.rooms,selectedRoom:S.selectedRoom||null,viewAll:!!S.viewAll
  }));
}

function curSchool(){ return S.schools.find(s=>s.id===S.currentSchool)||S.schools[0] }

S = loadState();

/* ─── UTILITIES ─── */
const $ = id => document.getElementById(id);
const uid = () => Math.random().toString(36).slice(2,10)+Date.now().toString(36);
const sk = (d,p) => `${d}|${p}`;
const tLabel=(t1,t2)=>t2?`${t1} + ${t2}`:(t1||"");
// ÇOKLU ÖĞRETMEN desteği: tanım/dersteki TÜM öğretmenler (geriye dönük teacher/teacher2)
function defTeachers(d){ return (d&&Array.isArray(d.teachers)&&d.teachers.length)?d.teachers:(d&&d.teacher?[d.teacher,...(d.teacher2?[d.teacher2]:[])].filter(Boolean):[]); }
function lessonTeachers(l){ return (l&&Array.isArray(l.teachers)&&l.teachers.length)?l.teachers:(l&&l.teacher?[l.teacher,...(l.teacher2?[l.teacher2]:[])].filter(Boolean):[]); }
function tLabelArr(ts){ return (ts||[]).filter(Boolean).join(" + "); }
function defLabel(d){ return tLabelArr(defTeachers(d)); }
function lessonLabel(l){ return tLabelArr(lessonTeachers(l)); }
// Öğretmen listesini teacher/teacher2 alanlarıyla senkron tutar
function setTeachers(obj, list){
  const arr=[...(list||[])].filter(Boolean);
  obj.teachers=[...new Set(arr)];
  obj.teacher=obj.teachers[0]||null;
  obj.teacher2=obj.teachers[1]||null;
  return obj;
}
// Tanım/derste aynı ders-sınıf eşleşmesini kıyaslamak için kararlı anahtar
function refKey(course,teachers,className){ return `${course}|${[...new Set(teachers)].sort().join("+")}|${className}`; }
// ÇOKLU ÖĞRETMEN: ek öğretmen seçimi checkbox listesi (Windows'ta çoklu seçim Ctrl'siz çalışsın)
function extraChecks(container){
  if(!container) return [];
  const boxes=container.querySelectorAll?container.querySelectorAll("input.xtra-chk:checked"):[];
  return [...boxes].map(cb=>cb.value).filter(Boolean);
}
function renderExtraChecks(container, selected){
  if(!container) return;
  const sel=new Set(selected||[]);
  container.innerHTML=S.teachers.length
    ? S.teachers.map(t=>`<label class="xtra-row"><input type="checkbox" class="xtra-chk" value="${esc(t)}"${sel.has(t)?" checked":""}><span>${esc(t)}</span></label>`).join("")
    : '<span style="font-size:11px;color:var(--text3)">Önce öğretmen ekleyin</span>';
}
const esc = s => {const d=document.createElement('div');d.textContent=s;return d.innerHTML};
const trSort = (a,b) => (a||'').localeCompare(b||'', 'tr');
const toMin = t => { const [h,m]=String(t).split(':').map(Number); return h*60+m; };

/* ─── SLOT DURUMU (okul bazlı) ─── */
function schoolOpenIn(school,d,p){ return !((school.schoolClosed||{})[sk(d,p)]) }
function classOpenIn(school,cl,d,p){
  return schoolOpenIn(school,d,p) && !(school.classClosed&&school.classClosed[cl] && school.classClosed[cl][sk(d,p)])
}
function teacherOpenIn(school,t,d,p){
  if(!schoolOpenIn(school,d,p)) return false;
  if(S.teacherClosed[t] && S.teacherClosed[t][school.id] && S.teacherClosed[t][school.id][sk(d,p)]) return false;
  // Diğer okullarda duvar saati olarak çakışan dersi var mı?
  const ptC=school.periodTimes&&school.periodTimes[p-1];
  if(!ptC) return true;
  const cS=toMin(ptC.start), cE=toMin(ptC.end);
  for(const sc of S.schools){
    if(sc.id===school.id) continue;
    for(const l of sc.lessons){
      if(l.day!==d||!lessonTeachers(l).includes(t)) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const oS=toMin(pt.start), oE=toMin(pt.end);
      if(cS<oE&&oS<cE) return false; // duvar saati çakışması
    }
  }
  return true;
}
function schoolOpen(d,p){ return schoolOpenIn(curSchool(),d,p) }
function classOpen(cl,d,p){ return classOpenIn(curSchool(),cl,d,p) }
function teacherOpen(t,d,p){ return teacherOpenIn(curSchool(),t,d,p) }

// Öğle arası: kullanıcı schoolLunch (gün|saat) ile belirler; belirtilmediyse okulun
// TÜM günlerde kapalı ve öğlen bandında olan saati otomatik bulunur (geriye dönük).
function schoolHasLunch(sc){ return !!sc.schoolLunch && Object.keys(sc.schoolLunch).some(k=>sc.schoolLunch[k]); }
function schoolAutoLunchPeriod(sc){
  const closed=sc.schoolClosed||{};
  const allDay={};
  for(const k of Object.keys(closed)){ const [day,p]=k.split('|'); allDay[p]=(allDay[p]||0)+1; }
  for(const [p,cnt] of Object.entries(allDay)){
    if(cnt!==(sc.days||[]).length) continue;
    const pt=sc.periodTimes&&sc.periodTimes[p-1];
    if(!pt) continue;
    const s=toMin(pt.start), e=toMin(pt.end);
    if(s<toMin("11:30")||e>toMin("14:30")) continue;
    return Number(p);
  }
  return null;
}
// Belirli bir gün için okulun öğle arası ders saati (kullanıcı ayarı öncelikli)
function schoolLunchDayPeriod(sc, day){
  if(!sc.schoolLunch) return null;
  const prefix=day+"|";
  for(const k of Object.keys(sc.schoolLunch)){
    if(sc.schoolLunch[k] && k.indexOf(prefix)===0) return Number(k.slice(prefix.length));
  }
  return null;
}
// Belirli bir gün için öğle arası pencereleri (tüm okullar). Gün için kullanıcı ayarı yoksa
// okulun otomatik (tüm günler kapalı) öğle arasına düşer.
function lunchWindowsForDay(day){
  const out=[];
  for(const sc of S.schools){
    if(!(sc.defs||[]).length) continue;
    let lp=schoolLunchDayPeriod(sc, day);
    if(lp==null) lp=schoolAutoLunchPeriod(sc);
    if(lp==null) continue;
    const pt=sc.periodTimes&&sc.periodTimes[lp-1];
    if(!pt) continue;
    out.push({start:toMin(pt.start),end:toMin(pt.end),school:sc.name});
  }
  return out;
}
// Okul görünümü hücre döngüsü: aç → kapat → öğle arası → aç (gün bazlı)
function cycleSchoolCell(d,p){
  const sc=curSchool();
  const k=sk(d,p);
  const closed=sc.schoolClosed||(sc.schoolClosed={});
  const lunch=sc.schoolLunch||(sc.schoolLunch={});
  if(closed[k] && lunch[k]){
    // öğle arası → aç
    delete lunch[k];
    delete closed[k];
    toast(`${d} ${p}. saat açıldı (öğle arası kaldırıldı).`);
  }else if(closed[k]){
    // kapalı → öğle arası
    lunch[k]=true;
    toast(`${d} ${p}. saat öğle arası olarak işaretlendi.`);
  }else{
    // aç → kapat
    closed[k]=true;
    toast(`${d} ${p}. saat kapatıldı.`);
  }
  saveState();
}
function teacherGlobalLesson(t,d,p){
  for(const school of S.schools){
    const l=school.lessons.find(l=>l.day===d&&l.period===p&&lessonTeachers(l).includes(t));
    if(l) return {lesson:l, schoolId:school.id, schoolName:school.name};
  }
  return null;
}

function toggleSchool(d,p){
  const k=sk(d,p);
  if(curSchool().schoolClosed[k]) delete curSchool().schoolClosed[k];
  else curSchool().schoolClosed[k]=true;
  saveState();
}
function toggleClass(cl,d,p){
  const k=sk(d,p);
  if(!curSchool().classClosed[cl]) curSchool().classClosed[cl]={};
  if(curSchool().classClosed[cl][k]) delete curSchool().classClosed[cl][k];
  else curSchool().classClosed[cl][k]=true;
  saveState();
}
function toggleTeacher(t,d,p){
  if(!S.teacherClosed[t]) S.teacherClosed[t]={};
  if(!S.teacherClosed[t][S.currentSchool]) S.teacherClosed[t][S.currentSchool]={};
  const k=sk(d,p);
  if(S.teacherClosed[t][S.currentSchool][k]) delete S.teacherClosed[t][S.currentSchool][k];
  else S.teacherClosed[t][S.currentSchool][k]=true;
  saveState();
}

function lessonAt(d,p){
  return curSchool().lessons.find(l => l.day===d && l.period===p);
}

function classLessonAt(className,d,p,school=curSchool()){
  return school.lessons.find(l => l.className===className && l.day===d && l.period===p);
}

function teacherLessonAt(teacher,d,p,school=curSchool()){
  return school.lessons.find(l => l.day===d && l.period===p && lessonTeachers(l).includes(teacher));
}

function courseColor(c){
  let h=0;
  for(let i=0;i<c.length;i++) h=((h<<5)-h)+c.charCodeAt(i);
  return `c${Math.abs(h)%10}`;
}

/* ─── DERS EKLE/SİL ─── */
function addLesson(course, teacher, className, day, period, hours){
  hours=hours||1;
  for(let o=0;o<hours;o++){
    const pp=period+o;
    if(pp>curSchool().periods) return false;
    if(!classOpen(className,day,pp)||!teacherOpen(teacher,day,pp)) return false;
    if(classLessonAt(className,day,pp)||teacherLessonAt(teacher,day,pp)) return false;
  }
  const id=uid();
  const totalHours=hours;
  for(let o=0;o<hours;o++){
    curSchool().lessons.push({id,course,teacher,className,day,period:period+o,hours:totalHours,part:o+1});
  }
  if(!S.teachers.includes(teacher)) S.teachers.push(teacher);
  if(!curSchool().classes.includes(className)) curSchool().classes.push(className);
  saveState();
  return true;
}

function removeLesson(id){
  curSchool().lessons = curSchool().lessons.filter(l=>l.id!==id);
  saveState();
  refresh();
}

function clearLessons(){
  curSchool().lessons=[];
  saveState();
  refresh();
}

/* ============================================================
   GRID RENDERER
   ============================================================ */
function renderGrid(container, mode, entity, schoolOverride){
  const school=schoolOverride||curSchool();
  container.innerHTML="";
  if(!school.days.length||!school.periods){ container.innerHTML='<div class="empty">Önce okul saatlerini tanımlayın.</div>'; return; }
  const autoLunchP=schoolAutoLunchPeriod(school);

  // Tüm dersleri bir kere tara, (day,period) → ders haritası oluştur
  const lessonMap={};
  for(const l of school.lessons){
    if(mode==="school") continue; // okul görünümü ders göstermez
    if(mode==="class"&&l.className!==entity) continue;
    if(mode==="teacher"&&!lessonTeachers(l).includes(entity)) continue;
    const key=sk(l.day,l.period);
    if(!lessonMap[key]) lessonMap[key]=l; // ilk eklenen kalsın (çakışma olmamalı)
  }

  const wrap=document.createElement("div");
  wrap.style.overflow="auto";
  const tbl=document.createElement("table");

  const hdr=document.createElement("tr");
  const fc=document.createElement("th");
  fc.style.cssText="position:sticky;left:0;z-index:3";
  hdr.appendChild(fc);
  for(let p=1;p<=school.periods;p++){
    const th=document.createElement("th");
    const t=school.periodTimes&&school.periodTimes[p-1];
    th.innerHTML=t&&t.start?`${p}<br><span style="font-weight:400;font-size:10px;opacity:.7">${t.start}-${t.end}</span>`:String(p);
    if(p===school.periods) th.style.borderRight="1px solid #2a2d33";
    hdr.appendChild(th);
  }
  tbl.appendChild(hdr);

  for(const day of school.days){
    const dayLunchP = schoolLunchDayPeriod(school, day) ?? autoLunchP;
    const tr=document.createElement("tr");
    const dc=document.createElement("td");
    dc.className="day-cell";
    dc.textContent=day;
    tr.appendChild(dc);

    for(let p=1;p<=school.periods;p++){
      const td=document.createElement("td");
      td.className="grid-cell";
      td.dataset.day=day;
      td.dataset.period=p;

      const lesson=lessonMap[sk(day,p)]||null;
      const prevLesson=lessonMap[sk(day,p-1)]||null;
      const isBlockStart=lesson&&(!prevLesson||prevLesson.id!==lesson.id);

      if(lesson){
        td.classList.add("lesson",courseColor(lesson.course));
        td.title=`${lesson.course}\nSınıf: ${lesson.className}\nÖğretmen: ${lessonLabel(lesson)}${lesson.room?`\nDerslik: ${lesson.room}`:""}`;

        // Her hücreye etiketi yaz
        if(mode==="class"){
          td.innerHTML=`${esc(lesson.course)}<br><span class="more">${esc(lessonLabel(lesson))}</span>`;
        }else{
          td.appendChild(document.createTextNode(esc(lesson.className)));
        }
        if(isBlockStart){
          const del=document.createElement("button");
          del.className="del-lesson";del.textContent="×";
          del.dataset.lessonId=lesson.id;
          del.addEventListener("click",e=>{e.stopPropagation();removeLesson(lesson.id);});
          td.appendChild(del);
        }
      }else if(mode==="teacher"){
        // Bu okulun period'u ile duvar saati çakışan diğer okul dersleri
        const pt=school.periodTimes&&school.periodTimes[p-1];
        let other=null;
        if(pt){
          const cS=toMin(pt.start), cE=toMin(pt.end);
          for(const sc of S.schools){
            if(sc.id===school.id) continue;
            const l=sc.lessons.find(l=>l.day===day&&lessonTeachers(l).includes(entity)&&(sc.periodTimes&&sc.periodTimes[l.period-1])&&(function(){const o=sc.periodTimes[l.period-1];const oS=toMin(o.start),oE=toMin(o.end);return cS<oE&&oS<cE})());
            if(l){other={lesson:l,schoolName:sc.name};break;}
          }
        }
        if(other){
          td.classList.add("lesson","other-school");
          td.title=`${other.schoolName} → ${other.lesson.course}\n${other.lesson.className}`;
          if(!lessonMap[sk(day,p-1)]) td.appendChild(document.createTextNode("["+esc(other.schoolName.slice(0,3))+"]"));
        }else{
          td.classList.add(teacherOpenIn(school,entity,day,p)?"open":"closed");
          td.title=teacherOpenIn(school,entity,day,p)?"Tıkla: kapat  |  Sağ tık: ders ekle":"Tıkla: aç";
        }
      }else if(mode==="class"){
        td.classList.add(classOpenIn(school,entity,day,p)?"open":"closed");
        td.title=classOpenIn(school,entity,day,p)?"Tıkla: kapat  |  Sağ tık: ders ekle":"Tıkla: aç";
      }else{ // school
        td.classList.add(schoolOpenIn(school,day,p)?"open":"closed");
        td.title=schoolOpenIn(school,day,p)?"Tıkla: kapat":"Tıkla: öğle arası yap  |  tekrar tıkla: aç";
      }
      if(dayLunchP && p===dayLunchP){
        td.classList.add("lunch");
        if(!td.textContent) td.textContent="ÖĞLE ARASI";
        td.title=(td.title?td.title+"\n":"")+"Öğle arası (yemek molası) — tıkla: aç";
      }
      tr.appendChild(td);
    }
    tbl.appendChild(tr);
  }
  wrap.appendChild(tbl);
  container.appendChild(wrap);
}

// Öğretmenin TÜM okullardaki derslerini tek bir duvar saati zaman çizelgesinde gösterir
function renderTeacherCombined(container, entity, kind, schoolFilter){
  container.innerHTML="";
  kind=kind||"teacher";
  // Gün aralığı: ders tanımlı okulların periodTimes'ından min başlangıç / max bitiş (10 dk'ya yuvarla)
  let dayStart=Infinity, dayEnd=-Infinity;
  for(const sc of S.schools){
    if(!(sc.defs||[]).length) continue;
    if(schoolFilter&&sc.name!==schoolFilter) continue;
    for(const pt of (sc.periodTimes||[])){
      dayStart=Math.min(dayStart, toMin(pt.start));
      dayEnd=Math.max(dayEnd, toMin(pt.end));
    }
  }
  if(!isFinite(dayStart)){ container.innerHTML='<div class="empty">Okul saatleri tanımlı değil.</div>'; return; }
  dayStart=Math.floor(dayStart/10)*10;
  dayEnd=Math.ceil(dayEnd/10)*10;
  const STEP=10, cols=Math.max(1,Math.round((dayEnd-dayStart)/STEP));
  const ft=m=>String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0");
  const days=curSchool().days;
  const byDay={};
  for(const sc of S.schools){
    if(schoolFilter&&sc.name!==schoolFilter) continue;
    for(const l of sc.lessons||[]){
      const want=kind==="room"?l.room:(lessonTeachers(l).includes(entity)?entity:null);
      if(!want||want!==entity) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      (byDay[l.day]=byDay[l.day]||[]).push({course:l.course,className:l.className,school:sc.name,teachers:lessonTeachers(l),teacher:l.teacher,teacher2:l.teacher2,s:toMin(pt.start),e:toMin(pt.end)});
    }
  }
  const colIdx=t=>Math.max(0,Math.min(cols-1,Math.floor((t-dayStart)/STEP)));

  const wrap=document.createElement("div"); wrap.style.overflow="auto";
  const legend=document.createElement("div");
  legend.style.cssText="font-size:11px;color:var(--text2);margin-bottom:6px;";
  legend.innerHTML='<span style="background:var(--badge-ok);color:var(--badge-okt);padding:0 6px;border-radius:4px;margin-right:6px">[O] ORTAOKUL</span><span style="background:var(--badge-err);color:var(--badge-errt);padding:0 6px;border-radius:4px;margin-right:6px">[L] LİSE</span><span style="background:var(--badge-warn);color:var(--badge-warnt);padding:0 6px;border-radius:4px">sarı = öğle arası</span><span style="color:var(--text3);margin-left:6px">(üst skala 10 dk/dilim)</span>';
  wrap.appendChild(legend);
  const tbl=document.createElement("table"); tbl.style.borderCollapse="collapse";
  const htr=document.createElement("tr");
  const fc=document.createElement("th");
  fc.textContent="Gün"; fc.style.cssText="position:sticky;left:0;z-index:3;background:var(--bg);color:var(--text);padding:4px 8px;border:1px solid var(--border);font-weight:600;";
  htr.appendChild(fc);
  for(let i=0;i<cols;i++){
    const th=document.createElement("th");
    th.textContent=ft(dayStart+i*STEP);
    th.title=`${ft(dayStart+i*STEP)}-${ft(dayStart+(i+1)*STEP)}`;
    const leftBold=(i%3===0)?'border-left:2px solid var(--surface-tint);':'';
    th.style.cssText=`font-size:7px;padding:2px 0;background:var(--text);color:var(--surface);border:1px solid var(--border);min-width:22px;height:26px;font-weight:500;${leftBold}`;
    htr.appendChild(th);
  }
  tbl.appendChild(htr);

  const dayShort=d=>d.slice(0,3); // Pazartesi→Paz, Salı→Sal, Çarşamba→Çar, Perşembe→Per, Cuma→Cum
  for(const day of days){
    const lessons=(byDay[day]||[]).sort((a,b)=>a.s-b.s);
    const tr=document.createElement("tr");
    const dc=document.createElement("td"); dc.className="day-cell"; dc.textContent=dayShort(day); dc.title=day; tr.appendChild(dc);
    const cells=new Array(cols).fill(0);
    for(const l of lessons){
      const c1=colIdx(l.s), c2=colIdx(Math.max(l.e-1,l.s));
      for(let i=c1;i<=c2;i++) cells[i]={lesson:l};
    }
    for(const lw of lunchWindowsForDay(day)){
      const c1=colIdx(lw.start), c2=colIdx(Math.max(lw.end-1,lw.start));
      for(let i=c1;i<=c2;i++){ if(cells[i]===0) cells[i]={lunch:true, school:lw.school}; }
    }
    // Teneffüs: her dersin ARDINDAN gelen standart ara (o okulun bir sonraki ders saati başlangıcına kadar;
    // arkada ders olmasa bile işaretlenir). Öğle arası ve gün sonu hariç.
    for(const l of lessons){
      const sc=S.schools.find(x=>x.name===l.school);
      const times=(sc&&sc.periodTimes)||[];
      const pIdx=times.findIndex(pt=>toMin(pt.end)===l.e);
      if(pIdx>=0 && pIdx+1<times.length){
        const nextStart=toMin(times[pIdx+1].start);
        if(nextStart>l.e && nextStart-l.e<=40){
          const c1=colIdx(l.e), c2=colIdx(Math.max(nextStart-1,l.e));
          for(let i=c1;i<=c2;i++){ if(cells[i]===0) cells[i]={tenef:true}; }
        }
      }
    }
    let i=0;
    while(i<cols){
      const c=cells[i];
      let j=i+1;
      if(c&&c.lunch){ while(j<cols&&cells[j]&&cells[j].lunch&&cells[j].school===c.school) j++; }
      else if(c&&c.lesson){ while(j<cols&&cells[j]&&cells[j].lesson===c.lesson) j++; }
      else if(c&&c.tenef){ while(j<cols&&cells[j]&&cells[j].tenef) j++; }
      else{ while(j<cols&&cells[j]===0) j++; }
      const td=document.createElement("td");
      td.colSpan=j-i;
      if(c===0){ td.className="grid-cell open"; td.style.minWidth="22px"; }
      else if(c&&c.tenef){
        td.className="grid-cell tenef";
        td.textContent="ARA";
        td.title="Teneffüs";
        td.style.minWidth=(j-i)*22+"px";
      }
      else if(c&&c.lunch){
        td.className="grid-cell lunch";
        td.textContent=`ÖĞLE ${c.school==="LİSE"?"L":"O"}`;
        td.title=`${c.school} öğle arası`;
        td.style.minWidth=(j-i)*22+"px";
      }
      else if(c&&c.lesson){
        const l=c.lesson;
        td.className="grid-cell lesson "+courseColor(l.course);
        const sbadge=l.school==="LİSE"?"L":"O";
        td.innerHTML=`<div style="font-weight:700;line-height:1.2">[${sbadge}] ${esc(l.className)}</div><div style="font-size:8px;opacity:.85">${kind==="room"?esc(l.course):ft(l.s)+"-"+ft(l.e)}</div>`;
        td.title=`${l.school} ${l.className} ${l.course}${kind==="room"?` Öğr: ${tLabelArr(l.teachers||[l.teacher])}`:""}  ${ft(l.s)}-${ft(l.e)}`;
        td.style.minWidth=(j-i)*22+"px";
      }
      tr.appendChild(td);
      i=j;
    }
    tbl.appendChild(tr);
  }
  wrap.appendChild(tbl);
  container.appendChild(wrap);
}

// Tüm okulların mevcut çizelgesini kısıt ve tutarlılık açısından doğrular.
// Öğretmenlerin hatasız program yapabilmesi için dağıtım sonrası ve dosya açılışında kullanılır.
function verifySchedule(){
  const issues=[];
  const schools=S.schools.filter(s=>(s.defs||[]).length);
  const teacherSet=new Set(S.teachers||[]);
  for(const sc of schools){
    const cSet=new Set(sc.courses), clSet=new Set(sc.classes);
    const classBusy={}, teacherBusy={};
    const defHours={};
    for(const def of sc.defs||[]) defHours[refKey(def.course,defTeachers(def),def.className)]=(defHours[refKey(def.course,defTeachers(def),def.className)]||0)+Math.max(1,Number(def.hours)||1);
    const placed={};
    for(const l of sc.lessons||[]){
      const key=refKey(l.course,lessonTeachers(l),l.className);
      placed[key]=(placed[key]||0)+1;
      if(!cSet.has(l.course)) issues.push(`Tanımsız ders: ${sc.name} ${l.className} ${l.course}`);
      for(const t of lessonTeachers(l)) if(!teacherSet.has(t)) issues.push(`Tanımsız öğretmen: ${sc.name} ${l.className} ${t}`);
      if(!clSet.has(l.className)) issues.push(`Tanımsız sınıf: ${sc.name} ${l.course} ${l.className}`);
      const ck=`${l.className}|${l.day}|${l.period}`;
      if(classBusy[ck]) issues.push(`Sınıf çakışması: ${sc.name} ${l.day} ${l.period}.s ${l.className} (${l.course})`);
      else classBusy[ck]=1;
      for(const t of lessonTeachers(l)){
        const tk=`${t}|${l.day}|${l.period}`;
        if(teacherBusy[tk]) issues.push(`Öğretmen çakışması: ${sc.name} ${l.day} ${l.period}.s ${t} (${l.course})`);
        else teacherBusy[tk]=1;
      }
      if((sc.schoolClosed||{})[`${l.day}|${l.period}`]) issues.push(`Kapalı (okul) saate ders: ${sc.name} ${l.className} ${l.course} ${l.day} ${l.period}.s`);
      if(sc.classClosed&&sc.classClosed[l.className]&&sc.classClosed[l.className][`${l.day}|${l.period}`]) issues.push(`Kapalı (sınıf) saate ders: ${sc.name} ${l.className} ${l.course} ${l.day} ${l.period}.s`);
    }
    for(const [k,h] of Object.entries(defHours)){
      const p=placed[k]||0;
      if(p!==h) issues.push(`Eksik/Fazla saat: ${sc.name} ${k} → çizelgede ${p}, tanım ${h}`);
    }
    for(const def of sc.defs||[]){
      if(!def.blockFixed) continue;
      const ls=sc.lessons.filter(l=>refKey(l.course,lessonTeachers(l),l.className)===refKey(def.course,defTeachers(def),def.className));
      if(ls.length>1){
        const byDay={};
        for(const l of ls)(byDay[l.day]=byDay[l.day]||[]).push(l.period);
        for(const [day,pers] of Object.entries(byDay)){
          pers.sort((a,b)=>a-b);
          for(let i=1;i<pers.length;i++) if(pers[i]!==pers[i-1]+1){ issues.push(`Tek blok değil: ${sc.name} ${def.className} ${def.course} ${day} [${pers.join(',')}]`); break; }
        }
      }
    }
  }
  const dayMap=new Map();
  // Derslik çakışması: aynı derslik aynı saat aralığında yalnız bir derste kullanılabilir (tüm okullar).
  // Okulların ders saatleri farklı olabileceğinden saat aralığı örtüşmesine göre kontrol edilir.
  const roomIntervals={};
  for(const sc of schools){
    for(const l of sc.lessons||[]){
      if(!l.room) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const k=`${l.room}|${l.day}`;
      (roomIntervals[k]=roomIntervals[k]||[]).push({start:toMin(pt.start),end:toMin(pt.end),label:`${sc.name} ${l.className} ${l.course}`});
    }
  }
  for(const [k,ints] of Object.entries(roomIntervals)){
    const [room,day]=k.split('|');
    for(let i=0;i<ints.length;i++) for(let j=i+1;j<ints.length;j++){
      if(ints[i].start<ints[j].end&&ints[j].start<ints[i].end){
        issues.push(`Derslik çakışması: ${room} ${day} (${ints[i].label} ↔ ${ints[j].label})`);
      }
    }
  }
  for(const sc of schools){
    for(const l of sc.lessons||[]){
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const iv={start:toMin(pt.start),end:toMin(pt.end),school:sc.name,course:l.course,className:l.className};
      for(const t of lessonTeachers(l)){
        const k=`${t}|${l.day}`;
        if(!dayMap.has(k)) dayMap.set(k,[]);
        dayMap.get(k).push(iv);
      }
    }
  }
  for(const [key,ints] of dayMap){
    const [teacher,day]=key.split('|');
    ints.sort((a,b)=>a.start-b.start);
    for(let i=0;i<ints.length;i++) for(let j=i+1;j<ints.length;j++){
      if(ints[i].start<ints[j].end&&ints[j].start<ints[i].end) issues.push(`Çapraz çakışma: ${teacher} ${day} (${ints[i].school} ${ints[i].course} ↔ ${ints[j].school} ${ints[j].course})`);
    }
    for(let i=1;i<ints.length;i++){
      if(ints[i-1].school===ints[i].school) continue;
      const gap=ints[i].start-ints[i-1].end;
      if(gap<10) issues.push(`Teneffüs<10dk: ${teacher} ${day} ${ints[i-1].school} ${ints[i-1].course} → ${ints[i].school} ${ints[i].course}`);
    }
    const lunchWin=lunchWindowsForDay(day);
    if(lunchWin.length){
      const hasLunch=ints=>lunchWin.some(lw=>!ints.some(iv=>iv.start<lw.end&&lw.start<iv.end));
      if(!hasLunch(ints)) issues.push(`Öğle arası yok: ${teacher} ${day}`);
    }
  }
  return issues;
}

/* ============================================================
   ÇÖZÜCÜ (kısıt-tabanlı çoklu deneme)
   ============================================================ */
async function solve(opts={}){
  if(!curSchool().defs.length){toast("Hiç ders tanımlanmamış. Önce Dersler sekmesinden ders ekleyin.","err");return null;}

  const school=curSchool();
  const days=school.days;
  const periods=school.periods;
  const validation=validateScheduleData(school);
  if(validation.errors.length){
    const result={totalBlocks:0,placedBlocks:0,totalHours:0,placedHours:0,
      forcedFailed:[],failed:[],allFailed:[],capacityIssues:[],validationErrors:validation.errors,validationWarnings:validation.warnings,flexible:false};
    showScheduleResult(result);
    toast(`${validation.errors.length} veri hatası var. Dağıtım başlamadı.`,"err");
    return result;
  }
  const flexible=!!opts.flexibleBlocks;
  function blockParts(hours,maxBlk,fixed){
    const parts=[];
    let rem=hours;
    if(fixed){
      parts.push(hours); return parts;
    }
    if(!flexible||maxBlk<=1){
      while(rem>0){const sz=Math.min(maxBlk,rem);parts.push(sz);rem-=sz;}
      return parts;
    }
    const mode=Math.random();
    if(mode<0.34){
      while(rem>0){const sz=Math.min(maxBlk,rem);parts.push(sz);rem-=sz;}
    }else if(mode<0.72){
      parts.push(Math.min(maxBlk,rem)); rem-=parts[0];
      while(rem>0){parts.push(1);rem--;}
    }else{
      while(rem>0){parts.push(1);rem--;}
    }
    return parts;
  }

  // Alternatif blok bölüşümleri; kompakt olan önce gelir (2+2+1 -> 2+1+1+1 -> 1+1+1+1+1)
  const altsCache={};
  function altsFor(def){
    if(altsCache[def.id]) return altsCache[def.id];
    const hours=Math.max(1,Number(def.hours)||1);
    if(def.blockFixed){ altsCache[def.id]=[[hours]]; return altsCache[def.id]; }
    const maxBlk=Math.max(1,Number(def.block)||1);
    altsCache[def.id]=altDecompositions(hours,maxBlk).slice().sort((a,b)=>a.length-b.length);
    return altsCache[def.id];
  }

  // Hiç yerleştirilemeyecek dersler: uygun saat yoksa o ders imkansızdır
  const noCandidateDefs=[],noCandidateDefIds=new Set();
  for(const def of school.defs){
    const testSize=def.blockFixed?Math.max(1,Number(def.hours)||1):1;
    const b1={...def,size:testSize};
    let has=false;
    for(const day of days){ for(let start=1;start<=periods-testSize+1;start++){ if(baseCanPlace(b1,day,start)){ has=true; break; } } if(has) break; }
    if(!has){ noCandidateDefs.push(def); noCandidateDefIds.add(def.id); }
  }
  const activeDefs=school.defs.filter(d=>!noCandidateDefIds.has(d.id));
  if(!activeDefs.length&&!noCandidateDefs.length){toast("Ders yok.","err");return null;}
  if(!S.teachers.length||!school.classes.length){toast("Sınıf veya öğretmen yok.","err");return null;}
  solveCancelled=false;

  // Başlangıç blok seti (kapasite hesabı ve toplamlar için)
  const allBlocks=[];
  for(const g of activeDefs){
    const maxBlk=Math.max(1,Number(g.block)||1);
    let part=1;
    for(const sz of blockParts(Math.max(1,Number(g.hours)||1),maxBlk,g.blockFixed)){
      allBlocks.push({...g,size:sz,bid:uid(),defId:g.id,partNo:part++});
    }
  }

  const ck=(cl,d,p)=>`${cl}|${d}|${p}`;
  const tk=(t,d,p)=>`${t}|${d}|${p}`;
  const dk=(d,p)=>`${d}|${p}`;
  const rk=(r,d,p)=>`${r}|${d}|${p}`;
  const blockKey=b=>`${b.course}|${b.teacher}|${b.className}`;
  // "Aynı dersin parçaları" kısıtları (spreadCourse / courseGap) TANIM (def) bazlıdır:
  // aynı öğretmen-sınıf-ders tanımının blokları günlere yayılır; aynı adlı FARKLI tanımlar
  // (örn. iki ayrı İNGİLİZCE tanımı / farklı öğretmen) birbirini engellemez.
  const defKey=b=>b.defId||blockKey(b);
  const blockLabel=b=>`${b.className} ${b.course} (${tLabelArr(b.teachers||[b.teacher])})`;

  // Diğer okullardaki derslik kullanımları (derslikler tüm okulların ortak mekânıdır;
  // aynı derslik aynı anda yalnız bir derste kullanılabilir). Okulların ders saatleri
  // farklı olabildiğinden çakışma ZAMAN bazlı kontrol edilir (saat aralığı örtüşmesi).
  const roomBusyOther={}; // room|day -> [aralık]
  for(const sc of S.schools){
    if(sc.id===S.currentSchool) continue;
    for(const l of sc.lessons||[]){
      if(!l.room) continue;
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      const k=`${l.room}|${l.day}`;
      (roomBusyOther[k]=roomBusyOther[k]||[]).push({start:toMin(pt.start),end:toMin(pt.end)});
    }
  }

  // ─── Yeni kısıtlar (dağıtım öncesi özelleştirilir) ───
  const C=normConstraints(curSchool().constraints);
  const courseGap=Math.max(0,Math.floor(Number(C.courseGap)||0));
  const minBreak=Math.max(0,Math.floor(Number(C.minBreak)||0));

  // Öğle arası pencereleri (gün bazlı): kullanıcının belirlediği schoolLunch veya otomatik tespit
  const lunchWinByDay={};
  for(const day of days) lunchWinByDay[day]=lunchWindowsForDay(day);
  const requireLunch=!!C.requireLunch && Object.values(lunchWinByDay).some(w=>w.length>0);
  // Diğer okullardaki sabit derslerin öğretmen|gün -> [aralık] haritası
  const otherInts={};
  for(const sc of S.schools){
    if(sc.id===S.currentSchool) continue;
    for(const l of sc.lessons||[]){
      const pt=sc.periodTimes&&sc.periodTimes[l.period-1];
      if(!pt) continue;
      for(const t of lessonTeachers(l)){
        const k=`${t}|${l.day}`;
        (otherInts[k]=otherInts[k]||[]).push({start:toMin(pt.start),end:toMin(pt.end),schoolId:sc.id});
      }
    }
  }
  function blockInterval(b,start){
    const pt=school.periodTimes;
    const p0=start, p1=start+b.size-1;
    if(!pt[p0-1]||!pt[p1-1]) return null;
    return {start:toMin(pt[p0-1].start), end:toMin(pt[p1-1].end), schoolId:school.id};
  }
  function teacherDayIntervals(state,t,day){
    const cur=(state.teacherDayIntervals||{})[`${t}|${day}`]||[];
    const oth=otherInts[`${t}|${day}`]||[];
    return cur.concat(oth);
  }
  // Teneffüs şartı SADECE farklı okullar arası geçişlerde geçerlidir.
  // Aynı okul içinde ders saatleri arasında zaten ara vardır.
  function breaksBreak(ints,bi){
    for(const iv of ints){
      if(iv.schoolId===bi.schoolId) continue;
      if(iv.end>bi.start-minBreak && iv.start<bi.end+minBreak) return true;
    }
    return false;
  }
  function hasFreeLunch(ints,bi,day){
    const win=lunchWinByDay[day];
    if(!win||!win.length) return true; // o gün öğle arası tanımlı değilse şart yok
    const all=bi?ints.concat([bi]):ints;
    for(const lw of win){
      let free=true;
      for(const iv of all){ if(iv.start<lw.end&&lw.start<iv.end){ free=false; break; } }
      if(free) return true;
    }
    return false;
  }
  const pairConflicts={};
  for(const pr of (C.coursePairs||[])){
    if(!pr.a||!pr.b||pr.a===pr.b) continue;
    (pairConflicts[pr.a]=pairConflicts[pr.a]||new Set()).add(pr.b);
    (pairConflicts[pr.b]=pairConflicts[pr.b]||new Set()).add(pr.a);
  }
  const courseBlockCount={};
  for(const b of allBlocks) courseBlockCount[defKey(b)]=(courseBlockCount[defKey(b)]||0)+1;
  const teacherCourseSet={};
  for(const b of allBlocks) for(const t of (b.teachers||[b.teacher])) (teacherCourseSet[t]=teacherCourseSet[t]||new Set()).add(b.course);
  function blockPriority(b){
    if(C.spreadCourse && (courseBlockCount[defKey(b)]||0)>1) return true;
    if(C.spreadTeacher && (b.teachers||[b.teacher]).some(t=>(teacherCourseSet[t]?.size||0)>1)) return true;
    if(pairConflicts[b.course]) return true;
    return false;
  }
  function constraintViolation(state,b,day,start){
    if(C.spreadCourse && (state.courseDayCount[`${defKey(b)}|${day}`]||0)>0) return "spreadCourse";
    if(courseGap>0 && start!==undefined){
      const slots=state.courseSlots[`${defKey(b)}|${day}`];
      if(slots){
        for(const s of slots){
          if(start < s.start+s.size+courseGap && s.start < start+b.size+courseGap) return "courseGap";
        }
      }
    }
    if(C.spreadTeacher){
      for(const t of (b.teachers||[b.teacher])){
        const set=state.teacherDayCourses[`${t}|${day}`];
        if(set && [...set].some(c2=>c2!==b.course)) return "spreadTeacher";
      }
    }
    const pcs=pairConflicts[b.course];
    if(pcs && pcs.size){
      const set=state.dayCourseSet[`${b.className}|${day}`];
      if(set){ for(const c2 of pcs){ if(set.has(c2)) return "coursePair"; } }
    }
    if(minBreak>0 || requireLunch){
      const bi=blockInterval(b,start);
      if(bi){
        const teachers=b.teachers&&b.teachers.length?b.teachers:[b.teacher];
        for(const t of teachers){
          const ints=teacherDayIntervals(state,t,day);
          if(minBreak>0 && breaksBreak(ints,bi)) return "break";
          if(requireLunch && !hasFreeLunch(ints,bi,day)) return "lunch";
        }
      }
    }
    return null;
  }
  function countViolations(placements){
    const dayInfo={};
    for(const p of Object.values(placements)){
      const b=p.block, day=p.day;
      if(!dayInfo[day]) dayInfo[day]={courseCount:{},teacherCourses:{},courseSlots:{},dayCourses:{}};
      dayInfo[day].courseCount[defKey(b)]=(dayInfo[day].courseCount[defKey(b)]||0)+1;
      for(const t of (b.teachers||[b.teacher])) (dayInfo[day].teacherCourses[t]=dayInfo[day].teacherCourses[t]||new Set()).add(b.course);
      (dayInfo[day].courseSlots[defKey(b)]=dayInfo[day].courseSlots[defKey(b)]||[]).push({start:p.start,size:b.size});
      (dayInfo[day].dayCourses[b.className]=dayInfo[day].dayCourses[b.className]||new Set()).add(b.course);
    }
    let spreadCourseV=0,spreadTeacherV=0,coursePairV=0,courseGapV=0,breakV=0,lunchV=0;
    for(const day in dayInfo){
      const di=dayInfo[day];
      if(C.spreadCourse) for(const c in di.courseCount) if(di.courseCount[c]>1) spreadCourseV+=di.courseCount[c]-1;
      if(C.spreadTeacher) for(const t in di.teacherCourses) if(di.teacherCourses[t].size>1) spreadTeacherV+=di.teacherCourses[t].size-1;
      if(courseGap>0){
        for(const c in di.courseSlots){
          const slots=di.courseSlots[c].sort((a,b)=>a.start-b.start);
          for(let i=1;i<slots.length;i++){
            const gap=slots[i].start-(slots[i-1].start+slots[i-1].size);
            if(gap<courseGap) courseGapV+=courseGap-gap;
          }
        }
      }
      if(C.coursePairs&&C.coursePairs.length){
        for(const cl in di.dayCourses){
          const set=di.dayCourses[cl];
          for(const pr of C.coursePairs){ if(pr.a!==pr.b&&set.has(pr.a)&&set.has(pr.b)) coursePairV++; }
        }
      }
    }
    if(minBreak>0||requireLunch){
      // öğretmen|gün -> [aralık] (bu okulun yerleşimleri + diğer okullar)
      const tInts={};
      for(const p of Object.values(placements)){
        const b=p.block, day=p.day;
        const bi=blockInterval(b,p.start);
        if(!bi) continue;
        for(const t of (b.teachers||[b.teacher])){
          const k=`${t}|${day}`;
          (tInts[k]=tInts[k]||[]).push(bi);
        }
      }
      for(const k of Object.keys(otherInts)) (tInts[k]=(tInts[k]||[])).push(...otherInts[k]);
      for(const [k,ints] of Object.entries(tInts)){
        if(ints.length<2) continue;
        ints.sort((a,b)=>a.start-b.start);
        if(minBreak>0){
          for(let i=1;i<ints.length;i++){
            const a=ints[i-1], b=ints[i];
            if(a.schoolId===b.schoolId) continue; // aynı okul içi ara zaten var
            const gap=b.start-a.end;
            if(gap<minBreak) breakV+=minBreak-gap;
          }
        }
        if(requireLunch){
          const day=k.split('|')[1];
          const free=hasFreeLunch(ints,undefined,day);
          if(!free) lunchV++;
        }
      }
    }
    return {spreadCourseV,spreadTeacherV,coursePairV,courseGapV,breakV,lunchV,total:spreadCourseV+spreadTeacherV+coursePairV+courseGapV+breakV+lunchV};
  }

  showScheduleProgress("Dağıtım hazırlanıyor...",0);

  function baseCanPlace(b,day,start){
    for(let o=0;o<b.size;o++){
      const pp=start+o;
      if(pp>periods) return false;
      if(!classOpen(b.className,day,pp)) return false;
      for(const t of (b.teachers||[b.teacher])) if(!teacherOpen(t,day,pp)) return false;
      if(b.avail && b.avail[`${day}|${pp}`]===false) return false; // derse özel kapalı saat
    }
    return true;
  }

  function openClassSlots(className){
    let n=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(classOpen(className,day,p)) n++;
    return n;
  }

  function openTeacherSlots(teacher){
    let n=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(teacherOpen(teacher,day,p)) n++;
    return n;
  }

  // Öğretmenin haftalık gerçek ders sınırı: her gün açık olabildiği saatlerden,
  // ders verdiği sınıflardan en az birinin de açık olduğu saatler düşülerek hesaplanır.
  // (Örn. tüm sınıflar Perşembe 6-7 kapalıysa öğretmen o gün en fazla 6 saat ders verebilir.)
  function teacherWeeklyCap(teacher, classNames){
    let cap=0;
    for(const day of days){
      let tOpen=0,anyOpen=0;
      for(let p=1;p<=periods;p++){
        if(!teacherOpen(teacher,day,p)) continue;
        tOpen++;
        for(const cl of classNames){ if(classOpen(cl,day,p)){ anyOpen++; break; } }
      }
      cap+=Math.min(tOpen,anyOpen);
    }
    return cap;
  }

  function findCapacityIssues(blocks){
    const classNeed={},teacherNeed={},teacherClasses={},issues=[];
    for(const b of blocks){
      classNeed[b.className]=(classNeed[b.className]||0)+b.size;
      for(const t of (b.teachers||[b.teacher])){
        teacherNeed[t]=(teacherNeed[t]||0)+b.size;
        (teacherClasses[t]=teacherClasses[t]||new Set()).add(b.className);
      }
    }
    for(const [name,need] of Object.entries(classNeed)){
      const open=openClassSlots(name);
      if(need>open) issues.push({type:"Sınıf",name,need,open,extra:need-open});
    }
    for(const [name,need] of Object.entries(teacherNeed)){
      const open=teacherWeeklyCap(name,teacherClasses[name]);
      if(need>open) issues.push({type:"Öğretmen",name,need,open,extra:need-open});
    }
    return issues;
  }

  const capacityIssues=findCapacityIssues(allBlocks);
  const forcedFailed=[];
  const forcedDefIds=new Set(noCandidateDefIds);
  for(const def of noCandidateDefs){
    forcedFailed.push({...def,size:Math.max(1,Number(def.hours)||1),reason:"Bu ders için hiç uygun saat yok (sınıf ve öğretmen açık saatleri çakışmıyor)."});
  }
  for(const issue of capacityIssues){
    let extra=issue.extra;
    const candidates=activeDefs
      .filter(d=>!forcedDefIds.has(d.id) && (issue.type==="Sınıf"?d.className===issue.name:defTeachers(d).includes(issue.name)))
      .sort((a,b)=> (Math.max(1,Number(a.hours)||1)-Math.max(1,Number(b.hours)||1)) || (a.id<b.id?-1:1));
    for(const d of candidates){
      if(extra<=0) break;
      forcedDefIds.add(d.id);
      forcedFailed.push({...d,size:Math.max(1,Number(d.hours)||1),reason:`${issue.type} kapasitesi aşılıyor: ${issue.need}/${issue.open}`});
      extra-=Math.max(1,Number(d.hours)||1);
    }
  }
  const activeDefsList=activeDefs.filter(d=>!forcedDefIds.has(d.id));
  const blockCountBase=allBlocks.filter(b=>!forcedDefIds.has(b.defId)).length;

  function canPlace(state,b,slot){
    if(b.room){
      const bi=blockInterval(b,slot.start);
      if(bi){ const others=roomBusyOther[`${b.room}|${slot.day}`]||[]; for(const iv of others){ if(iv.start<bi.end&&bi.start<iv.end) return false; } }
    }
for(let o=0;o<b.size;o++){
      const p=slot.start+o;
      if(state.classBusy[ck(b.className,slot.day,p)]) return false;
      for(const t of (b.teachers||[b.teacher])) if(state.teacherBusy[tk(t,slot.day,p)]) return false;
      if(b.room && state.roomBusy[rk(b.room,slot.day,p)]) return false;
    }
    return true;
  }

  function putBlock(state,b,slot){
    state.placements[b.bid]={block:b,day:slot.day,start:slot.start};
    for(let o=0;o<b.size;o++){
      const p=slot.start+o;
      state.classBusy[ck(b.className,slot.day,p)]=b.bid;
      for(const t of (b.teachers||[b.teacher])) state.teacherBusy[tk(t,slot.day,p)]=b.bid;
      if(b.room) state.roomBusy[rk(b.room,slot.day,p)]=b.bid;
      state.cellLoad[dk(slot.day,p)]=(state.cellLoad[dk(slot.day,p)]||0)+1;
      state.classDay[`${b.className}|${slot.day}`]=(state.classDay[`${b.className}|${slot.day}`]||0)+1;
      for(const t of (b.teachers||[b.teacher])) state.teacherDay[`${t}|${slot.day}`]=(state.teacherDay[`${t}|${slot.day}`]||0)+1;
      state.courseDay[`${defKey(b)}|${slot.day}`]=(state.courseDay[`${defKey(b)}|${slot.day}`]||0)+1;
    }
    state.courseDayCount[`${defKey(b)}|${slot.day}`]=(state.courseDayCount[`${defKey(b)}|${slot.day}`]||0)+1;
    (state.courseSlots[`${defKey(b)}|${slot.day}`]=state.courseSlots[`${defKey(b)}|${slot.day}`]||[]).push({start:slot.start,size:b.size});
    for(const t of (b.teachers||[b.teacher])) (state.teacherDayCourses[`${t}|${slot.day}`]=state.teacherDayCourses[`${t}|${slot.day}`]||new Set()).add(b.course);
    (state.dayCourseSet[`${b.className}|${slot.day}`]=state.dayCourseSet[`${b.className}|${slot.day}`]||new Set()).add(b.course);
    const bi=blockInterval(b,slot.start);
    if(bi){
      for(const t of (b.teachers||[b.teacher])) (state.teacherDayIntervals[`${t}|${slot.day}`]=state.teacherDayIntervals[`${t}|${slot.day}`]||[]).push(bi);
    }
  }

  function scoreSlot(state,b,slot){
    let score=0;
    const clsDay=state.classDay[`${b.className}|${slot.day}`]||0;
    const tchDay=Math.max(...(b.teachers||[b.teacher]).map(t=>state.teacherDay[`${t}|${slot.day}`]||0));
    const sameCourseDay=state.courseDay[`${defKey(b)}|${slot.day}`]||0;
    score+=sameCourseDay*180;
    score+=Math.max(0,clsDay-5)*18;
    score+=Math.max(0,tchDay-5)*14;
    score+=slot.start*0.9;
    score+=days.indexOf(slot.day)*0.15;
    for(let o=0;o<b.size;o++) score+=(state.cellLoad[dk(slot.day,slot.start+o)]||0)*0.4;
    return score+Math.random()*2.5;
  }

  const candCache={};
  function blockCandidates(defId,size){
    const k=defId+"|"+size;
    if(candCache[k]) return candCache[k];
    const def=activeDefs.find(d=>d.id===defId);
    const b={...def,size};
    const list=[];
    for(const day of days){ for(let start=1;start<=periods-size+1;start++){ if(baseCanPlace(b,day,start)) list.push({day,start}); } }
    candCache[k]=list;
    return list;
  }
  const defFailCount={};
  let bestFailedDefs=new Set();

  function runAttempt(attempt){
    // Bloklar bu deneme için yeniden oluşturulur: yerleşemeyen / yerleşmesi zor dersler için
    // farklı blok bölüşümleri sırayla denenir (2+2+1 -> 2+1+1+1 -> 1+1+1+1+1)
    const blocks=[];
    for(const g of activeDefsList){
      const hours=Math.max(1,Number(g.hours)||1);
      const maxBlk=Math.max(1,Number(g.block)||1);
      let parts;
      if(!flexible||maxBlk<=1){
        parts=blockParts(hours,maxBlk,g.blockFixed);
      }else{
        const alts=altsFor(g);
        const hardNow=bestFailedDefs.has(g.id)||(defFailCount[g.id]||0)>0;
        if(hardNow){
          parts=alts[attempt % alts.length];
        }else{
          parts=alts[Math.floor(Math.random()*alts.length)];
        }
      }
      let part=1;
      for(const sz of parts){
        blocks.push({...g,size:sz,bid:uid(),defId:g.id,partNo:part++,candidates:blockCandidates(g.id,sz)});
      }
    }
    const state={
      placements:{},classBusy:{},teacherBusy:{},roomBusy:{},cellLoad:{},
      classDay:{},teacherDay:{},courseDay:{},
      courseDayCount:{},courseSlots:{},teacherDayCourses:{},dayCourseSet:{},teacherDayIntervals:{}
    };
    const placed=[],failed=[];
    // Önce yerleşemeyen / yerleşme ihtimali düşük dersler yerleştirilir
    const ordered=[...blocks].sort((a,b)=>{
      const fx=bestFailedDefs.has(a.defId)?1:0, fy=bestFailedDefs.has(b.defId)?1:0;
      if(fx!==fy) return fy-fx;
      const cx=defFailCount[a.defId]||0, cy=defFailCount[b.defId]||0;
      if(cx!==cy) return cy-cx;
      const pa=blockPriority(a)?1:0, pb=blockPriority(b)?1:0;
      if(pa!==pb) return pb-pa;
      if(a.candidates.length!==b.candidates.length) return a.candidates.length-b.candidates.length;
      if(a.size!==b.size) return a.size-b.size;
      return Math.random()-0.5;
    });
    // En-kısıtlı-önce (most-constrained-first): her adımda GÜNCEL durumda uygun saati en az olan
    // blok yerleştirilir. Böylece yerleşmesi zor (tek saatlik, az boş yeri kalan) dersler önce
    // yerleşir; sonraki adımlar kalan boşluklara uyum sağlar. Maliyet düşüktür: yalnızca
    // öğretmen/sınıf/derslik paylaşan blokların sayısı yeniden hesaplanır.
    const remaining=[...ordered];
    const countViable=b=>{ let n=0; for(const slot of b.candidates){ if(canPlace(state,b,slot)&&!constraintViolation(state,b,slot.day,slot.start)) n++; } return n; };
    const viableCache=new Map(), dirty=new Set(remaining.map(b=>b.bid));
    while(remaining.length){
      let bi=0, bestC=Infinity;
      for(let i=0;i<remaining.length;i++){
        const b=remaining[i];
        if(dirty.has(b.bid)){ viableCache.set(b.bid,countViable(b)); dirty.delete(b.bid); }
        const c=viableCache.get(b.bid);
        if(c<bestC){ bestC=c; bi=i; }
      }
      const b=remaining[bi];
      remaining.splice(bi,1);
      const viable=b.candidates.filter(slot=>canPlace(state,b,slot) && !constraintViolation(state,b,slot.day,slot.start));
      if(!viable.length){ failed.push(b); defFailCount[b.defId]=(defFailCount[b.defId]||0)+1; continue; }
      viable.sort((x,y)=>scoreSlot(state,b,x)-scoreSlot(state,b,y));
      const pickLimit=attempt<20?1:Math.min(flexible?9:4,viable.length);
      const slot=viable[Math.floor(Math.random()*pickLimit)];
      putBlock(state,b,slot);
      placed.push(b);
      for(const rb of remaining){
        const shared=(rb.teachers||[rb.teacher]).some(t=>(b.teachers||[b.teacher]).includes(t));
        if(shared||rb.className===b.className||(b.room&&rb.room===b.room)) dirty.add(rb.bid);
      }
    }
    return {state,placed,failed};
  }

  function resultCost(result){
    let cost=result.failed.length*100000;
    const courseDays={};
    for(const p of Object.values(result.state.placements)){
      const key=defKey(p.block);
      if(!courseDays[key]) courseDays[key]={};
      courseDays[key][p.day]=(courseDays[key][p.day]||0)+1;
      cost+=p.start*0.2;
    }
    for(const daysMap of Object.values(courseDays)){
      for(const cnt of Object.values(daysMap)) if(cnt>1) cost+=(cnt-1)*500;
    }
    cost+=countViolations(result.state.placements).total*400;
    return cost;
  }

  function blankState(){
    return {placements:{},classBusy:{},teacherBusy:{},roomBusy:{},cellLoad:{},
      classDay:{},teacherDay:{},courseDay:{},courseDayCount:{},courseSlots:{},teacherDayCourses:{},dayCourseSet:{},teacherDayIntervals:{}};
  }
  function stateFromPlacements(placements){
    const st=blankState();
    for(const pid in placements){ const pl=placements[pid]; putBlock(st,pl.block,{day:pl.day,start:pl.start}); }
    return st;
  }
  // Bir dersin saatlerini farklı blok kombinasyonlarına böler (örn. 5s -> [2,2,1],[2,1,1,1],[1,1,1,1,1])
  function altDecompositions(hours,maxBlk){
    const res=[];
    function rec(rem,path){
      if(rem===0){ res.push([...path]); return; }
      for(let s=Math.min(maxBlk,rem); s>=1; s--) rec(rem-s,path.concat(s));
    }
    rec(hours,[]);
    // Daha ince (daha çok 1'lik) bölünmüşler önce denensin — yerleşme şansı daha yüksek
    res.sort((a,b)=>b.length-a.length || b[0]-a[0]);
    return res.slice(0,80);
  }
  // Bir bloğu yerleştirir; sığmazsa başka bir dersi yerinden oynatarak (kick/min-conflicts) yer açar
  let forceDeadline=0;
  function forcePlace(placements, block, depth){
    if(Date.now()>forceDeadline) return null;
    depth=depth||0;
    const st=stateFromPlacements(placements);
    const cands=[];
    for(const day of days){ for(let start=1;start<=periods-block.size+1;start++){ if(baseCanPlace(block,day,start)) cands.push({day,start}); } }
    let via=cands.filter(s=>canPlace(st,block,s)&&!constraintViolation(st,block,s.day,s.start));
    if(via.length){ const np={...placements}; const s=via.sort((x,y)=>scoreSlot(st,block,x)-scoreSlot(st,block,y))[0]; np[block.bid]={block,day:s.day,start:s.start}; return np; }
    if(depth>=2) return null;
    for(const slot of cands){
      const occ=[];
      for(let o=0;o<block.size;o++){ const p=slot.start+o;
        const cb=st.classBusy[ck(block.className,slot.day,p)]; if(cb&&cb!==block.bid) occ.push(cb);
        for(const t of (block.teachers||[block.teacher])){ const tb=st.teacherBusy[tk(t,slot.day,p)]; if(tb&&tb!==block.bid) occ.push(tb); }
      }
      // Önce tek saatlik blokları tekmele: yer değiştirmeleri kolay olduğundan daha iyi sonuç verir
      const kickList=[...new Set(occ)].sort((a,b)=>(placements[a]&&placements[a].block.size||9)-(placements[b]&&placements[b].block.size||9));
      for(const obid of kickList){
        const op=placements[obid]; if(!op) continue;
        const rem={...placements}; delete rem[obid];
        const after1=forcePlace(rem, block, depth+1);
        if(after1){
          const after2=forcePlace(after1, op.block, depth+1);
          if(after2) return after2;
        }
      }
    }
    return null;
  }
  // Yerleşemeyen derslerin bloklarını farklı kombinasyonlarla dener; başka dersleri de yerinden oynatarak tam yerleşmeyi hedefler
  function repair(best){
    const t0=Date.now();
    forceDeadline=t0+12000;
    let placements={};
    for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let pending=[...new Set(best.failed.map(b=>b.defId))];
    let passes=0;
    while(pending.length && passes<10 && !solveCancelled){
      passes++; let improvedAny=false; const stillPending=[];
      if(Date.now()-t0>12000) break;
      for(const defId of pending){
        const sample=best.failed.find(b=>b.defId===defId);
        const hours=sample.hours, maxBlk=Math.max(1,Number(sample.block)||1);
        const alts=sample.blockFixed?[[hours]]:altDecompositions(hours,maxBlk);
        let done=false;
        for(const alt of alts){
          const altBlocks=alt.map((sz,i)=>({...sample,size:sz,bid:uid(),defId,partNo:i+1}));
          const work={};
          for(const pid in placements){ if(placements[pid].block.defId!==defId) work[pid]=placements[pid]; }
          let ok=true, cur=work;
          for(const b of altBlocks){ const np=forcePlace(cur,b,2); if(!np){ ok=false; break; } cur=np; }
          if(ok){ placements=cur; done=true; improvedAny=true; break; }
        }
        if(!done) stillPending.push(defId);
      }
      pending=stillPending;
      if(!improvedAny) break;
    }
    const st=stateFromPlacements(placements);
    const failed=best.failed.filter(b=>pending.includes(b.defId));
    return { state:st, failed, placed:Object.keys(placements).length };
  }

  // Yerleşik dersleri de yerinden oynatarak (min-conflicts) takıldığı yerel optimumdan kurtulup yerleşmeyenleri sığdırmaya çalışır
  function improve(best){
    const t0=Date.now();
    forceDeadline=t0+20000;
    let placements={};
    for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let unplaced=best.failed.map(b=>({...b,bid:uid()}));
    let snap={placements:{...placements},unplaced:[...unplaced]};
    let iter=0,lastImprove=0;
    while(iter<8000 && !solveCancelled){
      iter++;
      if(Date.now()-t0>20000) break;
      let placedOne=false;
      for(let i=0;i<unplaced.length;i++){
        const np=forcePlace(placements,unplaced[i],3);
        if(np){ placements=np; unplaced.splice(i,1); placedOne=true; break; }
      }
      if(placedOne){
        if(unplaced.length<snap.unplaced.length){ snap={placements:{...placements},unplaced:[...unplaced]}; lastImprove=iter; }
        if(!unplaced.length) break;
        continue;
      }
      const pids=Object.keys(placements);
      if(!pids.length) break;
      // Konflikt odaklı kick: yerleşmeyen derslerin uygun saatlerini kapatan dersleri öncelikle yerinden oynat
      const stAll=stateFromPlacements(placements);
      const occ=new Set();
      for(const u of unplaced){
        for(const day of days){ for(let start=1;start<=periods-u.size+1;start++){
          if(!baseCanPlace(u,day,start)) continue;
          for(let o=0;o<u.size;o++){ const p=start+o;
            const cb=stAll.classBusy[ck(u.className,day,p)]; if(cb&&cb!==u.bid) occ.add(cb);
            for(const t of (u.teachers||[u.teacher])){ const tb=stAll.teacherBusy[tk(t,day,p)]; if(tb&&tb!==u.bid) occ.add(tb); }
          }
        }}
      }
      // Önce tek saatlik blokları öne al (yer değiştirmeleri kolay), yine de rastgele seç
      const pool=(occ.size?[...occ]:pids).sort((a,b)=>(placements[a]&&placements[a].block.size||9)-(placements[b]&&placements[b].block.size||9));
      const pid=pool[Math.floor(Math.random()*pool.length)];
      const pl=placements[pid];
      const rem={...placements}; delete rem[pid];
      const st=stateFromPlacements(rem);
      const cands=[];
      for(const day of days){ for(let start=1;start<=periods-pl.block.size+1;start++){ if(baseCanPlace(pl.block,day,start)) cands.push({day,start}); } }
      const via=cands.filter(s=>canPlace(st,pl.block,s)&&!constraintViolation(st,pl.block,s.day,s.start));
      if(via.length){
        const s=via.sort((x,y)=>scoreSlot(st,pl.block,x)-scoreSlot(st,pl.block,y))[0];
        placements={...rem}; placements[pid]={block:pl.block,day:s.day,start:s.start};
      }else{
        // Yerinden oynatılan ders için zincirleme kick ile yeni yer bul; bulunamazsa eskisi gibi kalsın
        const np=forcePlace(rem,pl.block,0);
        if(np) placements=np;
      }
      if(iter-lastImprove>3000) break;
    }
    const st=stateFromPlacements(snap.placements);
    return { state:st, failed:snap.unplaced, placed:Object.keys(snap.placements).length };
  }

  // ILS: yerel optimumdan çıkmak için yerleşmeyen derslerin saatlerini kapatan ve rastgele
  // blokları söküp yeniden yerleştirerek tam yerleşmeyi hedefler
  function ils(best, deadlineMs){
    const start=Date.now();
    forceDeadline=start+deadlineMs;
    let placements={};
    for(const pid in best.state.placements) placements[pid]={block:best.state.placements[pid].block,day:best.state.placements[pid].day,start:best.state.placements[pid].start};
    let unplaced=best.failed.map(b=>({...b,bid:uid()}));
    let snap={placements:{...placements},unplaced:[...unplaced]};
    let lastImprove=start;
    while(Date.now()-start<deadlineMs && !solveCancelled){
      for(let i=0;i<unplaced.length;i++){
        const np=forcePlace(placements,unplaced[i],3);
        if(np){ placements=np; unplaced.splice(i,1); i--; }
      }
      if(!unplaced.length){ snap={placements:{...placements},unplaced:[]}; break; }
      if(unplaced.length<snap.unplaced.length){ snap={placements:{...placements},unplaced:[...unplaced]}; lastImprove=Date.now(); }
      if(Date.now()-lastImprove>15000) break;
      const stAll=stateFromPlacements(placements);
      const toRemove=new Set();
      for(const u of unplaced){
        for(const day of days) for(let s=1;s<=periods-u.size+1;s++){
          if(!baseCanPlace(u,day,s)) continue;
          for(let o=0;o<u.size;o++){ const p=s+o;
            const cb=stAll.classBusy[ck(u.className,day,p)]; if(cb&&cb!==u.bid) toRemove.add(cb);
            for(const t of (u.teachers||[u.teacher])){ const tb=stAll.teacherBusy[tk(t,day,p)]; if(tb&&tb!==u.bid) toRemove.add(tb); }
          }
        }
      }
      const pids=Object.keys(placements);
      const extra=4+Math.floor(Math.random()*5);
      for(let k=0;k<extra;k++){ toRemove.add(pids[Math.floor(Math.random()*pids.length)]); }
      const kept={};
      for(const pid in placements) if(!toRemove.has(pid)) kept[pid]=placements[pid];
      const ins=[];
      for(const pid of toRemove){ const pl=placements[pid]; if(pl) ins.push(pl.block); }
      for(const u of unplaced) ins.push(u);
      ins.sort((a,b)=>blockCandidates(a.defId,a.size).length-blockCandidates(b.defId,b.size).length);
      let cur=kept; const newUnplaced=[];
      for(const b of ins){ const np=forcePlace(cur,b,3); if(np) cur=np; else newUnplaced.push(b); }
      placements=cur;
      unplaced=newUnplaced;
    }
    const st=stateFromPlacements(snap.placements);
    return { state:st, failed:snap.unplaced, placed:Object.keys(snap.placements).length };
  }

  school.lessons=[];
  let best=null,bestCost=Infinity;
  const maxAttempts=flexible?18000:12000;
  const plateauLimit=flexible?6000:4000;
  let lastImprove=0,attemptsRun=0;
  const loopDeadline=Date.now()+45000;
  for(let a=0;a<maxAttempts;a++){
    attemptsRun=a+1;
    if(Date.now()>loopDeadline) break;
    const result=runAttempt(a);
    const cost=resultCost(result);
    if(!best||result.failed.length<best.failed.length||(result.failed.length===best.failed.length&&cost<bestCost)){
      best=result; bestCost=cost; lastImprove=a;
    }
    bestFailedDefs=new Set(best.failed.map(b=>b.defId));
    if(!result.failed.length) break;
    if(solveCancelled) break;
    if(a%25===0){
      const stuck=a-lastImprove;
      showScheduleProgress(`Deneme ${a+1}: en iyi ${best.placed.length}/${blockCountBase} blok (${stuck} denemedir iyileşme yok)`,Math.min(92,Math.round((a+1)/maxAttempts*92)));
      await waitFrame();
    }
    if(a-lastImprove>=plateauLimit) break;
  }

  if(best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Yerleşemeyen dersler için alternatif bloklar deneniyor...",94);
    await waitFrame();
    best=repair(best);
  }
  if(best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Yerleşemeyen dersler için son yerleşim turu yapılıyor...",96);
    await waitFrame();
    best=improve(best);
  }
  if(best.failed.length>0 && !solveCancelled){
    showScheduleProgress("Kalan dersler için derin arama yapılıyor...",97);
    await waitFrame();
    best=ils(best,20000);
  }
  const placedCount=Array.isArray(best.placed)?best.placed.length:best.placed;

for(const p of Object.values(best.state.placements)){
    const b=p.block;
    for(let o=0;o<b.size;o++){
      const lesson={id:b.bid, course:b.course, className:b.className,
        day:p.day, period:p.start+o, hours:b.size, part:o+1, room:b.room||null};
      setTeachers(lesson, b.teachers||[b.teacher]);
      school.lessons.push(lesson);
    }
  }

  saveState(); renderDefs(); refresh();
  const allFailed=[...forcedFailed,...best.failed];
  const result={
    totalBlocks:allBlocks.length,activeBlocks:blockCountBase,placedBlocks:placedCount,
    totalHours:allBlocks.reduce((s,b)=>s+b.size,0),
    placedHours:school.lessons.length,
    forcedFailed,failed:best.failed,allFailed,capacityIssues,noCandidate:[],validationWarnings:validation.warnings,
    constraintViolations:countViolations(best.state.placements),
    flexible,attempts:attemptsRun,maxAttempts,lessons:school.lessons.map(l=>({...l}))
  };
  if(!opts.silentResult){
    showScheduleResult(result);
    if(allFailed.length===0){
      toast(`✓ Tüm dersler yerleşti (${placedCount} blok).`,"ok");
    }else{
      const cap=capacityIssues[0];
      const why=cap?` ${cap.type}: ${cap.name} ${cap.need}/${cap.open}.`:"";
      const examples=allFailed.slice(0,3).map(b=>blockLabel(b)).join(", ");
      toast(`⚠ ${placedCount}/${allBlocks.length} blok yerleşti.${why} Yerleşmeyen: ${examples}${allFailed.length>3?"...":""}`,"err");
    }
  }
  return result;
}

/* ============================================================
   GÖRÜNÜM
   ============================================================ */
function refresh(){
  renderSideLists();
  const mode=document.querySelector(".nav-btn.active")?.dataset.view||"school";

  if(mode==="school"){renderGrid($("schoolGrid"),"school",null);renderSchoolTimes();}
  else if(mode==="lessons"){renderDefs();renderSideLists();if(document.querySelector("#ltab-classes")?.classList.contains("active")) renderClassDefsOverview();}
  else if(mode==="classes"){
    const sel=curSchool().selectedClass;
    $("classViewTitle").textContent=sel?`Sınıf: ${sel}`:"Sınıf Seçin";
    if(sel){renderGrid($("classGrid"),"class",sel);renderEntityDefs("class",sel);}
    else{$("classGrid").innerHTML='<div class="empty">Soldan bir sınıf seçin.</div>';$("classDefsList").innerHTML="";}
  }else if(mode==="teachers"){
    const sel=S.selectedTeacher;
    $("teacherViewTitle").textContent=sel?`Öğretmen: ${sel}`:"Öğretmen Seçin";
    if(sel){
      let sf=null;
      if(teacherViewMode==="orta"){ sf=S.schools.find(s=>s.name==="ORTAOKUL"); renderGrid($("teacherGrid"),"teacher",sel,sf); }
      else if(teacherViewMode==="lise"){ sf=S.schools.find(s=>s.name==="LİSE"); renderGrid($("teacherGrid"),"teacher",sel,sf); }
      else{ renderTeacherCombined($("teacherGrid"),sel,"teacher"); }
      renderEntityDefs("teacher",sel,sf?sf.name:null);
    }
    else{$("teacherGrid").innerHTML='<div class="empty">Soldan bir öğretmen seçin.</div>';$("teacherDefsList").innerHTML="";}
  }else if(mode==="rooms"){
    renderRoomList();
    const sel=S.selectedRoom;
    $("roomViewTitle").textContent=sel?`Derslik: ${sel}`:"Derslik Seçin";
    if(sel){
      const sf=roomViewMode==="orta"?S.schools.find(s=>s.name==="ORTAOKUL"):roomViewMode==="lise"?S.schools.find(s=>s.name==="LİSE"):null;
      renderTeacherCombined($("roomGrid"),sel,"room",sf?sf.name:null);
      renderRoomDefs(sel,sf?sf.name:null);
    }
    else{$("roomGrid").innerHTML='<div class="empty">Soldan bir derslik seçin.</div>';$("roomDefsList").innerHTML="";}
  }else if(mode==="constraints"){
    renderConstraints();
  }else if(mode==="status"){
    renderStatus();
  }
}

// Durum raporları
// Sınıfın haftalık açık (ders yapılabilir) saat sayısı — kapasite
function classOpenSlots(sc, cl){
  let n=0;
  const days=sc.days||SCHOOL_DFLT.days, periods=sc.periods||10;
  const cc=(sc.classClosed&&sc.classClosed[cl])||{};
  for(const day of days) for(let p=1;p<=periods;p++){
    if(sc.schoolClosed&&sc.schoolClosed[`${day}|${p}`]) continue;
    if(cc[`${day}|${p}`]) continue;
    n++;
  }
  return n;
}
// Öğretmenin haftalık ders verebileceği saat kapasitesi (o okulda)
function teacherCap(sc, t, classes){
  let cap=0;
  const days=sc.days||SCHOOL_DFLT.days, periods=sc.periods||10;
  const tc=(S.teacherClosed&&S.teacherClosed[t]&&S.teacherClosed[t][sc.id])||{};
  for(const day of days){
    let tOpen=0, anyOpen=0;
    for(let p=1;p<=periods;p++){
      if(sc.schoolClosed&&sc.schoolClosed[`${day}|${p}`]) continue;
      if(tc[`${day}|${p}`]) continue;
      tOpen++;
      for(const cl of classes){ if(!(((sc.classClosed&&sc.classClosed[cl])||{})[`${day}|${p}`])){ anyOpen++; break; } }
    }
    cap+=Math.min(tOpen,anyOpen);
  }
  return cap;
}
function renderStatus(){
  const el=$("statusReport");
  if(!el) return;
  const schools=schoolsWithDefs();
  const escv=esc;
  const fmt=n=>String(n);
  // Doluluk = EKLENEN (tanımlı) saat / TOPLAM kapasite (yerleşme oranı değil)
  // Renk: %0 yeşil → %100 kırmızı (doluluk arttıkça uyarı rengi)
  const pctBadge=p=>`<span class="def-badge" style="background:hsl(${Math.round(Math.max(0,120-p*1.2))},65%,42%);color:#fff">%${p}</span>`;
  if(statusMode==="school"){
    const v=verifySchedule();
    el.innerHTML='<table class="stat-table"><thead><tr><th>Okul</th><th>Tanım</th><th>Eklenen Saat</th><th>Yerleşen</th><th>Kapasite</th><th>Doluluk</th><th>Sorun</th></tr></thead><tbody>'+
      schools.map(sc=>{
        const added=sc.defs.reduce((s,d)=>s+Math.max(1,Number(d.hours)||1),0);
        const placed=(sc.lessons||[]).length;
        let cap=0; for(const cl of sc.classes||[]) cap+=classOpenSlots(sc,cl);
        const pct=cap?Math.round(added/cap*100):0;
        const issues=v.filter(x=>x.includes(sc.name)).length;
        return `<tr><td><strong>${escv(sc.name)}</strong></td><td>${sc.defs.length}</td><td>${fmt(added)}</td><td>${fmt(placed)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td><td>${issues?`<span class="def-badge err">${issues}</span>`:"<span class=\"def-badge ok\">0</span>"}</td></tr>`;
      }).join("")+'</tbody></table>';
  }else if(statusMode==="teachers"){
    const rows=S.teachers.map(t=>{
      let added=0,placed=0,cap=0;
      const tClasses=[];
      for(const sc of schools){
        const cls=new Set();
        for(const d of sc.defs||[]){ if(defTeachers(d).includes(t)){ added+=Math.max(1,Number(d.hours)||1); cls.add(d.className); } }
        for(const l of sc.lessons||[]) if(lessonTeachers(l).includes(t)) placed++;
        if(cls.size) tClasses.push([sc,cls]);
      }
      for(const [sc,cls] of tClasses) cap+=teacherCap(sc,t,cls);
      const pct=cap?Math.round(added/cap*100):0;
      return `<tr><td><strong>${escv(t)}</strong></td><td>${fmt(added)}</td><td>${fmt(placed)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td></tr>`;
    }).join("");
    el.innerHTML='<table class="stat-table"><thead><tr><th>Öğretmen</th><th>Eklenen Saat</th><th>Yerleşen</th><th>Kapasite</th><th>Doluluk</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }else if(statusMode==="class"){
    const rows=[];
    for(const sc of schools){
      for(const cl of sc.classes||[]){
        let added=0,placed=0;
        for(const d of sc.defs||[]) if(d.className===cl) added+=Math.max(1,Number(d.hours)||1);
        placed=sc.lessons.filter(l=>l.className===cl).length;
        const cap=classOpenSlots(sc,cl);
        const pct=cap?Math.round(added/cap*100):0;
        rows.push(`<tr><td><strong>${escv(sc.name)}</strong></td><td><strong>${escv(cl)}</strong></td><td>${fmt(added)}</td><td>${fmt(placed)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td></tr>`);
      }
    }
    el.innerHTML='<table class="stat-table"><thead><tr><th>Okul</th><th>Sınıf</th><th>Eklenen Saat</th><th>Yerleşen</th><th>Kapasite</th><th>Doluluk</th></tr></thead><tbody>'+rows.join("")+'</tbody></table>';
  }else if(statusMode==="room"){
    const rooms=[...(S.rooms||[])];
    if(!rooms.length){ el.innerHTML='<div class="empty">Henüz derslik tanımlanmadı.</div>'; return; }
    const ref=curSchool(); const cap=ref?(ref.days||SCHOOL_DFLT.days).length*(ref.periods||10):50;
    const rows=rooms.map(r=>{
      let added=0; const perSchool={};
      for(const sc of schools){
        const n=sc.lessons.filter(l=>l.room===r).length;
        const defs=sc.defs.filter(d=>d.room===r).length;
        if(n||defs){ perSchool[sc.name]=`${defs} tanım / ${n} yerleşen`; added+=defs; }
      }
      const pct=cap?Math.round(added/cap*100):0;
      const detail=Object.entries(perSchool).map(([k,x])=>`${escv(k)}: ${x}`).join(" • ");
      return `<tr><td><strong>${escv(r)}</strong></td><td>${fmt(added)}</td><td>${fmt(cap)}</td><td>${pctBadge(pct)}</td><td>${detail||"—"}</td></tr>`;
    }).join("");
    el.innerHTML='<table class="stat-table"><thead><tr><th>Derslik</th><th>Eklenen (tanım)</th><th>Kapasite</th><th>Doluluk</th><th>Okullar</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }
  makeSortable(el.querySelector(".stat-table"));
}
// Durum tablolarını sütun başlığına tıklayınca sıralanabilir yapar
function makeSortable(table){
  if(!table||!table.querySelector) return;
  const thead=table.querySelector("thead"), tbody=table.querySelector("tbody");
  if(!thead||!tbody) return;
  const ths=[...thead.querySelectorAll("th")];
  ths.forEach((th,i)=>{
    th.style.cursor="pointer";
    th.title="Sıralamak için tıkla";
    th.addEventListener("click",()=>{
      const asc=th.dataset.asc!=="1";
      ths.forEach(x=>{ x.dataset.asc=""; x.textContent=x.textContent.replace(/ [▲▼]$/,""); });
      th.dataset.asc=asc?"1":"0";
      th.textContent+=(asc?" ▲":" ▼");
      const rows=[...tbody.querySelectorAll("tr")];
      const col=th.cellIndex;
      rows.sort((a,b)=>{
        const av=(a.children[col]?a.children[col].textContent:"").trim()||"";
        const bv=(b.children[col]?b.children[col].textContent:"").trim()||"";
        const an=parseFloat(av.replace(/[^0-9.]/g,""))||0;
        const bn=parseFloat(bv.replace(/[^0-9.]/g,""))||0;
        const bothNum=av&&bv&&(isFinite(an)||isFinite(bn));
        const cmp=bothNum?(an-bn):av.localeCompare(bv,"tr");
        return asc?cmp:-cmp;
      });
      rows.forEach(r=>tbody.appendChild(r));
    });
  });
}
document.querySelectorAll(".stat-btn").forEach(btn=>{
  btn.addEventListener("click",()=>{
    statusMode=btn.dataset.stat;
    document.querySelectorAll(".stat-btn").forEach(b=>b.classList.toggle("active",b===btn));
    renderStatus();
  });
});

function renderEntityDefs(mode, name, schoolFilter){
  const container=document.getElementById(mode==="class"?"classDefsList":"teacherDefsList");
  // Okul bazlı sekmede o okul; "Birlikte"/sınıf görünümünde tüm okulların tanımları
  const schools=mode==="class"?[curSchool()]:(schoolFilter?S.schools.filter(s=>s.name===schoolFilter):S.schools.filter(s=>(s.defs||[]).length));
  const placed={};
  for(const sc of schools){ for(const l of sc.lessons||[]){ const k=`${sc.id}|${refKey(l.course,lessonTeachers(l),l.className)}`; placed[k]=(placed[k]||0)+1; } }
  const rows=[];
  for(const sc of schools){
    for(const d of sc.defs||[]){
      const match=mode==="class"?(d.className===name):defTeachers(d).includes(name);
      if(!match) continue;
      const ph=placed[`${sc.id}|${refKey(d.course,defTeachers(d),d.className)}`]||0;
      const cls=ph>=d.hours?"ok":ph>0?"warn":"err";
      const badge=ph>=d.hours?"Tam":ph>0?`${ph}/${d.hours}`:"Bekliyor";
      rows.push(`<tr onclick="toggleDefPanel('${d.id}')" title="Ayarları açılır pencerede düzenle">
        ${mode==="teacher"?`<td>${esc(sc.name)}</td>`:""}
        <td>${esc(d.className)}</td><td><strong>${esc(d.course)}</strong></td>
        <td>${esc(defLabel(d))}</td><td>${d.hours}</td>
        <td><span class="def-badge ${cls}">${badge}</span></td>
        <td>${d.room?`<span class="room-chip">${esc(d.room)}</span>`:""}</td>
      </tr>`);
    }
  }
  if(!rows.length){
    container.innerHTML='<div style="font-size:12px;color:var(--text3);padding:8px 0">Bu '+ (mode==="class"?"sınıfa":"öğretmene") +' tanımlı ders yok.</div>';
    return;
  }
  container.innerHTML='<div class="ed-head">Tanımlı Dersler'+(mode==="teacher"?(schoolFilter?` (${schoolFilter})`:" (tüm okullar)"):"")+' <span style="opacity:.6;font-weight:500;text-transform:none">(satıra tıklayın: ayarlar)</span></div>'+
    `<table class="ed-table"><thead><tr>${mode==="teacher"?"<th>Okul</th>":""}<th>Sınıf</th><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th><th>Derslik</th></tr></thead><tbody>${rows.join("")}</tbody></table>`;
}
// Açılır pencere (modal) ile ders ayarlarını göster; tanım başka okuldaysa o okula geç
function toggleDefPanel(id){
  let d=null, sc=null;
  for(const s of S.schools){ const f=(s.defs||[]).find(x=>x.id===id); if(f){ d=f; sc=s; break; } }
  if(!d) return;
  if(sc&&sc.id!==S.currentSchool){ S.currentSchool=sc.id; saveState(); }
  const body=$("defEditModalBody");
  body.innerHTML=`<div class="ed-panel def-modal" id="edp-${id}">${buildDefPanelHTML(id)}</div>`;
  $("defEditModalTitle").textContent=`${d.course} — ${d.className} (${d.teacher})`;
  $("defEditModal").classList.remove("hidden");
  $("defEditModal").classList.add("open");
}
function closeDefModal(){
  $("defEditModal").classList.remove("open");
  $("defEditModal").classList.add("hidden");
  $("defEditModalBody").innerHTML="";
}
$("defEditModalClose").addEventListener("click",closeDefModal);
$("defEditModal").addEventListener("click",e=>{ if(e.target&&e.target.id==="defEditModal") closeDefModal(); });
document.addEventListener("keydown",e=>{ if(e.key==="Escape"&&!$("defEditModal").classList.contains("hidden")) closeDefModal(); });
function buildDefPanelHTML(id){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return "";
  const sc=curSchool();
  const lessons=sc.lessons.filter(l=>refKey(l.course,lessonTeachers(l),l.className)===refKey(d.course,defTeachers(d),d.className));
  const lessonCells={};
  for(const l of lessons) lessonCells[sk(l.day,l.period)]=l;
  const gridRows=sc.days.map(day=>{
    const cells=[];
    for(let p=1;p<=sc.periods;p++){
      const k=sk(day,p);
      const isLesson=lessonCells[k];
      const isClosed=d.avail&&d.avail[k]===false;
      const cls=isLesson?"av-lesson":isClosed?"av-closed":"av-open";
      const title=isLesson?`Yerleşik (${day} ${p}.s)`:isClosed?`${day} ${p}.s: bu ders için kapalı — tıkla aç`:`${day} ${p}.s: açık — tıkla kapat`;
      cells.push(`<td class="${cls}" title="${title}" data-k="${day}|${p}" onclick="defAvailClick('${id}','${day}',${p})">${isLesson?"X":isClosed?"●":"·"}</td>`);
    }
    return `<tr><td style="font-size:9px;color:var(--text3);font-weight:600;width:16px">${esc(day.slice(0,3))}</td>${cells.join("")}</tr>`;
  }).join("");
  const tOpts=S.teachers.map(t=>`<option value="${esc(t)}" ${t===d.teacher?"selected":""}>${esc(t)}</option>`).join("");
  const extraSel=defTeachers(d).slice(1);
  const tExtraOpts=S.teachers.map(t=>`<option value="${esc(t)}" ${extraSel.includes(t)?"selected":""}>${esc(t)}</option>`).join("");
  const rOpts='<option value="">— (derslik yok)</option>'+(S.rooms||[]).map(r=>`<option value="${esc(r)}" ${r===d.room?"selected":""}>${esc(r)}</option>`).join("");
  const periods=Array.from({length:sc.periods},(_,i)=>`<th>${i+1}</th>`).join("");
  return `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
      <strong style="font-size:12px">Haftalık çizelge</strong>
      <span style="font-size:10px;color:var(--text3)">tıkla: bu ders için açık/kapalı saat</span>
    </div>
    <table class="def-avail-table"><tr><th></th>${periods}</tr>${gridRows}</table>
    <div class="def-fields">
      <label>Ders Adı<input id="df-course-${id}" list="defCourseList" value="${esc(d.course)}" style="width:150px"></label>
      <label>Öğretmen<select id="df-teacher-${id}" style="width:170px">${tOpts}</select></label>
      <label>Ek Öğretmenler<div id="df-extra-${id}" class="xtra-box">${S.teachers.map(t=>`<label class="xtra-row"><input type="checkbox" class="xtra-chk" value="${esc(t)}"${extraSel.includes(t)?" checked":""}><span>${esc(t)}</span></label>`).join("")||'<span style="font-size:11px;color:var(--text3)">Önce öğretmen ekleyin</span>'}</div></label>
      <label>Saat<input id="df-hours-${id}" type="number" min="1" max="40" value="${d.hours}" style="width:56px"></label>
      <label>Blok<select id="df-block-${id}"><option value="1" ${d.block==1?"selected":""}>1</option><option value="2" ${d.block==2?"selected":""}>2</option><option value="3" ${d.block==3?"selected":""}>3</option><option value="4" ${d.block==4?"selected":""}>4</option></select></label>
      <label style="font-size:10px;text-transform:none">Tek blok<input id="df-fixed-${id}" type="checkbox" ${d.blockFixed?"checked":""} style="width:auto;height:auto"></label>
      <label>Derslik<select id="df-room-${id}" style="width:150px">${rOpts}</select></label>
    </div>
    <div class="def-actions">
      <button class="def-save" onclick="saveDefPanel('${id}')">Kaydet</button>
      <button class="def-del" onclick="deleteDefPanel('${id}')">Tanımı Sil</button>
    </div>`;
}
// Bu ders için açık/kapalı saati değiştir (çözücü bu saatleri tanımlı ders için dikkate alır)
function defAvailClick(id,day,p){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return;
  if(!d.avail) d.avail={};
  const k=sk(day,p);
  if(d.avail[k]===false) delete d.avail[k];
  else d.avail[k]=false;
  const cell=document.querySelector(`#edp-${id} td[data-k="${day}|${p}"]`);
  if(cell){
    const isClosed=d.avail[k]===false;
    cell.className=isClosed?"av-closed":"av-open";
    cell.textContent=isClosed?"●":"·";
    cell.title=isClosed?`${day} ${p}.s: bu ders için kapalı — tıkla aç`:`${day} ${p}.s: açık — tıkla kapat`;
  }
  saveState();
}
// Açılır panelden ders tanımını güncelle
function saveDefPanel(id){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return;
  const course=($("df-course-"+id).value||"").trim();
  const teacher=$("df-teacher-"+id).value;
  const extras=extraChecks($("df-extra-"+id));
  const teachers=[teacher,...extras.filter(t=>t&&t!==teacher)];
  const className=d.className;
  const hours=Math.max(1,Number($("df-hours-"+id).value)||1);
  const block=Math.max(1,Number($("df-block-"+id).value)||1);
  const blockFixed=$("df-fixed-"+id).checked;
  const room=$("df-room-"+id).value||null;
  if(!course||!teacher){ toast("Ders adı ve öğretmen gerekli.","err"); return; }
  for(const t of teachers) if(!S.teachers.includes(t)) S.teachers.push(t);
  for(const t of teachers) addTeacherCourse(t,course);
  if(!curSchool().courses.includes(course)) curSchool().courses.push(course);
  // Ders adı/öğretmen değiştiyse bu tanıma ait yerleşmiş dersleri de güncelle (tutarlılık)
  const oldRef=refKey(d.course,defTeachers(d),className);
  for(const l of curSchool().lessons){
    if(refKey(l.course,lessonTeachers(l),l.className)===oldRef){ l.course=course; setTeachers(l,teachers); l.room=room; }
  }
  d.course=course; setTeachers(d,teachers); d.hours=hours; d.block=block; d.blockFixed=blockFixed; d.room=room;
  saveState(); renderDefs(); refresh();
  closeDefModal();
  toast(`"${course}" güncellendi. Yeniden dağıtım gerekebilir.`);
}
function deleteDefPanel(id){
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d) return;
  showConfirm("Ders Tanımını Sil",`"${d.course}" (${d.className}) tanımı ve yerleşmiş dersleri silinsin mi?`,ok=>{
    if(!ok) return;
    curSchool().defs=curSchool().defs.filter(x=>x.id!==id);
curSchool().lessons=curSchool().lessons.filter(l=>refKey(l.course,lessonTeachers(l),l.className)!==refKey(d.course,defTeachers(d),d.className));
    saveState(); refresh();
    closeDefModal();
    toast("Tanım silindi.");
  });
}

/* ============================================================
   DAĞITIM İLERLEME/RAPOR
   ============================================================ */
let lastScheduleOptions={flexibleBlocks:false};
let solveCancelled=false;
let teacherViewMode="birlikte";
let roomViewMode="birlikte";
let statusMode="school";

function waitFrame(){ return new Promise(resolve=>setTimeout(resolve,0)); }

function validateScheduleData(school){
  const errors=[],warnings=[];
  const classSet=new Set(school.classes||[]);
  const courseSet=new Set(school.courses||[]);
  const teacherSet=new Set(S.teachers||[]);
  const seen={};

  (school.defs||[]).forEach((d,i)=>{
    const row=i+1;
    if(!d.course||!String(d.course).trim()) errors.push({title:`${row}. ders: ders adı boş`,body:"Ders tanımında ders adı eksik."});
if(!d.teacher||!String(defLabel(d)).trim()) errors.push({title:`${row}. ders: öğretmen boş`,body:`${d.course||"Ders"} için öğretmen seçilmemiş.`});
    if(!d.className||!String(d.className).trim()) errors.push({title:`${row}. ders: sınıf boş`,body:`${d.course||"Ders"} için sınıf seçilmemiş.`});
    for(const t of defTeachers(d)) if(!teacherSet.has(t)) errors.push({title:`${t}: öğretmen listede yok`,body:`${d.course} / ${d.className} tanımı, öğretmenler listesinde bulunmayan bir öğretmene bağlı.`});
    if(d.className&&!classSet.has(d.className)) errors.push({title:`${d.className}: sınıf listede yok`,body:`${d.course} / ${d.teacher} tanımı, sınıflar listesinde bulunmayan bir sınıfa bağlı.`});
    if(d.course&&courseSet.size&&!courseSet.has(d.course)) warnings.push({title:`${d.course}: ders listede yok`,body:`Bu ders tanımı var ama ders adları listesinde görünmüyor.`});

    const hours=Number(d.hours), block=Number(d.block);
    if(!Number.isFinite(hours)||hours<=0) errors.push({title:`${d.course||row}: saat hatası`,body:"Ders saati 1 veya daha büyük olmalı."});
    if(!Number.isFinite(block)||block<=0) errors.push({title:`${d.course||row}: blok hatası`,body:"Blok değeri 1 veya daha büyük olmalı."});
    if(Number.isFinite(hours)&&Number.isFinite(block)&&block>hours) warnings.push({title:`${d.course}: blok saatten büyük`,body:`${hours} saatlik ders için ${block}'lik blok tanımlı; dağıtım bunu ${hours} saat olarak sınırlar.`});

for(const t of defTeachers(d)){
      if(d.course&&S.teacherCourses&&S.teacherCourses[t]&&S.teacherCourses[t].length&&!S.teacherCourses[t].includes(d.course)){
        warnings.push({title:`${t}: ders eşleşmesi yok`,body:`${t} için ${d.course} dersi öğretmen-ders eşleşmelerinde tanımlı değil.`});
      }
    }

const key=refKey(d.course,defTeachers(d),d.className);
    seen[key]=(seen[key]||0)+1;
  });

  for(const [key,count] of Object.entries(seen)){
    if(count>1){
      const [course,teachers,className]=key.split("|");
      warnings.push({title:`Tekrarlı tanım: ${className} ${course}`,body:`${teachers} için aynı sınıf/ders ${count} kez tanımlanmış. Toplam saatler ayrı ayrı dağıtılır.`});
    }
  }
  return {errors,warnings};
}

// Dağıtım öncesi kapasite/yerleştirilebilirlik kontrolü (sıfır ders yerleştirmeden çalışır).
// Dönen issues: bu koşullarda FİZİKSEL olarak yerleştirilemeyecek dersler (kırmızı, dağıtımı engeller).
function precheckSchedule(school){
  const validation=validateScheduleData(school);
  const days=school.days||SCHOOL_DFLT.days;
  const periods=school.periods||10;
  const sk=(d,p)=>`${d}|${p}`;
  const schoolOpen=(d,p)=>!school.schoolClosed[sk(d,p)];
  const classOpen=(cl,d,p)=>schoolOpen(d,p)&&!((school.classClosed[cl]||{})[sk(d,p)]);
  const teacherOpen=(t,d,p)=>{
    if(!schoolOpen(d,p)) return false;
    if(S.teacherClosed[t]&&S.teacherClosed[t][school.id]&&S.teacherClosed[t][school.id][sk(d,p)]) return false;
    // Diğer okullarda duvar saati olarak çakışan ders var mı
    const ptC=school.periodTimes&&school.periodTimes[p-1];
    if(!ptC) return true;
    const cS=toMin(ptC.start), cE=toMin(ptC.end);
    for(const other of S.schools){
      if(other.id===school.id) continue;
      for(const l of other.lessons||[]){
        if(l.day!==d||!lessonTeachers(l).includes(t)) continue;
        const pt=other.periodTimes&&other.periodTimes[l.period-1];
        if(!pt) continue;
        const oS=toMin(pt.start), oE=toMin(pt.end);
        if(cS<oE&&oS<cE) return false;
      }
    }
    return true;
  };
  const defs=school.defs||[];
  const issues=[];
  if(!defs.length){
    issues.push({type:"Veri",name:"Ders yok",need:0,open:0,extra:0,reason:"Henüz hiç ders tanımlanmamış. Dersler sekmesinden ders ekleyin."});
    return {validation,issues,blocking:true};
  }
  const classNeed={},teacherNeed={},teacherClasses={},pairHours={};
  for(const def of defs){
    const h=Math.max(1,Number(def.hours)||1);
    classNeed[def.className]=(classNeed[def.className]||0)+h;
    for(const t of defTeachers(def)){
      teacherNeed[t]=(teacherNeed[t]||0)+h;
      (teacherClasses[t]=teacherClasses[t]||new Set()).add(def.className);
      const pk=`${t}|${def.className}`;
      pairHours[pk]=(pairHours[pk]||0)+h;
    }
  }
  for(const [name,need] of Object.entries(classNeed)){
    let open=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(classOpen(name,day,p)) open++;
    if(need>open) issues.push({type:"Sınıf",name,need,open,extra:need-open,
      reason:`${name} sınıfının haftalık açık saati ${open}, tanımlı ders saati ${need}. ${need-open} saat bu kapalı saatlerle yerleştirilemez.`});
  }
  for(const [name,need] of Object.entries(teacherNeed)){
    let cap=0;
    for(const day of days){
      let tOpen=0,anyOpen=0;
      for(let p=1;p<=periods;p++){
        if(!teacherOpen(name,day,p)) continue;
        tOpen++;
        for(const cl of teacherClasses[name]){ if(classOpen(cl,day,p)){ anyOpen++; break; } }
      }
      cap+=Math.min(tOpen,anyOpen);
    }
    if(need>cap) issues.push({type:"Öğretmen",name,need,open:cap,extra:need-cap,
      reason:`${name} öğretmeni, kapalı saatler nedeniyle haftada en fazla ${cap} saat ders verebilir; tanımlı ders saati ${need}. ${need-cap} saat yerleştirilemez.`});
  }
  for(const [pk,h] of Object.entries(pairHours)){
    const [t,cl]=pk.split("|");
    let overlap=0;
    for(const day of days) for(let p=1;p<=periods;p++) if(teacherOpen(t,day,p)&&classOpen(cl,day,p)) overlap++;
    if(overlap<h) issues.push({type:"Eşleşme",name:`${t} ↔ ${cl}`,need:h,open:overlap,extra:h-overlap,
      reason:`${t} ile ${cl} arasında ortak açık saat ${overlap}, tanımlı ders ${h} saat. ${h-overlap} saat yerleştirilemez.`});
  }
  // Tek blok (blockFixed) dersler: en az bir gün o kadar ardışık açık saat var mı?
  for(const def of defs){
    if(!def.blockFixed) continue;
    const h=Math.max(1,Number(def.hours)||1);
    let ok=false;
    for(const day of days){
      for(let start=1;start<=periods-h+1;start++){
        let good=true;
        for(let o=0;o<h;o++){ if(!classOpen(def.className,day,start+o)){ good=false; break; } for(const t of defTeachers(def)) if(!teacherOpen(t,day,start+o)){ good=false; break; } }
        if(good){ ok=true; break; }
      }
      if(ok) break;
    }
    if(!ok) issues.push({type:"Blok",name:`${def.className} ${def.course}`,need:h,open:0,extra:h,
      reason:`${def.className} ${def.course} dersi tek blok olarak yerleştirilemiyor (${h} ardışık açık saat bulunmuyor). Bu ders için "Tek blok" işaretini kaldırın veya saatini azaltın.`});
  }
  // Derse özel kapatılan saatler: hiç uygun açık saat kalmadı mı?
  for(const def of defs){
    if(!def.avail) continue;
    const size=def.blockFixed?Math.max(1,Number(def.hours)||1):1;
    let ok=false;
    for(const day of days) for(let start=1;start<=periods-size+1;start++){
      let good=true;
      for(let o=0;o<size;o++){ const p=start+o; if(!classOpen(def.className,day,p)||(def.avail[sk(day,p)]===false)){ good=false; break; } for(const t of defTeachers(def)) if(!teacherOpen(t,day,p)){ good=false; break; } }
      if(good){ ok=true; break; }
    }
    if(!ok) issues.push({type:"Ders",name:`${def.className} ${def.course}`,need:size,open:0,extra:size,
      reason:`${def.className} ${def.course} dersi için bu derse özel kapatılan saatler yüzünden uygun açık saat kalmadı. Açılır panelden kapatılan saatleri açın.`});
  }
  return {validation,issues,blocking:validation.errors.length>0||issues.length>0};
}

function showPrecheck(){
  const school=curSchool();
  const pre=precheckSchedule(school);
  showScheduleOverlay();
  $("scheduleTitle").textContent="Ön Kontrol";
  $("scheduleProgress").style.display="none";
  $("scheduleProgressBar").style.width="100%";
  $("scheduleReport").innerHTML="";
  $("scheduleSaveBtn").style.display="none";
  $("scheduleCloseBtn").textContent="Kapat";
  const startBtn=$("scheduleStartBtn");
  startBtn.style.display="";
  startBtn.disabled=pre.blocking;
  startBtn.title=pre.blocking?"Önce kapasite sorunlarını giderin":"Dağıtımı başlat";

  const defCount=(school.defs||[]).length;
  const parts=[`<div class="schedule-summary">
    <div class="schedule-stat"><strong>${defCount}</strong><span>Ders tanımı</span></div>
    <div class="schedule-stat"><strong>${school.classes.length}</strong><span>Sınıf</span></div>
    <div class="schedule-stat"><strong>${school.days.length}</strong><span>Gün</span></div>
    <div class="schedule-stat"><strong>${school.periods}</strong><span>Saat</span></div>
  </div>`];

  if(pre.validation.errors.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">Düzeltilmesi gereken veri hataları</div>
      <ul class="schedule-list">${pre.validation.errors.map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul></div>`);
  }
  if(pre.issues.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">Yerleştirilemeyecek dersler (${pre.issues.length})</div>
      <ul class="schedule-list">${pre.issues.map(x=>`<li><strong>${esc(x.type)}:</strong> ${esc(x.reason)}</li>`).join("")}</ul></div>`);
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-body">Bu sorunlar giderilmeden dağıtım yapılamaz. Kapalı saatleri açın veya ders/öğretmen saatlerini azaltın, sonra yeniden Dağıt'a basın.</div></div>`);
  }
  if(pre.validation.warnings.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Veri uyarıları</div>
      <ul class="schedule-list">${pre.validation.warnings.slice(0,12).map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul>
      ${pre.validation.warnings.length>12?`<div class="schedule-alert-body">+${pre.validation.warnings.length-12} uyarı daha var.</div>`:""}</div>`);
  }
  if(!pre.blocking){
    parts.push(`<div class="schedule-alert ok"><div class="schedule-alert-title">Ön kontrol geçti</div>
      <div class="schedule-alert-body">Tüm dersler kapasite sınırları içinde görünüyor. Dağıtımı başlatabilirsiniz.</div></div>`);
  }
  $("scheduleReport").innerHTML=parts.join("");

  const qf=$("scheduleQf");
  if(pre.issues.length && (school.defs||[]).length){
    qf.classList.remove("hidden");
    renderQfList(pre.issues);
  }else{
    qf.classList.add("hidden");
    $("scheduleQfList").innerHTML="";
  }
}

// Ön kontrol penceresinde düzeltilebilir dersler: soruna karışan dersleri listele
function qfAffectedDefs(issues){
  const out=[],seen=new Set();
  for(const def of curSchool().defs||[]){
    let hit=false;
    for(const is of issues){
      if(is.type==="Öğretmen"&&defTeachers(def).includes(is.name)) hit=true;
      else if(is.type==="Sınıf"&&def.className===is.name) hit=true;
      else if(is.type==="Eşleşme"&&defTeachers(def).some(t=>`${t}|${def.className}`===is.name)) hit=true;
      if(hit) break;
    }
    if(hit&&!seen.has(def.id)){ seen.add(def.id); out.push(def); }
  }
  return out;
}

function renderQfList(issues){
  const defs=qfAffectedDefs(issues);
  const list=$("scheduleQfList");
  if(!defs.length){
    list.innerHTML='<div class="empty" style="padding:8px;font-size:12px">İlgili ders bulunamadı.</div>';
    return;
  }
  list.innerHTML=defs.map(d=>{
    const teacherOpts=[...S.teachers].sort(trSort).map(t=>
      `<option value="${esc(t)}"${t===d.teacher?" selected":""}>${esc(t)}</option>`).join("");
    return `<div class="qf-row">
      <span class="qf-label" title="${esc(d.course)} — ${esc(d.className)}">${esc(d.course)} &mdash; ${esc(d.className)} (${d.hours}s)</span>
      <select class="qf-teacher" data-id="${d.id}">${teacherOpts}</select>
      <input type="number" class="qf-hours" data-id="${d.id}" min="1" max="12" value="${d.hours}" title="Saat">
      <button class="qf-del btn sm danger" data-id="${d.id}" title="Bu dersi sil">&times;</button>
    </div>`;
  }).join("");
}

function showScheduleOverlay(){
  $("scheduleOverlay").classList.remove("hidden");
  $("scheduleOverlay").classList.add("open");
}

function hideScheduleOverlay(){
  $("scheduleOverlay").classList.remove("open");
  $("scheduleOverlay").classList.add("hidden");
}

/* ─── KISITLAR GÖRÜNÜMÜ ─── */
function renderConstraints(){
  const c=curSchool().constraints=normConstraints(curSchool().constraints);
  $("spreadCourseChk").checked=!!c.spreadCourse;
  $("spreadTeacherChk").checked=!!c.spreadTeacher;
  $("courseGapChk").value=c.courseGap||0;
  $("minBreakChk").value=c.minBreak||0;
  $("requireLunchChk").checked=!!c.requireLunch;
  const opts=[...curSchool().courses].sort(trSort).map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join("");
  $("pairA").innerHTML=opts; $("pairB").innerHTML=opts;
  const list=$("pairList");
  if(!c.coursePairs||!c.coursePairs.length){
    list.innerHTML='<span style="font-size:12px;color:var(--text3)">Henüz çift eklenmedi</span>';
  }else{
    list.innerHTML=c.coursePairs.map((p,i)=>
      `<span class="assign-item">${esc(p.a)} <em style="font-style:normal;opacity:.6">↔</em> ${esc(p.b)}
        <button class="del" data-pair="${i}">&times;</button></span>`).join("");
    list.querySelectorAll(".del").forEach(btn=>{
      btn.addEventListener("click",()=>{
        c.coursePairs.splice(Number(btn.dataset.pair),1);
        saveState();renderConstraints();
      });
    });
  }
}
$("spreadCourseChk").addEventListener("change",e=>{curSchool().constraints.spreadCourse=e.target.checked;saveState();});
$("spreadTeacherChk").addEventListener("change",e=>{curSchool().constraints.spreadTeacher=e.target.checked;saveState();});
$("courseGapChk").addEventListener("change",e=>{
  curSchool().constraints.courseGap=Math.max(0,Math.floor(Number(e.target.value)||0));
  $("courseGapChk").value=curSchool().constraints.courseGap;
  saveState();
  toast(curSchool().constraints.courseGap>0?`Aynı dersin blokları arası en az ${curSchool().constraints.courseGap} saat fark olacak.`:"Aynı ders saat farkı kuralı kapalı.");
});
$("minBreakChk").addEventListener("change",e=>{
  curSchool().constraints.minBreak=Math.max(0,Math.floor(Number(e.target.value)||0));
  $("minBreakChk").value=curSchool().constraints.minBreak;
  saveState();
  toast(curSchool().constraints.minBreak>0?`Dersler arası en az ${curSchool().constraints.minBreak} dk teneffüs şartı açık.`:"Teneffüs şartı kapalı.");
});
$("requireLunchChk").addEventListener("change",e=>{
  curSchool().constraints.requireLunch=e.target.checked;
  saveState();
  toast(e.target.checked?"Her öğretmenin günlük öğle arası şartı açık.":"Öğle arası şartı kapalı.");
});
$("addPairBtn").addEventListener("click",()=>{
  const a=$("pairA").value, b=$("pairB").value;
  if(!a||!b){toast("İki ders seçin.","err");return;}
  if(a===b){toast("Aynı ders çift olamaz.","err");return;}
  const c=curSchool().constraints;
  if(!c.coursePairs) c.coursePairs=[];
  if(c.coursePairs.some(p=>(p.a===a&&p.b===b)||(p.a===b&&p.b===a))){toast("Bu çift zaten var.","err");return;}
  c.coursePairs.push({a,b});
  saveState();renderConstraints();
  toast(`"${a}" ile "${b}" aynı gün olmayacak.`);
});


function showScheduleProgress(text,percent){
  showScheduleOverlay();
  $("scheduleTitle").textContent="Dağıtım yapılıyor";
  $("scheduleProgress").style.display="";
  $("scheduleProgressText").textContent=text;
  $("scheduleProgressBar").style.width=Math.max(0,Math.min(100,percent||0))+"%";
  $("scheduleReport").innerHTML="";
  $("scheduleSaveBtn").style.display="none";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");
  $("scheduleCloseBtn").textContent="Kapat";
}

function groupBlocks(blocks){
  const map={};
for(const b of blocks){
    const tLabel=tLabelArr(b.teachers||[b.teacher]);
    const key=`${b.className}|${b.course}|${tLabel}|${b.reason||""}`;
    if(!map[key]) map[key]={className:b.className,course:b.course,teacher:tLabel,hours:0,count:0,reason:b.reason||""};
    map[key].hours+=b.size||1;
    map[key].count++;
  }
  return Object.values(map).sort((a,b)=>trSort(a.className,b.className)||trSort(a.course,b.course)||trSort(a.teacher,b.teacher));
}

function showScheduleResult(result){
  showScheduleOverlay();
  const failed=result.allFailed||[...(result.forcedFailed||[]),...(result.failed||[])];
  const impossible=result.capacityIssues||[];
  const validationErrors=result.validationErrors||[];
  const validationWarnings=result.validationWarnings||[];
  const softFailed=(result.failed||[]).filter(b=>!(result.forcedFailed||[]).some(f=>f.bid===b.bid));
  const placedHours=result.placedHours||0;
  const totalHours=result.totalHours||0;

  $("scheduleTitle").textContent=validationErrors.length?"Dağıtım başlamadı":failed.length?"Dağıtım raporu":"Dağıtım tamamlandı";
  $("scheduleProgress").style.display="none";
  $("scheduleProgressBar").style.width="100%";

  const summary=`<div class="schedule-summary">
    <div class="schedule-stat"><strong>${placedHours}</strong><span>Yerleşen saat</span></div>
    <div class="schedule-stat"><strong>${Math.max(0,totalHours-placedHours)}</strong><span>Eksik saat</span></div>
    <div class="schedule-stat"><strong>${result.placedBlocks||0}</strong><span>Yerleşen blok</span></div>
    <div class="schedule-stat"><strong>${failed.length+validationErrors.length+validationWarnings.length}</strong><span>Uyarı</span></div>
  </div>`;

  const parts=[summary];
  if(validationErrors.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">Dağıtımdan önce düzeltilmesi gereken hatalar</div>
      <ul class="schedule-list">${validationErrors.map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul></div>`);
  }
  if(validationWarnings.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Veri uyarıları</div>
      <ul class="schedule-list">${validationWarnings.slice(0,12).map(x=>`<li><strong>${esc(x.title)}</strong>: ${esc(x.body)}</li>`).join("")}</ul>
      ${validationWarnings.length>12?`<div class="schedule-alert-body">+${validationWarnings.length-12} uyarı daha var.</div>`:""}</div>`);
  }
  if(!failed.length&&!validationErrors.length){
    parts.push(`<div class="schedule-alert ok"><div class="schedule-alert-title">Tüm dersler yerleşti</div><div class="schedule-alert-body">Belirlenen kapalı saatler ve öğretmen/sınıf çakışmaları korunarak program oluşturuldu.</div></div>`);
  }

  if(impossible.length){
    parts.push(impossible.map(i=>`<div class="schedule-alert danger">
      <div class="schedule-alert-title">${esc(i.name)}: kapasite aşılıyor</div>
      <div class="schedule-alert-body">${i.type} açık saati <strong>${i.open}</strong>, tanımlı ders saati <strong>${i.need}</strong>. En az <strong>${i.extra}</strong> saat bu şartlarda imkansız.</div>
    </div>`).join(""));
  }

  const forced=groupBlocks(result.forcedFailed||[]);
  if(forced.length){
    parts.push(`<div class="schedule-alert danger"><div class="schedule-alert-title">İmkansız olduğu için ayrılan dersler</div>
      <ul class="schedule-list">${forced.map(x=>`<li>${esc(x.className)} ${esc(x.course)} - ${esc(x.teacher)}: ${x.hours} saat (${esc(x.reason)})</li>`).join("")}</ul></div>`);
  }

  const soft=groupBlocks(softFailed);
  if(soft.length){
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Yerleşmeyen ama farklı düzenle denenebilecek dersler</div>
      <div class="schedule-alert-body">Bu dersler kapasite hesabında imkansız görünmüyor; blok düzeni veya yerleşim sırası nedeniyle sıkışmış olabilir.${curSchool().constraints&&curSchool().constraints.spreadCourse?" <strong>Aynı dersin parçaları aynı güne denk gelmesin</strong> kuralı bu veriyle tam yerleşimi engelliyor olabilir — Kısıtlar sekmesinden bu kuralı kapatıp <strong>ders saat farkı</strong> kuralını (örn. 2) deneyin.":""}</div>
      <ul class="schedule-list">${soft.map(x=>`<li>${esc(x.className)} ${esc(x.course)} - ${esc(x.teacher)}: ${x.hours} saat</li>`).join("")}</ul></div>`);
  }

  const cv=result.constraintViolations;
  if(cv && cv.total>0){
    const items=[];
    if(cv.spreadCourseV>0) items.push(`Aynı dersin aynı güne denk geldiği: ${cv.spreadCourseV} saat`);
    if(cv.spreadTeacherV>0) items.push(`Aynı öğretmenin farklı dersi aynı gün: ${cv.spreadTeacherV} saat`);
    if(cv.coursePairV>0) items.push(`Ders çifti aynı gün çakıştı: ${cv.coursePairV} saat`);
    if(cv.courseGapV>0) items.push(`Aynı dersin blokları arasında istenen saat farkı korunamadı: ${cv.courseGapV} saat`);
    if(cv.breakV>0) items.push(`Öğretmen dersleri arasında istenen teneffüs sağlanamadı: ${cv.breakV} dk`);
    if(cv.lunchV>0) items.push(`Öğretmenin günlük öğle arası sağlanamadı: ${cv.lunchV} öğretmen-gün`);
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Kısıt ihlalleri (${cv.total})</div>
      <div class="schedule-alert-body">Belirtilen derslerin tamamı yerleşti; aşağıdaki kısıtlar kısmen sağlanamadı (gün/slot sayısı yetersiz olabilir).</div>
      <ul class="schedule-list">${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`);
  }

  $("scheduleSaveBtn").style.display=validationErrors.length?"none":"";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");

  if(softFailed.length && result.attempts){
    const rounds=result.rounds?`${result.rounds} tam dağıtım turunda `:"";
    parts.push(`<div class="schedule-alert warn"><div class="schedule-alert-title">Maksimum arama sonucu</div><div class="schedule-alert-body">${rounds}${result.attempts} farklı kombinasyon denendi; son uzun aralıkta daha iyi yerleşim bulunamadı. Kalan dersler için kapasiteyi gevşetmek, öğretmen kapalı saatlerini açmak veya blok şartlarını değiştirmek gerekir.</div></div>`);
  }

  // Güvenlik doğrulaması: çizelge kısıtlara uygun mu?
  const verify=verifySchedule();
  if(verify.length){
    parts.push(`<div class="schedule-alert ${failed.length?'danger':'warn'}"><div class="schedule-alert-title">Çizelge doğrulaması — ${verify.length} sorun</div>
      <ul class="schedule-list">${verify.slice(0,20).map(x=>`<li>${esc(x)}</li>`).join("")}${verify.length>20?`<li>+${verify.length-20} sorun daha...</li>`:""}</ul></div>`);
  }

  $("scheduleReport").innerHTML=parts.join("");
  $("scheduleCloseBtn").textContent="Kapat";
}

async function autoSolve(){
  solveCancelled=false;
  showScheduleProgress("Maksimum yerleşim aranıyor...",0);
  let best=null,bestScore=-Infinity,totalAttempts=0,noImproveRounds=0;
  let roundsRun=0;
  const maxRounds=9, plateauRounds=3;
  const solveStart=Date.now();
  for(let round=1;round<=maxRounds;round++){
    roundsRun=round;
    if(Date.now()-solveStart>300000) break;
    showScheduleProgress(`Tur ${round}/${maxRounds}: farklı blok ve saat kombinasyonu deneniyor`,Math.round((round-1)/maxRounds*96));
    await waitFrame();
    if(solveCancelled) break;
    let result;
    try{
      result=await solve({flexibleBlocks:true,silentResult:true});
    }catch(err){
      console.error(err);
      showScheduleProgress("Dağıtım sırasında hata oluştu: "+err.message,0);
      toast("Dağıtım hatası: "+err.message,"err");
      return null;
    }
    if(!result) return null;
    if(result.validationErrors&&result.validationErrors.length){
      showScheduleResult(result);
      return result;
    }
    totalAttempts+=result.attempts||0;
    const score=(result.placedHours||0)*1000-(result.allFailed||[]).length;
    if(!best||score>bestScore){
      best=result; bestScore=score; noImproveRounds=0;
    }else{
      noImproveRounds++;
    }
    if((result.failed||[]).length===0) break;
    if(noImproveRounds>=plateauRounds) break;
  }
  if(best&&best.lessons){
    curSchool().lessons=best.lessons.map(l=>({...l}));
    saveState(); renderDefs(); refresh();
    best.attempts=totalAttempts;
    best.rounds=roundsRun;
    showScheduleResult(best);
    if((best.failed||[]).length===0) toast(`✓ İmkansızlar hariç tüm dersler yerleşti (${best.placedHours} saat).`,"ok");
    else toast(`⚠ Maksimum yerleşim bulundu: ${best.placedHours}/${best.totalHours} saat.`,"err");
  }
  return best;
}

// Tüm okulları doğru sırayla dağıtır; sıra kaynaklı hataları önlemek için iki sırayı deneyip
// en az eksikli olanı seçer. Öğretmenlerin sıralama derdi olmadan hatasız program yapmasını sağlar.
async function distributeAll(){
  const schools=S.schools.filter(s=>(s.defs||[]).length);
  if(!schools.length){toast("Dağıtılacak okul yok.","err");return;}
  for(const sc of schools){
    const pre=precheckSchedule(sc);
    if(pre.blocking){ toast(`${sc.name}: ön kontrol sorunu. ${pre.issues[0]?.reason||""}`,"err"); return; }
  }
  solveCancelled=false;
  showScheduleOverlay();
  const hoursOf=sc=>sc.defs.reduce((s,x)=>s+Math.max(1,Number(x.hours)||1),0);
  // Çapraz okul etkileşimleri (paylaşılan öğretmen/derslik + teneffüs kuralı) nedeniyle
  // tek bir sıralama her zaman yeterli olmayabilir; eksiksiz çözüm bulunana kadar iki sıra da
  // birkaç tur denenir ve en iyisi (tercihen eksiksiz) anlık görüntüyle kaydedilir.
  const snapshot=()=>JSON.parse(JSON.stringify(schools.map(sc=>sc.lessons)));
  const restore=(sn)=>{ schools.forEach((sc,i)=>sc.lessons=sn[i]); };
  let best=null, bestSnap=null;
  const startT=Date.now();
  const maxRounds=5, budget=240000; // en fazla 5 tur / 4 dk
  outer:
  for(let round=0; round<maxRounds && !solveCancelled; round++){
    if(Date.now()-startT>budget) break;
    for(const ord of [schools, [...schools].reverse()]){
      if(solveCancelled) break;
      for(const sc of schools) sc.lessons=[];
      let total=0, failed=0;
      for(const sc of ord){
        if(solveCancelled) break;
        S.currentSchool=sc.id;
        showScheduleProgress(`${sc.name} dağıtılıyor... (tur ${round+1})`,12);
        await waitFrame();
        const r=await solve({flexibleBlocks:true,silentResult:true});
        total+=r.placedHours||0; failed+=(r.allFailed||[]).length;
      }
      if(!best||total-failed*100000>best.total-best.failed*100000){ best={ord,total,failed}; bestSnap=snapshot(); }
      if(failed===0){ break outer; }
    }
  }
  if(!best){ showScheduleOverlay(); $("scheduleTitle").textContent="Dağıtım"; $("scheduleReport").innerHTML='<div class="schedule-alert danger">Dağıtım tamamlanamadı.</div>'; return; }
  if(bestSnap) restore(bestSnap);
  saveState(); renderDefs(); refresh();
  const v=verifySchedule();
  showScheduleOverlay();
  $("scheduleProgress").style.display="none";
  $("scheduleSaveBtn").style.display="";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");
  $("scheduleCloseBtn").textContent="Kapat";
  $("scheduleTitle").textContent=v.length?`Dağıtım — ${v.length} sorun`:"Dağıtım tamamlandı";
  const summary=schools.map(sc=>{
    const placed=(sc.lessons||[]).length, need=hoursOf(sc);
    return `<div class="schedule-stat"><strong>${placed}/${need}</strong><span>${esc(sc.name)}</span></div>`;
  }).join("");
  $("scheduleReport").innerHTML=`<div class="schedule-summary">${summary}</div>`+(v.length
    ? `<div class="schedule-alert danger"><div class="schedule-alert-title">Çizelge doğrulaması — ${v.length} sorun</div><ul class="schedule-list">${v.slice(0,20).map(x=>`<li>${esc(x)}</li>`).join("")}${v.length>20?`<li>+${v.length-20} sorun daha...</li>`:""}</ul></div>`
    : `<div class="schedule-alert ok"><div class="schedule-alert-title">Sorun yok</div><div class="schedule-alert-body">Tüm okullar eksiksiz ve kısıtlara uygun dağıtıldı.</div></div>`);
  toast(v.length?`⚠ ${v.length} sorun — yeniden dağıtın veya raporu inceleyin.`:"✓ Tüm okullar dağıtıldı, doğrulama temiz.","ok");
}

/* ─── LİSTE ÖĞESİ DÜZENLEME ─── */
function setupInlineEdit(containerId, getList, saveFn){
  const container=$(containerId);
  if(!container) return;
  container.addEventListener("dblclick",e=>{
    const btn=e.target.closest(".side-item,.pill-item");
    if(!btn||btn.querySelector("input")||btn.classList.contains("empty")) return;
    // Önce normal click'in refresh'ini bekle
    setTimeout(()=>{
      // Buton hala DOM'da mı?
      if(!document.contains(btn)) return;
      const oldVal=btn.dataset.cl||btn.dataset.tc||btn.dataset.course||(btn.childNodes[0]&&btn.childNodes[0].textContent.trim())||"";
      btn.innerHTML="";
      const input=document.createElement("input");
      input.value=oldVal;
      input.style.cssText="width:100%;border:1px solid var(--blue);border-radius:3px;padding:2px 4px;font:inherit;outline:none";
      btn.appendChild(input);
      input.focus();input.select();
      function done(){
        const newVal=input.value.trim();
        if(newVal&&newVal!==oldVal) saveFn(oldVal,newVal);
        saveState();refresh();
      }
      input.addEventListener("keydown",ev=>{
        if(ev.key==="Enter"){ev.preventDefault();done();}
        if(ev.key==="Escape"){refresh();}
      });
      input.addEventListener("blur",done);
    },50);
    e.stopPropagation();
  });
}

function renderSideLists(){
  const cl=$("classList");
  // Sayaç: yerleşen ders sayısı / açık ders saati kapasitesi (okul seçimine göre)
  const cntCls=(sc,c)=>`${(sc.lessons||[]).filter(l=>l.className===c).length}/${classOpenSlots(sc,c)}`;
  if(S.viewAll){
    const items=[];
    for(const sc of S.schools){ if(!(sc.defs||[]).length) continue; for(const c of [...sc.classes].sort(trSort)){
      const active=(sc.id===S.currentSchool&&sc.selectedClass===c);
      items.push(`<div class="side-item${active?" active":""}" data-cl="${esc(c)}" data-school="${esc(sc.id)}">
        <input type="checkbox" class="si-cb" value="${esc(sc.name)} / ${esc(c)}">
        <span class="si-name">${esc(sc.name)} — ${esc(c)}</span>
        <span class="count" title="Yerleşen / açık saat">${cntCls(sc,c)}</span>
        <span class="si-del" data-del="class:${esc(c)}" data-del-school="${esc(sc.id)}">&times;</span>
      </div>`);
    }}
    cl.innerHTML=items.length?items.join(""):'<div class="empty" style="padding:10px">Henüz sınıf yok</div>';
  }else{
    const sc=curSchool();
    const sortedClasses=[...sc.classes].sort(trSort);
    cl.innerHTML=sc.classes.length
      ? sortedClasses.map(c=>
          `<div class="side-item${sc.selectedClass===c?" active":""}" data-cl="${esc(c)}">
            <input type="checkbox" class="si-cb" value="${esc(c)}">
            <span class="si-name">${esc(c)}</span>
            <span class="count" title="Yerleşen / açık saat">${cntCls(sc,c)}</span>
            <span class="si-del" data-del="class:${esc(c)}">&times;</span>
          </div>`).join("")
      : '<div class="empty" style="padding:10px">Henüz sınıf yok</div>';
  }

  const tl=$("teacherList");
  const sortedTeachers=[...S.teachers].sort(trSort);
  tl.innerHTML=S.teachers.length
    ? sortedTeachers.map(t=>{
        const tSchools=S.viewAll?schoolsWithDefs():[curSchool()];
        let placed=0,cap=0;
        for(const sc of tSchools){
          const cls=new Set();
          for(const d of sc.defs||[]){ if(defTeachers(d).includes(t)) cls.add(d.className); }
          placed+=(sc.lessons||[]).filter(l=>lessonTeachers(l).includes(t)).length;
          if(cls.size) cap+=teacherCap(sc,t,cls);
        }
        const cnt=cap?`${placed}/${cap}`:placed;
        return `<div class="side-item${S.selectedTeacher===t?" active":""}" data-tc="${esc(t)}">
          <input type="checkbox" class="si-cb" value="${esc(t)}">
          <span class="si-name">${esc(t)}</span>
          <span class="count" title="Yerleşen / kapasite">${cnt}</span>
          <span class="si-del" data-del="teacher:${esc(t)}">&times;</span>
        </div>`;
      }).join("")
    : '<div class="empty" style="padding:10px">Henüz öğretmen yok</div>';
}

function renderRoomList(){
  const rl=$("roomList");
  if(!rl) return;
  const sortedRooms=[...(S.rooms||[])].sort(trSort);
  const ref=curSchool();
  const cap=(ref?(ref.days||SCHOOL_DFLT.days).length*(ref.periods||10):50);
  rl.innerHTML=sortedRooms.length
    ? sortedRooms.map(r=>{
        const cnt=S.schools.reduce((s,sc)=>s+(sc.lessons||[]).filter(l=>l.room===r).length,0);
        return `<div class="side-item${S.selectedRoom===r?" active":""}" data-rm="${esc(r)}">
          <input type="checkbox" class="si-cb" value="${esc(r)}">
          <span class="si-name">${esc(r)}</span>
          <span class="count" title="Yerleşen / haftalık kapasite">${cnt}/${cap}</span>
          <span class="si-del" data-del="room:${esc(r)}">&times;</span>
        </div>`;
      }).join("")
    : '<div class="empty" style="padding:10px">Henüz derslik yok</div>';
}

function renderRoomDefs(room, schoolFilter){
  const el=$("roomDefsList");
  if(!el) return;
  // Okul bazlı sekmede o okulun; "Birlikte"de TÜM okulların dersleri tek listede
  const schools=schoolFilter?S.schools.filter(s=>s.name===schoolFilter):S.schools.filter(s=>(s.defs||[]).length);
  el.innerHTML='<div class="ed-head">Bu derslikte tanımlı dersler'+(schoolFilter?` (${schoolFilter})`:" (tüm okullar)")+'</div>';
  const allDefs=[];
  for(const sc of schools){
    for(const d of sc.defs||[]){ if(d.room===room){ const placed=(sc.lessons||[]).filter(l=>l.room===room&&l.course===d.course&&l.className===d.className).length; allDefs.push({d,placed,sc}); } }
  }
  if(!allDefs.length){ el.innerHTML+='<div style="font-size:12px;color:var(--text3);padding:8px 0">Bu derslikte tanımlı ders yok.</div>'; return; }
  el.innerHTML+='<table class="ed-table"><thead><tr><th>Okul</th><th>Sınıf</th><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th></tr></thead><tbody>'+
    allDefs.map(({d,placed,sc})=>{
      const cls=placed>=d.hours?"ok":placed>0?"warn":"err";
      const badge=placed>=d.hours?"Tam":placed>0?`${placed}/${d.hours}`:"Bekliyor";
      return `<tr><td>${esc(sc.name)}</td><td>${esc(d.className)}</td><td><strong>${esc(d.course)}</strong></td><td>${esc(defLabel(d))}</td><td>${d.hours}</td><td><span class="def-badge ${cls}">${badge}</span></td></tr>`;
    }).join("")+'</tbody></table>';
}

// Silme işlemleri (delegasyon)
document.querySelectorAll(".side-list").forEach(list=>{
  list.addEventListener("click",e=>{
    const del=e.target.closest(".si-del");
    if(!del) return;
    e.stopPropagation();
    const [kind, name] = del.dataset.del.split(":");
    if(!kind||!name) return;
    const delFn=()=>{
      if(kind==="class"){
        // TÜMÜ modunda derslik silme: sınıfın ait olduğu okulda işlem yap
        const sc=del.dataset.delSchool?S.schools.find(x=>x.id===del.dataset.delSchool):curSchool();
        if(sc){
          sc.classes=(sc.classes||[]).filter(c=>c!==name);
          sc.defs=(sc.defs||[]).filter(d=>d.className!==name);
          sc.lessons=(sc.lessons||[]).filter(l=>l.className!==name);
          if(sc.classClosed&&sc.classClosed[name]) delete sc.classClosed[name];
          if(sc.selectedClass===name) sc.selectedClass=(sc.classes[0]||null);
        }
      }else if(kind==="teacher"){
        S.teachers=S.teachers.filter(t=>t!==name);
        for(const school of S.schools){
          school.defs=school.defs.filter(d=>!defTeachers(d).includes(name));
          school.lessons=school.lessons.filter(l=>!lessonTeachers(l).includes(name));
        }
        delete S.teacherClosed[name];
        delete S.teacherCourses[name];
        if(S.selectedTeacher===name) S.selectedTeacher=S.teachers[0]||null;
      }else if(kind==="room"){
        S.rooms=S.rooms.filter(r=>r!==name);
        for(const school of S.schools){
          for(const d of school.defs||[]) if(d.room===name) d.room=null;
          for(const l of school.lessons||[]) if(l.room===name) l.room=null;
        }
        if(S.selectedRoom===name) S.selectedRoom=S.rooms[0]||null;
      }
      saveState();refresh();
      toast(`"${name}" silindi.`);
    };
    const msg=kind==="class"?"Bu sınıfı ve tüm ders tanımlarını silsin mi?":kind==="teacher"?"Bu öğretmeni tüm okullardaki dersleriyle birlikte silsin mi?":"Bu dersliği silsin mi? (Bu derslikteki dersler dersliksiz kalır)";
    showConfirm("Sil",msg,ok=>{if(ok)delFn();});
  });
});

// Toplu silme
const bulkMap={delClassesBtn:"classList",delTeachersBtn:"teacherList"};
for(const [btnId,listId] of Object.entries(bulkMap)){
  $(btnId)?.addEventListener("click",()=>{
    const checked=[...$(listId).querySelectorAll(".si-cb:checked")].map(cb=>cb.value);
    if(!checked.length){toast("Seçili öğe yok.","err");return;}
    showConfirm("Toplu Sil",`${checked.length} öğe silinecek.`,ok=>{
      if(!ok) return;
      for(const name of checked){
        if(btnId==="delClassesBtn"){
          // TÜMÜ modunda checkbox değeri "OKUL / SINIF" biçimindedir
          const slash=name.indexOf(" / ");
          const sc=slash>0?S.schools.find(x=>x.name===name.slice(0,slash)):curSchool();
          const cls=slash>0?name.slice(slash+3):name;
          if(sc&&cls){
            sc.classes=(sc.classes||[]).filter(c=>c!==cls);
            sc.defs=(sc.defs||[]).filter(d=>d.className!==cls);
            sc.lessons=(sc.lessons||[]).filter(l=>l.className!==cls);
            if(sc.classClosed&&sc.classClosed[cls]) delete sc.classClosed[cls];
            if(sc.selectedClass===cls) sc.selectedClass=(sc.classes[0]||null);
          }
        }else if(btnId==="delTeachersBtn"){
          S.teachers=S.teachers.filter(t=>t!==name);
          for(const school of S.schools){
            school.defs=school.defs.filter(d=>!defTeachers(d).includes(name));
            school.lessons=school.lessons.filter(l=>!lessonTeachers(l).includes(name));
          }
          delete S.teacherClosed[name];
          delete S.teacherCourses[name];
          if(S.selectedTeacher===name) S.selectedTeacher=S.teachers[0]||null;
        }else if(btnId==="delCoursesBtn"){
          curSchool().courses=curSchool().courses.filter(c=>c!==name);
          curSchool().defs=curSchool().defs.filter(d=>d.course!==name);
          curSchool().lessons=curSchool().lessons.filter(l=>l.course!==name);
          for(const t of Object.keys(S.teacherCourses)) S.teacherCourses[t]=S.teacherCourses[t].filter(c=>c!==name);
        }
      }
      saveState();refresh();
      toast(`${checked.length} öğe silindi.`);
    });
  });
}

// Liste düzenleme kurulumu
setupInlineEdit("classList",()=>curSchool().classes,(oldVal,newVal)=>{
  const idx=curSchool().classes.indexOf(oldVal);
  if(idx>-1){curSchool().classes[idx]=newVal.toUpperCase();curSchool().classes.sort(trSort);}
  // defs ve lessons'daki referansları güncelle
  for(const d of curSchool().defs) if(d.className===oldVal) d.className=newVal.toUpperCase();
  for(const l of curSchool().lessons) if(l.className===oldVal) l.className=newVal.toUpperCase();
  if(curSchool().selectedClass===oldVal) curSchool().selectedClass=newVal.toUpperCase();
  // classClosed'daki anahtarı güncelle
  if(curSchool().classClosed[oldVal]){curSchool().classClosed[newVal.toUpperCase()]=curSchool().classClosed[oldVal];delete curSchool().classClosed[oldVal];}
});
setupInlineEdit("teacherList",()=>S.teachers,(oldVal,newVal)=>{
  const idx=S.teachers.indexOf(oldVal);
  if(idx>-1){S.teachers[idx]=newVal;S.teachers.sort(trSort);}
  for(const school of S.schools){
    for(const d of school.defs){ const i=defTeachers(d).indexOf(oldVal); if(i>-1){ d.teachers[i]=newVal; setTeachers(d,d.teachers); } }
    for(const l of school.lessons){ const i=lessonTeachers(l).indexOf(oldVal); if(i>-1){ l.teachers[i]=newVal; setTeachers(l,l.teachers); } }
  }
  if(S.selectedTeacher===oldVal) S.selectedTeacher=newVal;
  // teacherClosed ve teacherCourses
  if(S.teacherClosed[oldVal]){S.teacherClosed[newVal]=S.teacherClosed[oldVal];delete S.teacherClosed[oldVal];}
  if(S.teacherCourses[oldVal]){S.teacherCourses[newVal]=S.teacherCourses[oldVal];delete S.teacherCourses[oldVal];}
});

/* ============================================================
   DERS ADLARI (branş listesi)
   ============================================================ */
function addCourse(name){
  const n=name.trim();
  if(!n) return false;
  if(!curSchool().courses) curSchool().courses=[];
  if(curSchool().courses.includes(n)) return false;
  curSchool().courses.push(n);
  return true;
}



// Hızlı ders adı ekle
$("addCourseQuickBtn").addEventListener("click",()=>{
  const n=$("addCourseQuick").value.trim();
  if(!n) return;
  if(addCourse(n)){saveState();renderDefs();$("addCourseQuick").value="";toast(`"${n}" eklendi.`);}
  else toast("Zaten var.","err");
});
$("addCourseQuick").addEventListener("keydown",e=>{
  if(e.key==="Enter") $("addCourseQuickBtn").click();
});
// Toplu ders ekle
$("bulkCourseToggleBtn").addEventListener("click",()=>{
  const area=$("bulkCourseArea2");
  area.style.display=area.style.display==="none"?"":"none";
  if(area.style.display!=="none"){$("bulkCourseText2").value="";$("bulkCourseText2").focus();}
});
$("bulkCourseDo2").addEventListener("click",()=>{
  const lines=$("bulkCourseText2").value.split("\n").map(s=>s.trim()).filter(Boolean);
  if(!lines.length)return;
  let added=0;
  for(const l of lines){if(addCourse(l))added++;}
  $("bulkCourseArea2").style.display="none";
  if(added){saveState();renderDefs();toast(`${added} ders eklendi.`);}
  else toast("Hiçbiri eklenemedi.","err");
});

// Ders adı silme (chiplerden)
$("courseChips").addEventListener("click",e=>{
  const del=e.target.closest("[data-del-course]");
  if(!del)return;
  const name=del.dataset.delCourse;
  showConfirm("Sil",`"${name}" dersini ve tüm tanımlarını silsin mi?`,ok=>{
    if(!ok)return;
    curSchool().courses=curSchool().courses.filter(c=>c!==name);
    curSchool().defs=curSchool().defs.filter(d=>d.course!==name);
    curSchool().lessons=curSchool().lessons.filter(l=>l.course!==name);
    for(const t of Object.keys(S.teacherCourses)) S.teacherCourses[t]=S.teacherCourses[t].filter(c=>c!==name);
    saveState();renderDefs();
    toast(`"${name}" silindi.`);
  });
});

/* ============================================================
   ÖĞRETMEN-DERS EŞLEŞTİRME
   ============================================================ */
function getTeacherCourses(t){return S.teacherCourses[t]||[]}
function addTeacherCourse(t,c){
  if(!t||!c)return;
  if(!S.teacherCourses[t])S.teacherCourses[t]=[];
  if(!S.teacherCourses[t].includes(c))S.teacherCourses[t].push(c);
  saveState();
}
function removeTeacherCourse(t,c){
  if(!S.teacherCourses[t])return;
  S.teacherCourses[t]=S.teacherCourses[t].filter(x=>x!==c);
  if(!S.teacherCourses[t].length)delete S.teacherCourses[t];
  saveState();
}

function renderAssignments(){
  const tDl=$("assignTeacherList"),aDl=$("assignCourseList");
  if(tDl) tDl.innerHTML=[...S.teachers].sort(trSort).map(t=>`<option value="${esc(t)}">`).join("");
  if(aDl) aDl.innerHTML=[...curSchool().courses].sort(trSort).map(c=>`<option value="${esc(c)}">`).join("");

  const aL=$("assignList");
  const chips=[];
  for(const t of Object.keys(S.teacherCourses||{}).sort(trSort)){
    for(const c of [...S.teacherCourses[t]].sort(trSort)) chips.push({teacher:t,course:c});
  }
  aL.innerHTML=chips.length
    ? chips.map(({teacher,course})=>
        `<div class="assign-item">
          <span class="ai-t">${esc(teacher)}</span>
          <span class="ai-arrow">&rarr;</span>
          <span class="ai-c">${esc(course)}</span>
          <button class="del" data-atc="${esc(teacher)}" data-acc="${esc(course)}" title="Eşleşmeyi kaldır">&times;</button>
        </div>`
      ).join("")
    : '<div style="font-size:12px;color:var(--text3);padding:8px 0">Henüz eşleştirme yok.</div>';

  aL.querySelectorAll(".del").forEach(btn=>{
    btn.addEventListener("click",()=>{
      removeTeacherCourse(btn.dataset.atc,btn.dataset.acc);
      renderAssignments();
      buildCourseOpts();
    });
  });
}

function getBlockDist(hours, block){
  const max=block||2;
  const dist=[];
  let rem=hours;
  while(rem>0){const sz=Math.min(max,rem);dist.push(sz);rem-=sz;}
  return dist;
}

function updateDefPreview(){
  const courses=[...$("defCourse").selectedOptions].map(o=>o.value);
  const teachers=[...$("defTeacher").selectedOptions].map(o=>o.value);
  const classes=[...$("defClass").selectedOptions].map(o=>o.value);
  const hours=Math.max(1,Number($("defHours").value)||2);
  const block=Number($("defBlock").value)||2;
  const el=$("defPreview");
  if(!courses.length||!teachers.length||!classes.length){
    el.classList.remove("show");
    el.innerHTML="";
    return;
  }
  const fixed=!!$("defBlockFixed").checked;
  const dist=fixed?[hours]:getBlockDist(hours,block);
  const room=$("defRoom")&&$("defRoom").value?$("defRoom").value:null;
  const extras=extraChecks($("defExtra"));
  const parts=[];
  for(const course of courses){
    for(const t of teachers){
      const all=[t,...extras.filter(x=>x!==t)];
      for(const c of classes){
        parts.push(`<span>${esc(course)} <em>&rarr;</em> ${esc(tLabelArr(all))} <em>&rarr;</em> ${esc(c)}${room?` <strong class="room-chip">${esc(room)}</strong>`:""}</span>`);
      }
    }
  }
  el.innerHTML=`<div style="width:100%;font-size:11px;color:var(--text2);margin-bottom:2px">${hours} saat = ${dist.join("+")} blok${fixed?' <strong style="color:var(--blue)">(tek blok, parçalanmaz)</strong>':''} — ${parts.length} kayıt</div>`+parts.join("");
  el.classList.add("show");
}

function filterTeachersByCourse(){
  const course=$("defCourse").value;
  const sel=$("defTeacher");
  if(!course){
    sel.innerHTML=[...S.teachers].sort(trSort).map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join("");
    sel.size=Math.min(Math.max(S.teachers.length,2),15);
    return;
  }
  // Bu dersi veren öğretmenleri bul
  const tSet=new Set();
  for(const [t,courses] of Object.entries(S.teacherCourses||{})){
    if(courses.includes(course)) tSet.add(t);
  }
  const list=tSet.size?[...tSet]:[...S.teachers];
  list.sort(trSort);
  sel.innerHTML=list.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join("");
  const cnt=Math.max(list.length,2);
  sel.size=cnt;
  sel.style.height=Math.min(cnt*20+10,150)+"px";
  sel.style.overflowY="auto";
}

/* ============================================================
   DERS TANIMLAMA
   ============================================================ */
function renderDefs(){
  // Ders adları: düzenli liste (× ile silme)
  const chips=$("courseChips");
  const courses=[...curSchool().courses].sort(trSort);
  chips.innerHTML=courses.length
    ? courses.map(c=>`<div class="course-item"><span>${esc(c)}</span><button class="del" data-del-course="${esc(c)}" title="Bu dersi kaldır">&times;</button></div>`).join("")
    : '<div style="font-size:12px;color:var(--text3);padding:6px 0">Henüz ders eklenmedi.</div>';
  chips.querySelectorAll(".del").forEach(btn=>{
    btn.addEventListener("click",()=>{
      const name=btn.dataset.delCourse;
      curSchool().courses=curSchool().courses.filter(c=>c!==name);
      curSchool().defs=curSchool().defs.filter(d=>d.course!==name);
      curSchool().lessons=curSchool().lessons.filter(l=>l.course!==name);
      for(const t of Object.keys(S.teacherCourses)) S.teacherCourses[t]=S.teacherCourses[t].filter(c=>c!==name);
      saveState();renderDefs();
      toast(`"${name}" dersi kaldırıldı.`);
    });
  });

  // Ders alanı: çoklu seçim listesi
  const cSel=$("defCourse");
  cSel.innerHTML=[...curSchool().courses].sort(trSort).map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
  const cCount=Math.max(curSchool().courses.length,2);
  cSel.size=Math.min(cCount,8);
  cSel.style.height=Math.min(cCount*20+10,150)+"px";
  if(!curSchool().courses.length) cSel.innerHTML='<option value="">Önce ders ekleyin</option>';

  // Öğretmen (multi-select)
  const tSel=$("defTeacher");
  filterTeachersByCourse();
  if(!S.teachers.length) tSel.innerHTML='<option value="">Önce öğretmen ekleyin</option>';

  // Ek öğretmenler (checkbox listesi, istediğin kadar)
  const tExtra=$("defExtra");
  if(tExtra){
    const prev=extraChecks(tExtra);
    renderExtraChecks(tExtra, prev);
  }

  // Sınıf (multi-select)
  const clSel=$("defClass");
  clSel.innerHTML=[...curSchool().classes].sort(trSort).map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
  const clsCount=Math.max(curSchool().classes.length,2);
  clSel.size=clsCount;
  clSel.style.height=Math.min(clsCount*20+10,150)+"px";
  clSel.style.overflowY="auto";
  if(!curSchool().classes.length) clSel.innerHTML='<option value="">Önce sınıf ekleyin</option>';

  // Derslik (opsiyonel)
  const rSel=$("defRoom");
  if(rSel){
    const prev=rSel.value;
    rSel.innerHTML='<option value="">— (derslik yok)</option>'+(S.rooms||[]).sort(trSort).map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join("");
    if(prev) rSel.value=prev;
  }

  renderAssignments();

  // Tanımlı Dersler tablosu (Okul-Sınıf-Ders-Öğretmen-Saat-Durum)
  const listSchools=S.viewAll?schoolsWithDefs():[curSchool()];
  const placed={};
  for(const sc of listSchools){ for(const l of sc.lessons||[]){ const k=`${sc.id}|${refKey(l.course,lessonTeachers(l),l.className)}`; placed[k]=(placed[k]||0)+1; } }

  const total=curSchool().defs.reduce((s,d)=>s+(d.hours||0),0);
  $("defSummary").textContent=curSchool().defs.length?`Toplam ${curSchool().defs.length} ders, ${total} saat`:"";
  $("defSummary").style.marginBottom="10px";

  const list=$("defList");
  const allDefs=[];
  for(const sc of listSchools){ for(const d of sc.defs||[]) allDefs.push({d,sc}); }
  if(!allDefs.length){
    list.innerHTML='<tbody><tr><td colspan="7" style="padding:12px;color:var(--text3)">Henüz ders tanımlanmadı.</td></tr></tbody>';
    return;
  }

  const rows=[...allDefs].sort((a,b)=>trSort(a.d.course,b.d.course)).map(({d,sc})=>{
    const ph=placed[`${sc.id}|${refKey(d.course,defTeachers(d),d.className)}`]||0;
    let badge,bc;
    if(ph>=d.hours){badge="Tam";bc="ok";}
    else if(ph>0){badge=`${ph}/${d.hours}`;bc="warn";}
    else{badge="Bekliyor";bc="err";}
    return `<tr onclick="toggleDefPanel('${d.id}')" title="Ayarları açılır pencerede düzenle">
      <td><input type="checkbox" class="si-cb" value="${d.id}" onclick="event.stopPropagation()"></td>
      <td>${esc(sc.name)}</td>
      <td>${esc(d.className)}</td>
      <td><strong>${esc(d.course)}</strong></td>
      <td>${esc(defLabel(d))}</td>
      <td>${d.hours}${d.blockFixed?' <span style="font-size:10px;color:var(--blue)">tek blok</span>':''}</td>
      <td><span class="def-badge ${bc}">${badge}</span></td>
    </tr>`;
  }).join("");
  list.innerHTML=`<thead><tr><th style="width:24px"></th><th>Okul</th><th>Sınıf</th><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th></tr></thead><tbody>${rows}</tbody>`;
}

/* ============================================================
   BAĞLAM MENÜSÜ
   ============================================================ */
let ctxData=null;
// Ders tanımı düzenleme modu: seçili def'in özellikleri (saat, blok, derslik vb.) güncellenir
let editingDefId=null;
function setEditMode(def){
  editingDefId=def?def.id:null;
  const banner=$("defEditBanner");
  if(banner){
    banner.style.display=editingDefId?"flex":"none";
    if(editingDefId) $("defEditLabel").textContent=`Düzenleniyor: ${def.course} — ${def.className} (${def.teacher})`;
  }
  const btn=$("defSubmitBtn");
  if(btn) btn.textContent=editingDefId?"Değişiklikleri Kaydet":"Ders Ekle";
}
function clearDefForm(){
  $("defCourse").value="";
  $("defHours").value="4";$("defBlock").value="2";$("defBlockFixed").checked=false;
  if($("defRoom")) $("defRoom").value="";
  if($("defExtra")) renderExtraChecks($("defExtra"), []);
  for(const o of $("defTeacher").options) o.selected=false;
  for(const o of $("defClass").options) o.selected=false;
  $("defPreview").classList.remove("show");$("defPreview").innerHTML="";
  setEditMode(null);
}
// Düzenleme modunda öğretmen/sınıf çoklu seçimini tek seçime indir (değişeni tut)
function singleSelectIfEditing(sel){
  if(!editingDefId) return;
  const opts=[...sel.selectedOptions];
  if(opts.length>1){
    for(const o of sel.options) o.selected=false;
    opts[opts.length-1].selected=true;
  }
}

// Dersler sekmesi: 3 büyük butonla panel değiştir
document.querySelectorAll(".ltab").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".ltab").forEach(b=>b.classList.toggle("active",b===btn));
    document.querySelectorAll(".ltab-panel").forEach(p=>p.classList.toggle("active",p.id==="ltab-"+btn.dataset.ltab));
    if(btn.dataset.ltab==="classes") renderClassDefsOverview();
  });
});
// Sınıflara tanımlanan dersler genel görünümü (kart başına sınıf)
function renderClassDefsOverview(){
  const el=$("classDefsOverview");
  if(!el) return;
  const listSchools=S.viewAll?schoolsWithDefs():[curSchool()];
  if(!listSchools.length){ el.innerHTML='<div class="empty">Henüz okul yok.</div>'; return; }
  el.innerHTML='<div class="class-defs-overview">'+listSchools.map(sc=>{
    const placed={};
    for(const l of sc.lessons){ const k=refKey(l.course,lessonTeachers(l),l.className); placed[k]=(placed[k]||0)+1; }
    if(!(sc.classes||[]).length) return '';
    return sc.classes.map(cl=>{
      const defs=(sc.defs||[]).filter(d=>d.className===cl);
      const rows=defs.length?defs.map(d=>{
        const ph=placed[refKey(d.course,defTeachers(d),d.className)]||0;
        const cls=ph>=d.hours?"ok":ph>0?"warn":"err";
        const badge=ph>=d.hours?"Tam":ph>0?`${ph}/${d.hours}`:"Bekliyor";
        return `<tr onclick="toggleDefPanel('${d.id}')" title="Ayarları açılır pencerede düzenle">
          <td><strong>${esc(d.course)}</strong></td>
          <td>${esc(defLabel(d))}</td>
          <td>${d.hours}</td>
          <td><span class="def-badge ${cls}">${badge}</span></td>
          <td>${d.room?`<span class="room-chip">${esc(d.room)}</span>`:""}</td>
        </tr>`;
      }).join(""):'<tr><td colspan="5" style="color:var(--text3);padding:6px 8px">Bu sınıfa tanımlı ders yok</td></tr>';
      return `<div class="cdo-card">
        <div class="cdo-head">${esc(sc.name)} — ${esc(cl)} <span class="count">${defs.length} ders</span></div>
        <table class="ed-table sortable"><thead><tr><th>Ders</th><th>Öğretmen</th><th>Saat</th><th>Durum</th><th>Derslik</th></tr></thead><tbody>${rows}</tbody></table>
      </div>`;
    }).join("");
  }).join("")+'</div>';
  el.querySelectorAll(".ed-table.sortable").forEach(t=>makeSortable(t));
}

function showCtx(e,mode,entity,day,period){
  e.preventDefault();
  ctxData={mode,entity,day,period};

  $("ctxTitle").textContent=`${day} ${period}. saat - ${entity}`;

  const pf=$("ctxPartnerField");
  const ps=$("ctxPartner");ps.innerHTML="";

  if(mode==="class"){
    $("ctxPartnerLabel").textContent="Öğretmen";
    pf.style.display="";
    S.teachers.forEach(t=>{const o=document.createElement("option");o.value=t;o.textContent=t;ps.appendChild(o);});
  }else if(mode==="teacher"){
    $("ctxPartnerLabel").textContent="Sınıf";
    pf.style.display="";
    curSchool().classes.forEach(c=>{const o=document.createElement("option");o.value=c;o.textContent=c;ps.appendChild(o);});
  }

  $("ctxCourseList").innerHTML=curSchool().courses.map(c=>`<option value="${esc(c)}">`).join("");
  $("ctxCourse").value="";

  const m=$("ctxMenu");
  m.style.left=Math.min(e.clientX,window.innerWidth-270)+"px";
  m.style.top=Math.min(e.clientY,window.innerHeight-250)+"px";
  m.classList.remove("hidden");
  $("ctxCourse").focus();
}

function hideCtx(){ $("ctxMenu").classList.add("hidden"); ctxData=null; }

/* ============================================================
   OLAYLAR
   ============================================================ */

// Karanlık mod
function applyBrandIcon(){
  const src=S.darkMode?"icon-dark.svg":"icon.svg";
  const bi=document.querySelector(".brand-icon");
  if(bi) bi.src=src;
  let link=document.querySelector('link[rel="icon"]');
  if(!link){ link=document.createElement("link"); link.rel="icon"; link.type="image/svg+xml"; (document.head||document.documentElement).appendChild(link); }
  link.href=src;
}
if(S.darkMode){document.getElementById("app").classList.add("dark");$("darkModeBtn").innerHTML=`<span class="ms material-symbols-outlined">light_mode</span><span id="darkModeLabel">Aydınlık</span>`;}
applyBrandIcon();
$("darkModeBtn").addEventListener("click",()=>{
  S.darkMode=!S.darkMode;
  document.getElementById("app").classList.toggle("dark",S.darkMode);
  saveState();
  $("darkModeBtn").innerHTML=`<span class="ms material-symbols-outlined">${S.darkMode?"light_mode":"dark_mode"}</span><span id="darkModeLabel">${S.darkMode?"Aydınlık":"Koyu"}</span>`;
  applyBrandIcon();
});

// Okul yönetimi
function populateSchoolSelect(){
  const sel=$("schoolSelect");
  sel.innerHTML=S.schools.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("")+'<option value="__ALL__">TÜMÜ</option>';
  sel.value=S.viewAll?"__ALL__":S.currentSchool;
}
$("schoolSelect").addEventListener("change",()=>{
  const v=$("schoolSelect").value;
  if(v==="__ALL__"){
    S.viewAll=true;
    // TÜMÜ: sınıf/öğretmen/derslik listeleri tüm okulları gösterir; düzenleme son seçilen okulda yapılır
  }else{
    S.viewAll=false;
    S.currentSchool=v;
  }
  saveState();refresh();
});
$("addSchoolBtn").addEventListener("click",()=>{
  showPrompt("Okul Adı","Okul adı",ok=>{
    if(!ok) return;
    const name=$("modalInput").value.trim();
    if(!name) return;
    const id="s"+Date.now().toString(36);
    const school=newSchool(id);
    school.name=name;
    S.schools.push(school);
    S.currentSchool=id;
    saveState();refresh();
    toast(`"${name}" okulu eklendi.`);
  });
});
// Sağ tık menüsünde okul silme yok, basit tutalım

// Navigasyon
document.querySelectorAll(".nav-btn").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".nav-btn").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
    const t=$(`view-${btn.dataset.view}`);
    if(t) t.classList.add("active");
    refresh();
  });
});
// İlk yüklemede okul seçiciyi doldur
populateSchoolSelect();

// Öğretmen görünümü sekmeleri: ORTAOKUL | LİSE | Birlikte
$("teacherTabs").addEventListener("click",e=>{
  const btn=e.target.closest(".tab");
  if(!btn) return;
  teacherViewMode=btn.dataset.tmode;
  document.querySelectorAll("#teacherTabs .tab").forEach(b=>b.classList.toggle("active",b===btn));
  refresh();
});
$("roomTabs")?.addEventListener("click",e=>{
  const btn=e.target.closest(".tab");
  if(!btn) return;
  roomViewMode=btn.dataset.tmode;
  document.querySelectorAll("#roomTabs .tab").forEach(b=>b.classList.toggle("active",b===btn));
  refresh();
});
// Çizelgeyi Doğrula: tüm okulların çizelgesini kısıtlara göre kontrol eder
$("teacherVerifyBtn").addEventListener("click",()=>{
  const v=verifySchedule();
  showScheduleOverlay();
  $("scheduleTitle").textContent=v.length?`Çizelge Doğrulaması — ${v.length} sorun`:"Çizelge Doğrulaması";
  $("scheduleProgress").style.display="none";
  $("scheduleSaveBtn").style.display="none";
  $("scheduleStartBtn").style.display="none";
  $("scheduleQf").classList.add("hidden");
  $("scheduleCloseBtn").textContent="Kapat";
  $("scheduleReport").innerHTML=v.length
    ? `<div class="schedule-alert danger"><div class="schedule-alert-title">${v.length} sorun bulundu</div>
        <ul class="schedule-list">${v.slice(0,30).map(x=>`<li>${esc(x)}</li>`).join("")}${v.length>30?`<li>+${v.length-30} sorun daha...</li>`:""}</ul>
        <div class="schedule-alert-body">Sorunlu çizelge kullanılmamalı; yeniden dağıtım önerilir.</div></div>`
    : `<div class="schedule-alert ok"><div class="schedule-alert-title">Sorun yok</div>
        <div class="schedule-alert-body">Çizelge tüm kısıtlara uygun: çakışma, teneffüs ve öğle arası kontrolleri temiz.</div></div>`;
});

// Okul ayarları
function autoFillTimes(){
  const start=$("startTimeInput")&&$("startTimeInput").value;
  const lessonMin=Math.max(1,Number(($("lessonMinInput")&&$("lessonMinInput").value)||40));
  const breakMin=Math.max(0,Number(($("breakMinInput")&&$("breakMinInput").value)||10));
  const periods=curSchool().periods||10;
  if(!start||!start.includes(":")){ toast("Başlangıç saati girin (örn. 09:00).","err"); return false; }
  const pad=n=>String(n).padStart(2,"0");
  let [h,m]=start.split(":").map(Number);
  if(!Number.isFinite(h)||!Number.isFinite(m)){ toast("Başlangıç saati geçersiz.","err"); return false; }
  const times=[];
  for(let i=0;i<periods;i++){
    const s=`${pad(h)}:${pad(m)}`;
    m+=lessonMin; h+=Math.floor(m/60); m%=60;
    const e=`${pad(h)}:${pad(m)}`;
    times.push({start:s,end:e});
    m+=breakMin; h+=Math.floor(m/60); m%=60;
  }
  curSchool().periodTimes=times;
  return true;
}
$("autoFillTimesBtn").addEventListener("click",()=>{
  if(autoFillTimes()){ saveState(); renderSchoolTimes(); refresh(); toast("Ders saatleri otomatik dolduruldu."); }
});
$("applySchoolBtn").addEventListener("click",()=>{
  const days=$("daysInput").value.split(",").map(s=>s.trim()).filter(Boolean);
  const periods=Math.max(1,Math.min(16,Number($("periodsInput").value)||10));
  curSchool().days=days;curSchool().periods=periods;
  // Ders saatlerini sıfırla (Otomatik Doldur alanları doluysa onları kullan)
  if(!autoFillTimes()) curSchool().periodTimes=defaultPeriodTimes(periods);
  saveState();refresh();
  toast("Okul saatleri güncellendi.");
});

// Sidebar seçim
$("classList").addEventListener("click",e=>{
  if(e.target.closest(".si-cb")||e.target.closest(".si-del")) return;
  const btn=e.target.closest(".side-item");if(!btn)return;
  if(btn.dataset.school) S.currentSchool=btn.dataset.school;
  curSchool().selectedClass=btn.dataset.cl;S.selectedTeacher=null;
  document.querySelectorAll("#teacherList .side-item").forEach(el=>el.classList.remove("active"));
  saveState();refresh();
});
$("teacherList").addEventListener("click",e=>{
  if(e.target.closest(".si-cb")||e.target.closest(".si-del")) return;
  const btn=e.target.closest(".side-item");if(!btn)return;
  S.selectedTeacher=btn.dataset.tc;curSchool().selectedClass=null;
  document.querySelectorAll("#classList .side-item").forEach(el=>el.classList.remove("active"));
  saveState();refresh();
});
$("roomList")?.addEventListener("click",e=>{
  if(e.target.closest(".si-cb")||e.target.closest(".si-del")) return;
  const btn=e.target.closest(".side-item");if(!btn)return;
  S.selectedRoom=btn.dataset.rm;
  saveState();refresh();
});

// Ekleme
function addSingleClass(name){
  const c=name.toUpperCase();
  if(!c) return false;
  if(!curSchool().classes) curSchool().classes=[];
  if(curSchool().classes.includes(c)) return false;
  curSchool().classes.push(c);return true;
}
function addSingleTeacher(name){
  if(!name) return false;
  if(!S.teachers) S.teachers=[];
  if(S.teachers.includes(name)) return false;
  S.teachers.push(name);return true;
}
function addSingleRoom(name){
  const r=name.trim().toUpperCase();
  if(!r) return false;
  if(!S.rooms) S.rooms=[];
  if(S.rooms.includes(r)) return false;
  S.rooms.push(r);return true;
}

$("addClassBtn").addEventListener("click",()=>{
  showPrompt("Sınıf Ekle","Sınıf adı", ok=>{
    if(!ok) return;
    const c=$("modalInput").value.trim();
    if(!c) return;
    if(addSingleClass(c)){curSchool().selectedClass=c.toUpperCase();saveState();refresh();toast("Sınıf eklendi.");}
    else toast("Zaten var veya geçersiz.","err");
  });
});
function setupBulkAdd(btnId, areaId, textId, doId, addFn, mode){
  const btn=$(btnId), area=$(areaId), text=$(textId), doBtn=$(doId);
  if(!btn||!area||!text||!doBtn)return;
  btn.addEventListener("click",()=>{
    const h=area.style.display;
    area.style.display=h==="none"?"":"none";
    if(area.style.display!=="none"){text.value="";text.focus();}
  });
  doBtn.addEventListener("click",()=>{
    const lines=text.value.split("\n").map(s=>s.trim()).filter(Boolean);
    if(!lines.length)return;
    let added=0;
    for(const l of lines){if(addFn(l))added++;}
    area.style.display="none";
    if(added){
      if(mode==="class") curSchool().selectedClass=lines[0].toUpperCase();
      if(mode==="teacher") S.selectedTeacher=lines[0];
      saveState();refresh();toast(`${added} eklendi.`);
    }else toast("Hiçbiri eklenemedi.","err");
  });
}
setupBulkAdd("bulkClassBtn","bulkClassArea","bulkClassText","bulkClassDo",n=>addSingleClass(n),"class");
setupBulkAdd("bulkTeacherBtn","bulkTeacherArea","bulkTeacherText","bulkTeacherDo",n=>addSingleTeacher(n),"teacher");
setupBulkAdd("bulkRoomBtn","bulkRoomArea","bulkRoomText","bulkRoomDo",n=>addSingleRoom(n),"room");

$("addRoomBtn")?.addEventListener("click",()=>{
  showPrompt("Derslik Ekle","Derslik adı (örn. Bilgisayar Laboratuvarı)", ok=>{
    if(!ok) return;
    const r=$("modalInput").value.trim();
    if(!r) return;
    if(addSingleRoom(r)){S.selectedRoom=r.trim().toUpperCase();saveState();refresh();toast("Derslik eklendi.");}
    else toast("Zaten var veya geçersiz.","err");
  });
});
$("delRoomsBtn")?.addEventListener("click",()=>{
  const checked=[...($("roomList")?.querySelectorAll(".si-cb:checked")||[])].map(cb=>cb.value);
  if(!checked.length){toast("Seçili derslik yok.","err");return;}
  showConfirm("Derslikleri Sil",`${checked.length} derslik silinecek.`,ok=>{
    if(!ok) return;
    for(const name of checked){
      S.rooms=S.rooms.filter(r=>r!==name);
      for(const school of S.schools){
        for(const d of school.defs||[]) if(d.room===name) d.room=null;
        for(const l of school.lessons||[]) if(l.room===name) l.room=null;
      }
    }
    if(S.selectedRoom&&!S.rooms.includes(S.selectedRoom)) S.selectedRoom=S.rooms[0]||null;
    saveState();refresh();
    toast(`${checked.length} derslik silindi.`);
  });
});

$("addTeacherBtn").addEventListener("click",()=>{
  showPrompt("Öğretmen Ekle","Öğretmen adı", ok=>{
    if(!ok) return;
    const t=$("modalInput").value.trim();
    if(!t) return;
    if(addSingleTeacher(t)){S.selectedTeacher=t;saveState();refresh();toast("Öğretmen eklendi.");}
    else toast("Zaten var veya geçersiz.","err");
  });
});


// Öğretmen-Ders eşleştirme
$("assignBtn").addEventListener("click",()=>{
  const t=($("assignTeacher").value||"").trim();
  const c=($("assignCourse").value||"").trim();
  if(!t||!c){toast("Öğretmen ve ders seçin (veya yazın).","err");return;}
  if(!S.teachers.includes(t)) S.teachers.push(t);
  addTeacherCourse(t,c);
  if(!curSchool().courses.includes(c)) curSchool().courses.push(c);
  renderAssignments();
  $("assignCourse").value="";
  $("assignTeacher").value="";
  toast(`"${t}" → "${c}" eşleştirildi.`);
});
$("defCourse").addEventListener("change",()=>{filterTeachersByCourse();updateDefPreview();});
$("defCourse").addEventListener("input",updateDefPreview);
$("defHours").addEventListener("input",updateDefPreview);
$("defBlock").addEventListener("change",updateDefPreview);
// Multi-select değişikliklerinde önizleme güncelle (change + click ile)
$("defTeacher").addEventListener("change",()=>{singleSelectIfEditing($("defTeacher"));updateDefPreview();});
$("defTeacher").addEventListener("click",()=>setTimeout(updateDefPreview,30));
$("defExtra")?.addEventListener("change",updateDefPreview);
$("defExtra")?.addEventListener("click",()=>setTimeout(updateDefPreview,30));
$("defClass").addEventListener("change",()=>{singleSelectIfEditing($("defClass"));updateDefPreview();});
$("defClass").addEventListener("click",()=>setTimeout(updateDefPreview,30));

// Ders tanımlama / düzenleme
function submitDefForm(){
  try{
    const courses=[...$("defCourse").selectedOptions].map(o=>o.value).filter(Boolean);
    const teachers=[...$("defTeacher").selectedOptions].map(o=>o.value);
    const classes=[...$("defClass").selectedOptions].map(o=>o.value);
    const extras=extraChecks($("defExtra"));
    const hours=Math.max(1,Number($("defHours").value)||2);
    const block=Number($("defBlock").value);
    const blockFixed=!!$("defBlockFixed").checked;
    const room=$("defRoom")&&$("defRoom").value?$("defRoom").value:null;

    if(!courses.length||!teachers.length||!classes.length){toast("Lütfen en az bir ders, öğretmen ve sınıf seçin.","err");return;}

    // Düzenleme modu: seçili def'in özelliklerini güncelle (yeni def EKLEME)
    if(editingDefId){
      const d=curSchool().defs.find(x=>x.id===editingDefId);
      if(d){
        const course=courses[0], t=teachers[0], c=classes[0];
        const tList=[t,...extras.filter(x=>x&&x!==t)];
        const dup=curSchool().defs.find(x=>x.id!==d.id&&refKey(x.course,defTeachers(x),x.className)===refKey(course,tList,c));
        if(dup){ toast("Bu ders/öğretmenler/sınıf için zaten bir tanım var.","err"); return; }
        const oldRef=refKey(d.course,defTeachers(d),d.className);
        d.course=course; setTeachers(d,tList); d.className=c; d.hours=hours; d.block=block; d.blockFixed=blockFixed; d.room=room;
        // Ders adı/öğretmen değiştiyse bu tanıma ait yerleşmiş dersleri de güncelle (tutarlılık)
        for(const l of curSchool().lessons){
          if(refKey(l.course,lessonTeachers(l),l.className)===oldRef){ l.course=course; setTeachers(l,tList); l.room=room; }
        }
        if(!curSchool().courses.includes(course)) curSchool().courses.push(course);
        for(const t2 of tList){
          if(!S.teachers.includes(t2)) S.teachers.push(t2);
          addTeacherCourse(t2,course);
        }
        saveState();renderDefs();refresh();
        toast(`"${course}" güncellendi. Yeniden dağıtım gerekebilir.`);
        clearDefForm();
        return;
      }
    }

    // Yeni ders oluşturma (ders × öğretmen × sınıf matrisi; her tanıma ek öğretmenler eklenir)
    for(const course of courses){ if(!curSchool().courses.includes(course)) curSchool().courses.push(course); }
    const allT=[...new Set([...teachers,...extras])];
    for(const t2 of allT) if(!S.teachers.includes(t2)) S.teachers.push(t2);
    let count=0;
    for(const course of courses){
      for(const t of teachers){
        for(const c of classes){
          if(!curSchool().defs) curSchool().defs=[];
          curSchool().defs.push(setTeachers({id:uid(),course,className:c,hours,block,blockFixed,room},[t,...extras.filter(x=>x&&x!==t)]));
          for(const t2 of [t,...extras.filter(x=>x&&x!==t)]) addTeacherCourse(t2,course);
          count++;
        }
      }
    }
    clearDefForm();
    saveState();renderDefs();
    toast(`${count} ders tanımlandı.`);
  }catch(err){
    toast("Hata: "+err.message,"err");
  }
}
$("defSubmitBtn").addEventListener("click",submitDefForm);
$("defEditCancel").addEventListener("click",()=>{clearDefForm();renderDefs();toast("Düzenleme iptal edildi.");});
$("delDefsBtn").addEventListener("click",()=>{
  const sel=[...document.querySelectorAll("#defList input:checked")].map(i=>i.value);
  if(!sel.length){toast("Seçili ders yok.","err");return;}
  curSchool().defs=curSchool().defs.filter(d=>!sel.includes(d.id));
  curSchool().lessons=curSchool().lessons.filter(l=>curSchool().defs.some(d=>refKey(d.course,defTeachers(d),d.className)===refKey(l.course,lessonTeachers(l),l.className)));
  saveState();renderDefs();refresh();
  toast(`${sel.length} ders silindi.`);
});
$("defList").addEventListener("dblclick",e=>{
  const item=e.target.closest("tr");
  if(!item)return;
  const cb=item.querySelector(".si-cb");
  const id=cb?cb.value:null;
  if(!id)return;
  const d=curSchool().defs.find(x=>x.id===id);
  if(!d)return;
  // Formu düzenleme modunda doldur (def silinmez; "Değişiklikleri Kaydet" ile güncellenir)
  for(const o of $("defCourse").options) o.selected=(o.value===d.course);
  for(const o of $("defTeacher").options) o.selected=(o.value===d.teacher);
  for(const o of $("defClass").options) o.selected=(o.value===d.className);
  const ev=new Event("change",{bubbles:true});
  $("defCourse").dispatchEvent(ev);
  $("defTeacher").dispatchEvent(ev);
  $("defClass").dispatchEvent(ev);
  $("defHours").value=d.hours;$("defBlock").value=d.block;
  $("defBlockFixed").checked=!!d.blockFixed;
  if($("defRoom")) $("defRoom").value=d.room||"";
  const exSel=defTeachers(d).slice(1);
  if($("defExtra")) renderExtraChecks($("defExtra"), exSel);
  if($("defExtra")) $("defExtra").dispatchEvent(new Event("change",{bubbles:true}));
  setEditMode(d);
  updateDefPreview();
  $("defForm").scrollIntoView({behavior:"smooth",block:"nearest"});
});

/* ─── DERS SAAT AYARLARI ─── */
function defaultPeriodTimes(n){
  const times=[];
  let h=9,m=0;
  for(let i=0;i<n;i++){
    const start=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
    m+=40;
    if(m>=60){h+=Math.floor(m/60);m=m%60;}
    const end=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
    times.push({start,end});
    m+=10; // teneffüs
    if(m>=60){h+=Math.floor(m/60);m=m%60;}
  }
  return times;
}

function renderSchoolTimes(){
  const grid=$("timeGrid");
  // periodTimes'i güncelle
  if(!curSchool().periodTimes||curSchool().periodTimes.length!==curSchool().periods){
    curSchool().periodTimes=defaultPeriodTimes(curSchool().periods);
    saveState();
  }
  let html='';
  for(let i=0;i<curSchool().periods;i++){
    const t=curSchool().periodTimes[i]||{start:"",end:""};
    html+=`<div class="pt-row">
      <label>${i+1}.</label>
      <div class="pt-times">
        <input type="time" class="pt-start" data-idx="${i}" value="${t.start}">
        <span class="pt-sep">—</span>
        <input type="time" class="pt-end" data-idx="${i}" value="${t.end}">
      </div>
    </div>`;
  }
  grid.innerHTML=html;
}

$("saveTimesBtn").addEventListener("click",()=>{
  const times=[];
  const starts=document.querySelectorAll(".pt-start");
  const ends=document.querySelectorAll(".pt-end");
  for(let i=0;i<curSchool().periods;i++){
    times.push({start:starts[i].value,end:ends[i].value});
  }
  curSchool().periodTimes=times;
  saveState();
  // Grid başlıklarını güncelle (tüm görünümler)
  if(document.querySelector(".nav-btn.active")?.dataset.view==="school") refresh();
  toast("Ders saatleri kaydedildi.");
});

// Grid tıklama (okul: kapat → öğle arası → aç döngüsü)
$("schoolGrid").addEventListener("click",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c)return;
  cycleSchoolCell(c.dataset.day,Number(c.dataset.period));refresh();
});
$("classGrid").addEventListener("click",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!curSchool().selectedClass)return;
  toggleClass(curSchool().selectedClass,c.dataset.day,Number(c.dataset.period));refresh();
});
$("teacherGrid").addEventListener("click",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!S.selectedTeacher)return;
  toggleTeacher(S.selectedTeacher,c.dataset.day,Number(c.dataset.period));refresh();
});

// Grid sağ tık — sadece sınıf/öğretmen görünümünde ders eklenir
$("schoolGrid").addEventListener("contextmenu",e=>{
  const c=e.target.closest(".grid-cell");if(!c)return;
  if(c.classList.contains("lesson")){toast("Burada zaten ders var. Silmek için × butonunu kullanın.","err");return;}
  toast("Ders eklemek için Sınıflar veya Öğretmenler görünümüne geçin.","");
  e.preventDefault();
});
$("classGrid").addEventListener("contextmenu",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!curSchool().selectedClass)return;
  const d=c.dataset.day,p=Number(c.dataset.period);
  if(!classOpen(curSchool().selectedClass,d,p)){toast("Sınıf saati kapalı.","err");return;}
  showCtx(e,"class",curSchool().selectedClass,d,p);
});
$("teacherGrid").addEventListener("contextmenu",e=>{
  const c=e.target.closest(".grid-cell:not(.lesson)");if(!c||!S.selectedTeacher)return;
  const d=c.dataset.day,p=Number(c.dataset.period);
  if(!teacherOpen(S.selectedTeacher,d,p)){toast("Öğretmen saati kapalı.","err");return;}
  showCtx(e,"teacher",S.selectedTeacher,d,p);
});

// Bağlam menüsü
$("ctxCancel").addEventListener("click",hideCtx);
$("ctxSave").addEventListener("click",()=>{
  if(!ctxData) return;
  const course=$("ctxCourse").value.trim();if(!course){toast("Ders adı girin.","err");return;}
  const block=Number($("ctxBlock").value);
  const partner=$("ctxPartner").value;
  if(!partner){toast("Lütfen seçim yapın.","err");return;}

  let teacher,className;
  if(ctxData.mode==="class"){className=ctxData.entity;teacher=partner;}
  else {teacher=ctxData.entity;className=partner;}

  if(!teacher||!className){toast("Eksik bilgi.","err");return;}
  const ok=addLesson(course,teacher,className,ctxData.day,ctxData.period,block);
  if(!ok){toast("Bu saatte çakışma var veya slot kapalı.","err");return;}
  // Aynı ders defs'te yoksa ekle
  if(!curSchool().defs.some(d=>refKey(d.course,defTeachers(d),d.className)===refKey(course,[teacher],className))){
    curSchool().defs.push({id:uid(),course,teacher,className,hours:block,block});
    saveState();
  }
  hideCtx();refresh();
  toast(`"${course}" eklendi.`);
});

document.addEventListener("click",e=>{if(!e.target.closest("#ctxMenu"))hideCtx();});

// Örnek veri
$("sampleBtn").addEventListener("click",()=>{
  curSchool().classes=["9A","9B","10A","11SAY","12EA"];
  S.teachers=["Ali Yılmaz","Ayşe Demir","Mehmet Kaya","Fatma Şahin","Mustafa Çelik","Zeynep Aydın","Ahmet Koç","Elif Arslan"];
  curSchool().schoolClosed={};curSchool().classClosed={};S.teacherClosed={};curSchool().lessons=[];curSchool().defs=[];S.teacherCourses={};
  curSchool().courses=["Matematik","Türk Dili","Fizik","Kimya","Biyoloji","Edebiyat","Coğrafya"];
  S.rooms=["FEN LABORATUVARI","BİLGİSAYAR LABORATUVARI"];
  curSchool().selectedClass="9A";S.selectedTeacher=null;S.selectedRoom=null;

  // Örnek öğretmen-ders eşleştirmeleri
  const tcMap={
    "Ali Yılmaz":["Matematik"],
    "Ayşe Demir":["Türk Dili","Edebiyat"],
    "Mehmet Kaya":["Fizik"],
    "Fatma Şahin":["Kimya"],
    "Mustafa Çelik":["Matematik"],
    "Zeynep Aydın":["Edebiyat"],
    "Ahmet Koç":["Coğrafya"],
    "Elif Arslan":["Biyoloji"]
  };
  for(const [t,cs] of Object.entries(tcMap)) S.teacherCourses[t]=cs;

  // Örnek ders tanımları
  const sampleDefs=[
    ["Matematik","Ali Yılmaz","9A",6,2],
    ["Türk Dili","Ayşe Demir","9A",5,2],
    ["Fizik","Mehmet Kaya","9A",4,2,null,"FEN LABORATUVARI"],
    ["Kimya","Fatma Şahin","9A",4,2,null,"FEN LABORATUVARI"],
    ["Matematik","Ali Yılmaz","10A",6,2],
    ["Türk Dili","Ayşe Demir","10A",5,2],
    ["Biyoloji","Elif Arslan","10A",4,2,null,"FEN LABORATUVARI"],
    ["Matematik","Mustafa Çelik","11SAY",6,2],
    ["Fizik","Mehmet Kaya","11SAY",4,2,null,"FEN LABORATUVARI"],
    ["Kimya","Fatma Şahin","11SAY",4,2,null,"FEN LABORATUVARI"],
    ["Matematik","Mustafa Çelik","12SAY",6,2],
    ["Fizik","Mehmet Kaya","12SAY",4,2,null,"FEN LABORATUVARI"],
    ["Türk Dili","Ayşe Demir","12EA",5,2],
    ["Edebiyat","Zeynep Aydın","11EA",5,2],
    ["Coğrafya","Ahmet Koç","11EA",4,2]
  ];
  for(const [c,t,cl,h,b,unused,room] of sampleDefs){
    const def={id:uid(),course:c,teacher:t,className:cl,hours:h,block:b};
    if(room) def.room=room;
    curSchool().defs.push(def);
  }
  saveState();refresh();
  toast("Örnek veri yüklendi. Dersler sekmesini inceleyin, sonra Dağıt'a basın.");
});

function downloadState(){
  const b=new Blob([JSON.stringify(S,null,2)],{type:"application/json"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(b);a.download="planla.json";a.click();
  URL.revokeObjectURL(b);
  toast("Kaydedildi.");
}

// Kaydet/Aç
$("saveBtn").addEventListener("click",downloadState);
$("openFile").addEventListener("change",async e=>{
  const f=e.target.files[0];if(!f)return;
  try{Object.assign(S,JSON.parse(await f.text()));saveState();refresh();toast("Açıldı.");}
  catch{toast("Geçersiz dosya.","err");}
  try{
    const v=verifySchedule();
    if(v.length) toast(`⚠ Çizelgede ${v.length} sorun bulundu (ör. ${v.slice(0,2).join("; ")}). Yeniden dağıtın.`,"err");
    else toast("Çizelge doğrulaması: sorun yok.");
  }catch{}
  e.target.value="";
});

// Dağıt (önce ön kontrol)
$("scheduleBtn").addEventListener("click",()=>{
  lastScheduleOptions={flexibleBlocks:true};
  showPrecheck();
});
$("distributeAllBtn").addEventListener("click",()=>{
  lastScheduleOptions={flexibleBlocks:true};
  distributeAll();
});
// Mevcut dağıtımı sil (tüm okulların yerleşmiş derslerini temizler)
$("clearDistBtn").addEventListener("click",()=>{
  showConfirm("Dağıtımı Sil","Tüm okullardaki yerleştirilmiş dersler silinecek. Devam edilsin mi?",ok=>{
    if(!ok) return;
    for(const sc of S.schools) sc.lessons=[];
    saveState(); renderDefs(); refresh();
    toast("Mevcut dağıtım silindi. Yeniden dağıtabilirsiniz.");
  });
});

// Aktif görünüm bağlamı (PDF/Excel başlığı için)
function exportContextLabel(){
  const mode=document.querySelector(".nav-btn.active")?.dataset.view||"school";
  if(mode==="class") return curSchool().selectedClass?`Sınıf: ${curSchool().selectedClass}`:"";
  if(mode==="teacher") return S.selectedTeacher?`Öğretmen: ${S.selectedTeacher}`:"";
  if(mode==="rooms") return S.selectedRoom?`Derslik: ${S.selectedRoom}`:"";
  return "Okul Saatleri";
}
function scopeLabel(scope){
  return {single:"Çizelge",classes:"Tüm Sınıflar",teachers:"Tüm Öğretmenler",rooms:"Tüm Derslikler",classTeacher:"Sınıflar+Öğretmenler",all:"Tüm Okullar"}[scope]||"Çizelge";
}
// Bir sınıfın çizelge tablosunu döndürür
// Bir tablo DOM'undan satırları (colspan açılarak) dizi olarak çıkarır
function cellToText(td){
  let s=td.innerHTML||"";
  if(!s) return "";
  s=s.replace(/<br\s*\/?>/gi,"\n").replace(/<\/(?:div|p|tr|h[1-6])>/gi,"\n").replace(/<[^>]+>/g,"")
    .replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&lt;/gi,"<").replace(/&gt;/gi,">").replace(/&quot;/gi,'"').replace(/&#39;/gi,"'");
  return s.replace(/[ \t]+/g," ").replace(/ *\n */g,"\n").replace(/\n{2,}/g,"\n").trim();
}
function tableToRows(tbl){
  const rows=[];
  for(const tr of tbl.querySelectorAll("tr")){
    const cells=[];
    for(const td of tr.querySelectorAll("th,td")){
      const span=td.colSpan||1;
      cells.push({v:cellToText(td), cls:td.className||"", span});
      for(let i=1;i<span;i++) cells.push({v:"",cls:"",span:0});
    }
    rows.push(cells);
  }
  return rows;
}
function xmlEsc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function buildClassSheet(sc,cl){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderGrid(tmp,"class",cl,sc);
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  // Alt tablo: Ders-Öğretmen-Saat + toplam
  const subRows=[["Ders","Öğretmen","Saat"]];
  let total=0;
  for(const d of sc.defs||[]){ if(d.className!==cl) continue; const h=Math.max(1,Number(d.hours)||1); subRows.push([String(d.course),String(defLabel(d)),String(h)]); total+=h; }
  subRows.push(["TOPLAM","",String(total)]);
  return {title:`${sc.name} — ${cl}`, tableHTML:html, rows, subRows};
}
// Bir öğretmenin birleşik (tüm okullar) çizelgesini döndürür
function buildTeacherSheet(t){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderTeacherCombined(tmp,t,"teacher");
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  // Alt tablo: Ders-Sınıf-Saat + toplam
  const subRows=[["Ders","Sınıf","Saat"]];
  let total=0;
  for(const sc of schoolsWithDefs()){ for(const d of sc.defs||[]){ if(!defTeachers(d).includes(t)) continue; const h=Math.max(1,Number(d.hours)||1); subRows.push([String(d.course),String(d.className),String(h)]); total+=h; } }
  subRows.push(["TOPLAM","",String(total)]);
  return {title:t, tableHTML:html, rows, subRows, wide:true};
}
function buildRoomSheet(r){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderTeacherCombined(tmp,r,"room");
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  return {title:`Derslik: ${r}`, tableHTML:html, rows, wide:true};
}
// Bir okulun ders listesi (Ders Adı + Öğretmen + Sınıf + Saat + Derslik) — çıktıların altına eklenir
function buildLessonListSheet(sc){
  const head=["Ders Adı","Öğretmen","Sınıf","Saat","Derslik"];
  const rows=[head.map(h=>({v:h,cls:""}))];
  for(const d of sc.defs||[]){
    rows.push([
      {v:String(d.course||""),cls:""},
      {v:String(defLabel(d)),cls:""},
      {v:String(d.className||""),cls:""},
      {v:String(Math.max(1,Number(d.hours)||1)),cls:""},
      {v:d.room?String(d.room):"",cls:""}
    ]);
  }
  const thead=rows[0].map(c=>`<th>${esc(c.v)}</th>`).join("");
  const tbody=rows.slice(1).map(r=>`<tr>${r.map(c=>`<td>${esc(c.v)}</td>`).join("")}</tr>`).join("");
  return {title:`${sc.name} — Ders Listesi`, tableHTML:`<table class="pa-list"><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table>`, rows};
}
function schoolsWithDefs(){ return S.schools.filter(s=>(s.defs||[]).length); }
// Aktif görünümün tek çizelgesini döndürür
function buildSingleSheet(){
  const mode=document.querySelector(".nav-btn.active")?.dataset.view||"school";
  let gridId="",title="";
  if(mode==="school"){ gridId="schoolGrid"; title=`${curSchool().name} — Okul Saatleri`; }
  else if(mode==="class"){ gridId="classGrid"; title=`${curSchool().name} — ${curSchool().selectedClass||"Sınıf"}`; }
  else if(mode==="teacher"){ gridId="teacherGrid"; title=`${curSchool().name} — ${S.selectedTeacher||"Öğretmen"}`; }
  else if(mode==="rooms"){ gridId="roomGrid"; title=`Derslik: ${S.selectedRoom||"Derslik"}`; }
  else return null;
  const tbl=$(gridId)&&$(gridId).querySelector("table");
  return tbl?{title, tableHTML:tbl.outerHTML, rows:tableToRows(tbl)}:null;
}
// Kapsama göre tüm çizelgeleri toplar; çoklu kapsamlarda her okulun DERS LİSTESİ de eklenir
function buildExportSheets(scope){
  const sheets=[];
  if(scope==="single"){
    const s=buildSingleSheet(); if(s) sheets.push(s);
  }else if(scope==="classes"){
    const sc=curSchool(); for(const cl of sc.classes) sheets.push(buildClassSheet(sc,cl));
  }else if(scope==="teachers"){
    for(const t of [...S.teachers]) sheets.push(buildTeacherSheet(t));
  }else if(scope==="rooms"){
    for(const r of [...(S.rooms||[])]) sheets.push(buildRoomSheet(r));
  }else if(scope==="classTeacher"){
    const sc=curSchool(); for(const cl of sc.classes) sheets.push(buildClassSheet(sc,cl));
    for(const t of [...S.teachers]) sheets.push(buildTeacherSheet(t));
  }else if(scope==="all"){
    for(const sc of S.schools){ if(!(sc.defs||[]).length) continue; for(const cl of sc.classes) sheets.push(buildClassSheet(sc,cl)); }
    // Öğretmenler: okul bazlı + birlikte programları
    for(const t of [...S.teachers]){
      for(const sc of schoolsWithDefs()) sheets.push(buildTeacherSchoolSheet(t,sc));
      sheets.push(buildTeacherSheet(t));
    }
    for(const r of [...(S.rooms||[])]) sheets.push(buildRoomSheet(r));
  }
  return sheets;
}
// Bir öğretmenin TEK OKUL çizelgesi (okul bazlı raporlar için)
function buildTeacherSchoolSheet(t, sc){
  const tmp=document.createElement("div");
  tmp.style.cssText="position:absolute;left:-9999px;top:0;";
  document.body.appendChild(tmp);
  renderGrid(tmp,"teacher",t,sc);
  const tbl=tmp.querySelector("table");
  const html=tbl?tbl.outerHTML:"";
  const rows=tbl?tableToRows(tbl):[];
  tmp.remove();
  const subRows=[["Ders","Sınıf","Saat"]];
  let total=0;
  for(const d of sc.defs||[]){ if(!defTeachers(d).includes(t)) continue; const h=Math.max(1,Number(d.hours)||1); subRows.push([String(d.course),String(d.className),String(h)]); total+=h; }
  subRows.push(["TOPLAM","",String(total)]);
  return {title:`${t} — ${sc.name}`, tableHTML:html, rows, subRows};
}
// PDF: tüm çizelgeler gizli yazdırma alanına yerleştirilir, tarayıcı yazdırmasıyla çıktı alınır
function exportPdf(scope){
  const sheets=buildExportSheets(scope);
  if(!sheets.length){toast("Aktarılacak çizelge yok.","err");return;}
  const prev=document.title;
  const area=$("printArea");
  // Her çizelge + en sonda ilgili okulların ders listeleri
  let html=sheets.map(s=>{
    let h=`<div class="pa-sheet${s.wide?" pa-wide":""}"><div class="pa-title">${esc(s.title)}</div>${s.tableHTML}`;
    if(s.subRows&&s.subRows.length>1){
      h+=`<div class="pa-sub-title">Ders Listesi</div><table class="pa-list">${s.subRows.map((r,i)=>`<tr>${r.map(c=>`<${i===0?"th":"td"}>${esc(c)}</${i===0?"th":"td"}>`).join("")}</tr>`).join("")}</table>`;
    }
    return h+`</div>`;
  }).join("");
  area.innerHTML=html;
  document.body.classList.add("export-print");
  document.title=`${curSchool().name} — ${scopeLabel(scope)} — Planla!`;
  toast("Yazdırma penceresinde hedef olarak 'PDF olarak kaydet'i seçin.");
  setTimeout(()=>{ window.print(); document.body.classList.remove("export-print"); area.innerHTML=""; document.title=prev; },80);
}
// Dosyayı indir (anchor'u DOM'a ekleyerek — daha güvenilir)
function downloadBlob(content, filename, mime){
  const blob=new Blob([content],{type:mime||"application/octet-stream"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url; a.download=filename; a.style.display="none";
  document.body.appendChild(a);
  a.click();
  setTimeout(()=>{ document.body.removeChild(a); URL.revokeObjectURL(url); },1000);
}
// Excel: çizelgeleri Excel 2003 XML (çok sayfalı) biçiminde .xls olarak dışa aktarır — uyarısız açılır
function exportExcel(scope){
  const sheets=buildExportSheets(scope);
  if(!sheets.length){toast("Aktarılacak çizelge yok.","err");return;}
  const fname=`${curSchool().name.replace(/\s+/g,"_")}_${scopeLabel(scope).replace(/\s+/g,"_")}`;
  // Excel çalışma sayfası biçimlendirme: başlık + grid başlığı kalın, gün sütunu kalın,
  // ders hücreleri ders rengine göre pastel dolgu + kalın yazı, kenarlıklar, çizgili satırlar, satır kaydırma
  const EXCEL_PALETTE={c0:{fill:"FFF3E0",font:"E65100"},c1:{fill:"E3F2FD",font:"0D47A1"},c2:{fill:"E8F5E9",font:"1B5E20"},c3:{fill:"FCE4EC",font:"880E4F"},c4:{fill:"F3E5F5",font:"4A148C"},c5:{fill:"FFF8E1",font:"F57F17"},c6:{fill:"E0F7FA",font:"006064"},c7:{fill:"FBE9E7",font:"BF360C"},c8:{fill:"F1F8E9",font:"33691E"},c9:{fill:"EDE7F6",font:"311B92"}};
  const thinBorder={top:{style:"thin",color:{rgb:"9AA0A6"}},bottom:{style:"thin",color:{rgb:"9AA0A6"}},left:{style:"thin",color:{rgb:"9AA0A6"}},right:{style:"thin",color:{rgb:"9AA0A6"}}};
  function styleExcelSheet(ws, gridRows, colCount, metaRows){
    const enc=(r,c)=>XLSX.utils.encode_cell({r,c});
    if(ws[enc(0,0)]) ws[enc(0,0)].s={font:{bold:true,sz:14},alignment:{vertical:"center"}};
    for(let c=0;c<colCount;c++){
      const a=enc(1,c);
      if(ws[a]) ws[a].s={font:{bold:true},fill:{fgColor:{rgb:"DDDDDD"}},border:thinBorder,alignment:{vertical:"middle",horizontal:"center",wrapText:true}};
    }
    for(let r=0;r<gridRows;r++){
      const metaRow=metaRows[r+1]||[];
      const dayFill=(r%2===1)?{fgColor:{rgb:"F2F2F2"}}:undefined;
      for(let c=0;c<colCount;c++){
        const a=enc(r+2,c);
        if(!ws[a]) continue;
        const cls=(typeof metaRow[c]==="object"&&metaRow[c].cls)?metaRow[c].cls:"";
        const cm=cls.match(/\bc(\d)\b/);
        let s={alignment:{wrapText:true,vertical:"center",horizontal:"center"},border:thinBorder};
        if(c===0){ s.font={bold:true}; if(dayFill) s.fill=dayFill; }
        else if(cm){ const p=EXCEL_PALETTE["c"+cm[1]]||EXCEL_PALETTE.c0; s.fill={fgColor:{rgb:p.fill}}; s.font={bold:true,color:{rgb:p.font}}; }
        else if(dayFill){ s.fill=dayFill; }
        ws[a].s=s;
      }
    }
    ws["!cols"]=Array.from({length:colCount},(_,i)=>({wch:i===0?(colCount>20?8:14):(colCount>20?5:13)}));
    ws["!rows"]=Array.from({length:gridRows+2},(_,r)=>({hpt:r===0?22:r===1?20:30}));
    ws["!freeze"]={xSplit:1,ySplit:2};
  }
  // Birincil: SheetJS ile gerçek .xlsx
  if(typeof XLSX!=="undefined"){
    try{
      const wb=XLSX.utils.book_new();
      sheets.forEach((s,i)=>{
        const metaRows=s.rows||[];
        const gridRows=metaRows.map(r=>r.map(c=>(typeof c==="object"?c.v:String(c))));
        const colCount=Math.max(1,...gridRows.map(r=>r.length));
        const extraSub=s.subRows||[];
        const aoa=[[String(s.title||"")],...gridRows];
        let subStart=aoa.length;
        if(extraSub.length){ aoa.push([""]); subStart=aoa.length; for(const r of extraSub) aoa.push(r.map(x=>String(x))); }
        const ws=XLSX.utils.aoa_to_sheet(aoa);
        // Birleştirmeler: başlık + 10 dk blok hücreleri (colspan)
        const merges=[];
        if(colCount>1) merges.push({s:{r:0,c:0},e:{r:0,c:colCount-1}});
        for(let r=0;r<metaRows.length;r++){
          let c=0;
          for(const cell of metaRows[r]){
            // Devam hücreleri (span:0) birleşik bloğun parçasıdır; sütun sayacı yalnızca
            // başlangıç hücresinin span'i kadar ilerler. Aksi halde yanlış birleşmeler oluşur.
            const span=(typeof cell==="object"&&cell.span!==undefined)?cell.span:1;
            if(span>1) merges.push({s:{r:r+1,c},e:{r:r+1,c:c+span-1}});
            c+=span;
          }
        }
        if(merges.length) ws["!merges"]=merges;
        styleExcelSheet(ws,gridRows.length,colCount,metaRows);
        if(s.wide){ ws["!rows"]=Array.from({length:aoa.length},(_,r)=>({hpt:r===0?18:r===1?14:15})); }
        // Alt ders listesi stili (kenarlık + başlık/toplam kalın)
        if(extraSub.length){
          for(let r=subStart;r<aoa.length;r++){ for(let c=0;c<3;c++){ const a=XLSX.utils.encode_cell({r,c}); if(ws[a]) ws[a].s=Object.assign({},ws[a].s||{},{border:thinBorder,alignment:{vertical:"top",wrapText:true}}); } }
          for(let c=0;c<3;c++){
            const h=XLSX.utils.encode_cell({r:subStart,c}); if(ws[h]) ws[h].s=Object.assign({},ws[h].s||{},{font:{bold:true}});
            const t=XLSX.utils.encode_cell({r:aoa.length-1,c}); if(ws[t]) ws[t].s=Object.assign({},ws[t].s||{},{font:{bold:true}});
          }
        }
        const name=String(s.title||("Sayfa"+(i+1))).replace(/[\[\]:*?/\\]/g," ").trim().slice(0,31)||("Sayfa"+(i+1));
        XLSX.utils.book_append_sheet(wb,ws,name);
      });
      XLSX.writeFile(wb, fname+".xlsx", {cellStyles:true});
      toast(`${sheets.length} çizelge Excel (.xlsx) olarak indiriliyor.`);
      return;
    }catch(err){
      toast("Excel oluşturulurken hata: "+err.message,"err");
    }
  }
  // Yedek: Excel 2003 XML (.xml uzantısı — uyarısız açılır)
  const clean=n=>String(n||"").replace(/[\[\]:*?/\\]/g," ").trim().slice(0,31);
  const toXmlRow=r=>`<Row>${r.map(c=>`<Cell><Data ss:Type="String">${xmlEsc(typeof c==="object"?c.v:String(c))}</Data></Cell>`).join("")}</Row>`;
  const ws=sheets.map((s,i)=>{
    const name=xmlEsc(clean(s.title||("Sayfa"+(i+1))));
    const rows=(s.rows||[]).map(toXmlRow).join("");
    return `<Worksheet ss:Name="${name}"><Table>${rows}</Table></Worksheet>`;
  }).join("");
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">${ws}</Workbook>`;
  downloadBlob(xml, fname+".xml", "application/vnd.ms-excel");
  toast(`${sheets.length} çizelge Excel olarak indiriliyor.`);
}
// Açılır menü bağları
let exportFormat="pdf";
function toggleExportMenu(e){
  const m=$("exportMenu");
  if(m.classList.contains("hidden")){
    const r=e.currentTarget.getBoundingClientRect();
    m.style.minWidth="240px";
    m.style.visibility="hidden";
    m.style.display="flex";
    const mh=m.offsetHeight;
    m.style.visibility="";
    m.style.display="";
    const spaceBelow=window.innerHeight-r.bottom;
    if(spaceBelow<mh && r.top>mh+8){
      m.style.top=(r.top-mh-6)+"px";
    }else{
      m.style.top=Math.max(4,Math.min(r.bottom+4,window.innerHeight-mh-4))+"px";
    }
    m.style.left=Math.max(6,Math.min(r.left,window.innerWidth-246))+"px";
    m.classList.remove("hidden");
  }else m.classList.add("hidden");
}
$("pdfBtn").addEventListener("click",e=>{ exportFormat="pdf"; toggleExportMenu(e); });
$("excelBtn").addEventListener("click",e=>{ exportFormat="excel"; toggleExportMenu(e); });
$("exportMenu").addEventListener("click",e=>{
  const item=e.target.closest(".em-item");
  if(!item) return;
  $("exportMenu").classList.add("hidden");
  const scope=item.dataset.scope;
  if(exportFormat==="pdf") exportPdf(scope); else exportExcel(scope);
});
document.addEventListener("click",e=>{
  if(!e.target.closest("#exportMenu")&&!e.target.closest("#pdfBtn")&&!e.target.closest("#excelBtn")) $("exportMenu").classList.add("hidden");
});
$("scheduleStartBtn").addEventListener("click",()=>{
  if($("scheduleStartBtn").disabled) return;
  autoSolve();
});
$("scheduleQfApply").addEventListener("click",()=>{
  let changed=false;
  document.querySelectorAll("#scheduleQfList .qf-teacher").forEach(sel=>{
    const d=curSchool().defs.find(x=>x.id===sel.dataset.id);
    if(!d) return;
    if(sel.value&&sel.value!==d.teacher){ setTeachers(d,[sel.value,...defTeachers(d).slice(1)]); addTeacherCourse(sel.value,d.course); changed=true; }
  });
  document.querySelectorAll("#scheduleQfList .qf-hours").forEach(inp=>{
    const d=curSchool().defs.find(x=>x.id===inp.dataset.id);
    if(!d) return;
    const v=Math.max(1,Math.min(12,Number(inp.value)||1));
    if(v!==d.hours){ d.hours=v; changed=true; }
  });
  if(!changed){ toast("Değişiklik yapılmadı.","err"); return; }
  saveState(); renderDefs(); refresh(); showPrecheck();
});
$("scheduleQfList").addEventListener("click",e=>{
  const btn=e.target.closest(".qf-del");
  if(!btn) return;
  const d=curSchool().defs.find(x=>x.id===btn.dataset.id);
  if(!d) return;
  curSchool().defs=curSchool().defs.filter(x=>x.id!==d.id);
  curSchool().lessons=curSchool().lessons.filter(l=>refKey(l.course,lessonTeachers(l),l.className)!==refKey(d.course,defTeachers(d),d.className));
  saveState(); renderDefs(); refresh(); showPrecheck();
  toast(`"${d.course} — ${d.className}" silindi.`);
});

$("scheduleCloseBtn").addEventListener("click",()=>{ solveCancelled=true; hideScheduleOverlay(); });
$("scheduleSaveBtn").addEventListener("click",downloadState);
$("scheduleOverlay").addEventListener("click",e=>{
  if(e.target===e.currentTarget) hideScheduleOverlay();
});

/* ============================================================
   MODAL — prompt() ve confirm() yerine
   ============================================================ */
let modalCb = null;

function hideModal(){
  $("modalOverlay").classList.remove("open");
  $("modalMsg").style.display="none";
  $("modalInput").style.display="none";
  $("modalTextarea").style.display="none";
  modalCb = null;
}

function showConfirm(title, msg, cb){
  $("modalTitle").textContent = title;
  $("modalMsg").textContent = msg;
  $("modalMsg").style.display="";
  $("modalInput").style.display="none";
  $("modalTextarea").style.display="none";
  $("modalOk").textContent = "Evet";
  modalCb = cb;
  $("modalOverlay").classList.add("open");
  $("modalOk").focus();
}

function showPrompt(title, placeholder, cb){
  $("modalTitle").textContent = title;
  $("modalMsg").style.display="none";
  $("modalInput").style.display="";
  $("modalTextarea").style.display="none";
  $("modalInput").value = "";
  $("modalInput").placeholder = placeholder || "";
  $("modalOk").textContent = "Tamam";
  modalCb = cb;
  $("modalOverlay").classList.add("open");
  setTimeout(()=>$("modalInput").focus(), 100);
}

function showBulkPrompt(title, placeholder, cb){
  $("modalTitle").textContent = title;
  $("modalMsg").style.display="none";
  $("modalInput").style.display="none";
  $("modalTextarea").style.display="";
  $("modalTextarea").value = "";
  $("modalTextarea").placeholder = placeholder || "";
  $("modalOk").textContent = "Ekle";
  modalCb = cb;
  $("modalOverlay").classList.add("open");
  setTimeout(()=>$("modalTextarea").focus(), 100);
}

$("modalCancel").addEventListener("click", hideModal);
$("modalOk").addEventListener("click", ()=>{
  const cb = modalCb;
  hideModal();
  if(cb) cb(true);
});
$("modalInput").addEventListener("keydown", e=>{
  if(e.key==="Enter") $("modalOk").click();
  if(e.key==="Escape") hideModal();
});
$("modalTextarea").addEventListener("keydown", e=>{
  if(e.key==="Escape") hideModal();
});
$("modalOverlay").addEventListener("click", e=>{
  if(e.target===e.currentTarget) hideModal();
});

// Toast
function toast(msg,type){
  const c=$("toasts");
  const t=document.createElement("div");
  t.className="toast"+(type==="ok"?" ok":type==="err"?" err":"");
  t.textContent=msg;
  c.appendChild(t);
  setTimeout(()=>{t.style.opacity="0";t.style.transform="translateY(8px)";t.style.transition=".3s"},2500);
  setTimeout(()=>t.remove(),3000);
}

/* ============================================================
   BAŞLAT
   ============================================================ */
refresh();
