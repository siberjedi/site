# Planla! — Ders Programı Üretici

> **Planla! ücretsizdir.** Dilediğiniz gibi kullanabilir, kopyalayabilir ve paylaşabilirsiniz.

## 🚀 Kurulum gerektirmez

**`baslat.html`** dosyasına çift tıklayın — uygulama tarayıcınızda açılır.
Python, Node.js veya başka bir program kurmanıza gerek yok.

- Tüm kütüphaneler klasörün içindedir, internet gerekmez
- Verileriniz tarayıcınızın hafızasında saklanır (aynı tarayıcıyı kullanmaya devam edin)
- İnternet bağlantınız yoksa yazı tipleri sistem fontuna döner, uygulama normal çalışır

## 📖 Detaylı kullanım kılavuzu

Tüm özellikler için **`KILAVUZ.md`** dosyasına bakın:
ders/sınıf/öğretmen/derslik ekleme, saatleri açma-kapama, teneffüs ve öğle arası,
ders tanımlama, kısıtlar, dağıtım, raporlar, PDF/Excel çıktısı ve daha fazlası.

## Dosyalar

| Dosya | Açıklama |
|---|---|
| `baslat.html` | Uygulama (çift tıkla açılır, kurulum gerekmez) |
| `styles.css` | Tasarım |
| `app.js` | Çözücü + arayüz |
| `KILAVUZ.md` | Detaylı Türkçe kullanım kılavuzu |
| `xlsx.full.min.js`, `cpexcel.js` | Excel çıktısı kütüphaneleri (klasör içinde) |
| `icon.svg`, `icon-dark.svg` | Uygulama ikonu (aydınlık / koyu mod) |